import math
import random

import pygame

from doom_audio import play_no_ammo_sound


WEAPON_PISTOL = 0
WEAPON_AK = 1
WEAPON_SHOTGUN = 2

PISTOL_MAG_SIZE = 6
AK_MAG_SIZE = 30
AK_START_RESERVE = 30
SHOTGUN_MAG_SIZE = 4
SHOTGUN_START_RESERVE = 4

PISTOL_RELOAD_MS = 1500
AK_RELOAD_MS = 3000
SHOTGUN_RELOAD_MS = 4000

PISTOL_FIRE_COOLDOWN_MS = 800
AK_FIRE_COOLDOWN_MS = 130
SHOTGUN_FIRE_COOLDOWN_MS = 900

PISTOL_DAMAGE_RANGE = (30, 45)
AK_DAMAGE_RANGE = (20, 30)
PISTOL_MAX_DAMAGE_DISTANCE = 600.0
AK_MAX_DAMAGE_DISTANCE = 600.0
SHOTGUN_MAX_DAMAGE_DISTANCE = 250.0

PISTOL_RECOIL = 80
AK_RECOIL = 20
SHOTGUN_RECOIL = 160

PISTOL_PITCH_KICK = 25
AK_PITCH_KICK_RANGE = (10, 18)
SHOTGUN_PITCH_KICK_RANGE = (50, 90)

PISTOL_SPREAD_ANGLE = 0.005
PISTOL_SPREAD_PITCH = 2.0
AK_SPREAD_ANGLE = 0.02
AK_SPREAD_PITCH = 5.0
SHOTGUN_SPREAD_ANGLE = 0.06
SHOTGUN_SPREAD_PITCH = 15.0

SHOTGUN_PELLET_COUNT = 5
SHOTGUN_BODY_DAMAGE = 20
SHOTGUN_HEADSHOT_DAMAGE = 30

AK_AMMO_PICKUP_LARGE = 30
AK_AMMO_PICKUP_SMALL = 15
SHOTGUN_AMMO_PICKUP = 4


def build_weapon_state():
    return {
        'current_weapon': WEAPON_PISTOL,
        'has_ak': False,
        'has_shotgun': False,
        'current_pistol_ammo': PISTOL_MAG_SIZE,
        'current_ak_ammo': AK_MAG_SIZE,
        'ak_reserve_ammo': AK_START_RESERVE,
        'current_shotgun_ammo': SHOTGUN_MAG_SIZE,
        'shotgun_reserve_ammo': SHOTGUN_START_RESERVE,
    }


def start_reload(ctx):
    if ctx['is_reloading']:
        return

    current_time = pygame.time.get_ticks()

    if ctx['current_weapon'] == WEAPON_PISTOL:
        if ctx['current_pistol_ammo'] < PISTOL_MAG_SIZE:
            ctx['is_reloading'] = True
            ctx['reload_end'] = current_time + PISTOL_RELOAD_MS
            ctx['play_sound']('pistol_reload')
        return

    if ctx['current_weapon'] == WEAPON_AK:
        if ctx['current_ak_ammo'] < AK_MAG_SIZE and ctx['ak_reserve_ammo'] > 0:
            ctx['is_reloading'] = True
            ctx['reload_end'] = current_time + AK_RELOAD_MS
            ctx['play_sound']('ak_reload')
            return
        if ctx['current_ak_ammo'] < AK_MAG_SIZE:
            ctx['last_no_ammo_time'] = play_no_ammo_sound(
                ctx['sounds'],
                ctx['last_no_ammo_time'],
                current_time,
            )
        return

    if ctx['current_weapon'] == WEAPON_SHOTGUN and ctx['current_shotgun_ammo'] < SHOTGUN_MAG_SIZE:
        if ctx['shotgun_reserve_ammo'] > 0:
            ctx['is_reloading'] = True
            ctx['reload_end'] = current_time + SHOTGUN_RELOAD_MS
            ctx['play_sound']('shotgun_reload')
        else:
            ctx['last_no_ammo_time'] = play_no_ammo_sound(
                ctx['sounds'],
                ctx['last_no_ammo_time'],
                current_time,
            )


def update_reload_state(ctx, current_time):
    if not ctx['is_reloading'] or current_time < ctx['reload_end']:
        return

    ctx['is_reloading'] = False
    if ctx['current_weapon'] == WEAPON_PISTOL:
        ctx['current_pistol_ammo'] = PISTOL_MAG_SIZE
    elif ctx['current_weapon'] == WEAPON_AK:
        needed = AK_MAG_SIZE - ctx['current_ak_ammo']
        taken = min(needed, ctx['ak_reserve_ammo'])
        ctx['current_ak_ammo'] += taken
        ctx['ak_reserve_ammo'] -= taken
    elif ctx['current_weapon'] == WEAPON_SHOTGUN:
        needed = SHOTGUN_MAG_SIZE - ctx['current_shotgun_ammo']
        taken = min(needed, ctx['shotgun_reserve_ammo'])
        ctx['current_shotgun_ammo'] += taken
        ctx['shotgun_reserve_ammo'] -= taken


def auto_reload_if_needed(ctx):
    if ctx['current_weapon'] == WEAPON_PISTOL and ctx['current_pistol_ammo'] == 0:
        start_reload(ctx)
    elif ctx['current_weapon'] == WEAPON_AK and ctx['current_ak_ammo'] == 0 and ctx['ak_reserve_ammo'] > 0:
        start_reload(ctx)
    elif (
        ctx['current_weapon'] == WEAPON_SHOTGUN
        and ctx['current_shotgun_ammo'] == 0
        and ctx['shotgun_reserve_ammo'] > 0
    ):
        start_reload(ctx)


def shoot(ctx):
    current_time = pygame.time.get_ticks()

    if (
        ctx['player_dead']
        or ctx['is_reloading']
        or ctx['is_melee_attacking']
        or ctx['grenade_ready']
        or ctx['game_state'] != ctx['STATE_PLAYING']
    ):
        return
    if current_time < ctx['fire_cooldown_end']:
        return

    pellet_count = 1
    move_penalty = 1.3 if ctx['player_is_moving'] else 1.0

    if ctx['current_weapon'] == WEAPON_PISTOL:
        if ctx['current_pistol_ammo'] <= 0:
            start_reload(ctx)
            return
        ctx['current_pistol_ammo'] -= 1
        ctx['play_sound']('pistol_shoot')
        ctx['fire_cooldown_end'] = current_time + PISTOL_FIRE_COOLDOWN_MS
        ctx['gun_recoil'] = PISTOL_RECOIL
        base_damage = random.randint(*PISTOL_DAMAGE_RANGE)
        max_damage_distance = PISTOL_MAX_DAMAGE_DISTANCE
        ctx['player_pitch'] += PISTOL_PITCH_KICK
        ctx['player_angle'] += random.uniform(-0.01, 0.01) * move_penalty
        spread_angle_range = PISTOL_SPREAD_ANGLE * move_penalty
        spread_pitch_range = PISTOL_SPREAD_PITCH * move_penalty
    elif ctx['current_weapon'] == WEAPON_AK:
        if ctx['current_ak_ammo'] <= 0:
            start_reload(ctx)
            return
        ctx['current_ak_ammo'] -= 1
        ctx['play_sound']('ak_shoot')
        ctx['fire_cooldown_end'] = current_time + AK_FIRE_COOLDOWN_MS
        ctx['gun_recoil'] = AK_RECOIL
        base_damage = random.randint(*AK_DAMAGE_RANGE)
        max_damage_distance = AK_MAX_DAMAGE_DISTANCE
        ctx['player_pitch'] += random.uniform(*AK_PITCH_KICK_RANGE)
        ctx['player_angle'] += random.uniform(-0.015, 0.015) * move_penalty
        spread_angle_range = AK_SPREAD_ANGLE * move_penalty
        spread_pitch_range = AK_SPREAD_PITCH * move_penalty
    elif ctx['current_weapon'] == WEAPON_SHOTGUN:
        if ctx['current_shotgun_ammo'] <= 0:
            start_reload(ctx)
            return
        ctx['current_shotgun_ammo'] -= 1
        ctx['play_sound']('shotgun_shoot')
        ctx['fire_cooldown_end'] = current_time + SHOTGUN_FIRE_COOLDOWN_MS
        ctx['gun_recoil'] = SHOTGUN_RECOIL
        base_damage = SHOTGUN_BODY_DAMAGE
        max_damage_distance = SHOTGUN_MAX_DAMAGE_DISTANCE
        pellet_count = SHOTGUN_PELLET_COUNT
        ctx['player_pitch'] += random.uniform(*SHOTGUN_PITCH_KICK_RANGE)
        ctx['player_angle'] += random.uniform(-0.1, 0.1) * (1.5 if ctx['player_is_moving'] else 1.0)
        shotgun_penalty = 1.2 if ctx['player_is_moving'] else 1.0
        spread_angle_range = SHOTGUN_SPREAD_ANGLE * shotgun_penalty
        spread_pitch_range = SHOTGUN_SPREAD_PITCH * shotgun_penalty
    else:
        return

    ctx['player_pitch'] = max(
        -ctx['HEIGHT'] // 2 + ctx['PLAYER_PITCH_LIMIT_MARGIN'],
        min(ctx['HEIGHT'] // 2 - ctx['PLAYER_PITCH_LIMIT_MARGIN'], ctx['player_pitch']),
    )
    ctx['is_shooting'] = True
    ctx['shoot_timer'] = 8

    for _ in range(pellet_count):
        angle_offset = random.uniform(-spread_angle_range, spread_angle_range)
        pitch_offset = random.uniform(-spread_pitch_range, spread_pitch_range)
        shot_angle = ctx['player_angle'] + angle_offset
        shot_pitch = ctx['player_pitch'] + pitch_offset

        ray_idx = int(((shot_angle - (ctx['player_angle'] - ctx['current_fov'] / 2)) / ctx['current_fov']) * ctx['CASTED_RAYS'])
        ray_idx = max(0, min(ctx['CASTED_RAYS'] - 1, ray_idx))
        wall_dist = ctx['Z_BUFFER'][ray_idx]

        target_enemy = None
        min_dist = wall_dist
        is_headshot = False

        for enemy in ctx['enemies']:
            if enemy['dead']:
                continue

            dx = enemy['x'] - ctx['player_x']
            dy = enemy['y'] - ctx['player_y']
            dist = math.hypot(dx, dy)
            safe_dist = max(1.0, dist)

            angle_to_enemy = math.atan2(dy, dx)
            angle_diff = angle_to_enemy - shot_angle
            while angle_diff < -math.pi:
                angle_diff += 2 * math.pi
            while angle_diff > math.pi:
                angle_diff -= 2 * math.pi

            if abs(angle_diff) >= ctx['current_fov'] / 2 or dist >= min_dist:
                continue

            wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / safe_dist
            sprite_height = wall_height * 0.8
            sprite_width = sprite_height * 0.6

            monster_bottom = ctx['HEIGHT'] // 2 + wall_height // 2 + shot_pitch
            monster_top = monster_bottom - sprite_height

            pixel_offset = (angle_diff / (ctx['current_fov'] / 2)) * (ctx['WIDTH'] / 2)
            hit_y = ctx['HEIGHT'] // 2

            if abs(pixel_offset) < sprite_width / 2 and monster_top <= hit_y <= monster_bottom:
                target_enemy = enemy
                min_dist = dist
                is_headshot = monster_top <= hit_y <= monster_top + sprite_height * 0.3

        if target_enemy is not None:
            distance_ratio = min(min_dist / max_damage_distance, 1.0)
            damage_multiplier = 1.0 - (0.8 * distance_ratio)

            if ctx['current_weapon'] == WEAPON_SHOTGUN:
                damage = SHOTGUN_HEADSHOT_DAMAGE if is_headshot else SHOTGUN_BODY_DAMAGE
            else:
                final_base_damage = base_damage * damage_multiplier
                damage = int(final_base_damage * 1.5) if is_headshot else int(final_base_damage)

            if damage > 0:
                target_enemy['hp'] -= damage
                offset_x = random.randint(-40, 40)
                offset_y = random.randint(-40, 0)
                ctx['damage_texts'].append(
                    {
                        'text': f"{damage}",
                        'x': ctx['WIDTH'] // 2 + offset_x,
                        'y': ctx['HEIGHT'] // 2 + offset_y,
                        'color': ctx['YELLOW'] if is_headshot else ctx['WHITE'],
                        'life': 45,
                    }
                )
                if target_enemy['hp'] <= 0 and not target_enemy['dead']:
                    ctx['kill_enemy'](target_enemy, is_headshot)
            continue

        target_x = ctx['player_x'] + math.cos(shot_angle) * (min_dist - 2)
        target_y = ctx['player_y'] + math.sin(shot_angle) * (min_dist - 2)
        wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / max(1.0, min_dist)
        hit_ratio = (-shot_pitch) / wall_height if wall_height > 0 else 0
        ctx['bullet_holes'].append({'x': target_x, 'y': target_y, 'ratio': hit_ratio, 'life': 300})


def draw_weapon(ctx):
    bob_x = 0
    bob_y = 0
    if ctx['player_is_moving'] and not ctx['is_aiming'] and ctx['game_state'] == ctx['STATE_PLAYING']:
        ctx['walk_timer'] += 0.15 * ctx['time_scale']
        bob_x = math.cos(ctx['walk_timer']) * 15
        bob_y = abs(math.sin(ctx['walk_timer'])) * 15
    else:
        ctx['walk_timer'] = 0

    actual_recoil = ctx['gun_recoil'] * 4.0 if ctx['current_weapon'] == WEAPON_SHOTGUN else ctx['gun_recoil']
    gun_base_pos = ctx['HEIGHT'] + 250 if ctx['is_reloading'] else ctx['HEIGHT'] + 80 + actual_recoil + bob_y
    center_x = ctx['WIDTH'] // 2 + bob_x
    skin_color = (224, 172, 105)

    if ctx['is_melee_attacking']:
        progress = ctx['melee_timer'] / 15.0
        offset_y = math.sin(progress * math.pi) * 80
        blade_color = (200, 200, 200)
        handle_color = (50, 50, 50)
        pygame.draw.polygon(
            ctx['virtual_screen'],
            blade_color,
            [
                (center_x + 20, ctx['HEIGHT'] - offset_y),
                (center_x + 35, ctx['HEIGHT'] - 150 - offset_y),
                (center_x + 45, ctx['HEIGHT'] - offset_y),
            ],
        )
        pygame.draw.rect(ctx['virtual_screen'], handle_color, (center_x + 25, ctx['HEIGHT'] - offset_y, 15, 80))
        return

    if ctx['grenade_ready']:
        hand_color = (210, 160, 120)
        grenade_x = center_x + 110
        grenade_y = ctx['HEIGHT'] - 105 + bob_y

        pygame.draw.polygon(
            ctx['virtual_screen'],
            hand_color,
            [
                (grenade_x - 95, ctx['HEIGHT']),
                (grenade_x - 20, grenade_y + 20),
                (grenade_x + 15, grenade_y - 15),
                (grenade_x - 55, ctx['HEIGHT']),
            ],
        )
        pygame.draw.circle(ctx['virtual_screen'], (70, 110, 70), (int(grenade_x), int(grenade_y)), 34)
        pygame.draw.circle(ctx['virtual_screen'], (40, 60, 40), (int(grenade_x), int(grenade_y)), 22, 3)
        pygame.draw.rect(ctx['virtual_screen'], (90, 90, 90), (grenade_x - 12, grenade_y - 48, 24, 16), border_radius=4)
        pygame.draw.rect(ctx['virtual_screen'], (180, 180, 180), (grenade_x + 8, grenade_y - 54, 22, 8), border_radius=3)
        return

    if ctx['current_weapon'] == WEAPON_PISTOL:
        metal_light = (110, 110, 110)
        metal_dark = (50, 50, 50)
        grip_color = (20, 20, 20)
        skin_color = (210, 160, 120)

        if ctx['is_aiming']:
            weapon_x = ctx['WIDTH'] // 2
            weapon_y = ctx['HEIGHT'] // 2 + 290
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        slide_top = weapon_y - 250
        if ctx['is_shooting']:
            flash_y = slide_top
            pygame.draw.circle(ctx['virtual_screen'], (255, 150, 0), (weapon_x, flash_y), 25)
            pygame.draw.circle(ctx['virtual_screen'], (255, 255, 200), (weapon_x, flash_y), 15)
            pygame.draw.polygon(
                ctx['virtual_screen'],
                (255, 200, 0),
                [
                    (weapon_x, flash_y - 40),
                    (weapon_x - 8, flash_y - 10),
                    (weapon_x - 30, flash_y),
                    (weapon_x - 8, flash_y + 10),
                    (weapon_x, flash_y + 20),
                    (weapon_x + 8, flash_y + 10),
                    (weapon_x + 30, flash_y),
                    (weapon_x + 8, flash_y - 10),
                ],
            )

        if ctx['is_aiming']:
            arm_top = ctx['HEIGHT']
            arm_bottom = weapon_y - 120
            pygame.draw.polygon(
                ctx['virtual_screen'],
                skin_color,
                [(weapon_x - 180, arm_top), (weapon_x - 90, arm_bottom + 30), (weapon_x - 20, arm_bottom - 20), (weapon_x - 80, arm_top)],
            )
            pygame.draw.polygon(
                ctx['virtual_screen'],
                skin_color,
                [(weapon_x + 180, arm_top), (weapon_x + 90, arm_bottom + 30), (weapon_x + 20, arm_bottom - 20), (weapon_x + 80, arm_top)],
            )

        grip_top = weapon_y - 150
        grip_bottom = weapon_y + 100
        pygame.draw.polygon(
            ctx['virtual_screen'],
            grip_color,
            [(weapon_x - 45, grip_top), (weapon_x + 45, grip_top), (weapon_x + 65, grip_bottom), (weapon_x - 65, grip_bottom)],
        )
        for i in range(1, 4):
            pygame.draw.line(
                ctx['virtual_screen'],
                (40, 40, 40),
                (weapon_x - 30, grip_top + i * 30),
                (weapon_x + 30, grip_top + i * 30),
                4,
            )

        body_top = weapon_y - 180
        pygame.draw.rect(ctx['virtual_screen'], metal_dark, (weapon_x - 40, body_top, 80, 100))
        pygame.draw.polygon(
            ctx['virtual_screen'],
            metal_dark,
            [(weapon_x - 35, body_top + 90), (weapon_x + 35, body_top + 90), (weapon_x + 30, body_top + 130), (weapon_x - 30, body_top + 130)],
            8,
        )
        pygame.draw.rect(ctx['virtual_screen'], metal_light, (weapon_x - 35, slide_top, 70, 140), border_radius=3)
        pygame.draw.rect(ctx['virtual_screen'], (10, 10, 10), (weapon_x - 12, slide_top - 10, 24, 15))
        pygame.draw.rect(ctx['virtual_screen'], ctx['BLACK'], (weapon_x + 18, slide_top + 30, 12, 50))
    elif ctx['current_weapon'] == WEAPON_AK:
        if ctx['is_aiming']:
            weapon_x = ctx['WIDTH'] // 2
            weapon_y = ctx['HEIGHT'] // 2 + 350
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        if ctx['is_shooting'] and ctx['shoot_timer'] >= 5:
            flash_y = weapon_y - 330
            pygame.draw.circle(ctx['virtual_screen'], (255, 150, 0), (weapon_x, flash_y), 20)
            pygame.draw.circle(ctx['virtual_screen'], (255, 255, 200), (weapon_x, flash_y), 10)
            pygame.draw.polygon(
                ctx['virtual_screen'],
                (255, 200, 0),
                [
                    (weapon_x, flash_y - 25),
                    (weapon_x - 6, flash_y - 6),
                    (weapon_x - 20, flash_y),
                    (weapon_x - 6, flash_y + 6),
                    (weapon_x, flash_y + 12),
                    (weapon_x + 6, flash_y + 6),
                    (weapon_x + 20, flash_y),
                    (weapon_x + 6, flash_y - 6),
                ],
            )

        wood = (120, 60, 20)
        pygame.draw.rect(ctx['virtual_screen'], wood, (weapon_x - 40, weapon_y - 150, 80, 150), border_radius=10)
        pygame.draw.polygon(ctx['virtual_screen'], (30, 30, 30), [(weapon_x - 20, weapon_y - 150), (weapon_x + 20, weapon_y - 150), (weapon_x + 40, weapon_y - 50), (weapon_x, weapon_y - 30)])
        pygame.draw.rect(ctx['virtual_screen'], (40, 40, 40), (weapon_x - 25, weapon_y - 320, 50, 200), border_radius=2)
        pygame.draw.rect(ctx['virtual_screen'], wood, (weapon_x - 30, weapon_y - 280, 60, 80), border_radius=5)
        pygame.draw.rect(ctx['virtual_screen'], (20, 20, 20), (weapon_x - 5, weapon_y - 330, 10, 10))

        if ctx['is_aiming']:
            skin_color = (210, 160, 120)
            pygame.draw.rect(ctx['virtual_screen'], skin_color, (weapon_x - 50, weapon_y - 280, 25, 70), border_radius=12)
            pygame.draw.rect(ctx['virtual_screen'], skin_color, (weapon_x + 20, weapon_y - 150, 35, 90), border_radius=15)
    elif ctx['current_weapon'] == WEAPON_SHOTGUN:
        if ctx['is_aiming']:
            weapon_x = ctx['WIDTH'] // 2
            weapon_y = ctx['HEIGHT'] // 2 + 90
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        if ctx['is_shooting']:
            flash_y = weapon_y - 380
            pygame.draw.circle(ctx['virtual_screen'], (255, 100, 0), (weapon_x, flash_y), 45)
            pygame.draw.circle(ctx['virtual_screen'], (255, 255, 150), (weapon_x, flash_y), 25)
            pygame.draw.polygon(
                ctx['virtual_screen'],
                (255, 150, 0),
                [
                    (weapon_x, flash_y - 60),
                    (weapon_x - 15, flash_y - 15),
                    (weapon_x - 50, flash_y),
                    (weapon_x - 15, flash_y + 15),
                    (weapon_x, flash_y + 30),
                    (weapon_x + 15, flash_y + 15),
                    (weapon_x + 50, flash_y),
                    (weapon_x + 15, flash_y - 15),
                ],
            )

        wood = (120, 60, 20)
        metal = (50, 50, 50)
        dark_metal = (35, 35, 35)
        pygame.draw.rect(ctx['virtual_screen'], wood, (weapon_x - 38, weapon_y - 155, 76, 155), border_radius=8)
        pygame.draw.rect(ctx['virtual_screen'], metal, (weapon_x - 35, weapon_y - 260, 70, 110))
        pygame.draw.rect(ctx['virtual_screen'], wood, (weapon_x - 38, weapon_y - 240, 76, 60), border_radius=5)

        barrel_width = 25
        barrel_spacing = 6
        barrel_x1 = weapon_x - barrel_width - (barrel_spacing // 2)
        barrel_x2 = weapon_x + (barrel_spacing // 2)
        pygame.draw.rect(ctx['virtual_screen'], dark_metal, (barrel_x1, weapon_y - 370, barrel_width, 110))
        pygame.draw.rect(ctx['virtual_screen'], dark_metal, (barrel_x2, weapon_y - 370, barrel_width, 110))
        pygame.draw.rect(ctx['virtual_screen'], (10, 10, 10), (weapon_x - 6, weapon_y - 380, 12, 10))

    if ctx['game_state'] == ctx['STATE_PLAYING']:
        decay = 10 if ctx['current_weapon'] == WEAPON_AK else 5
        ctx['gun_recoil'] = max(0, ctx['gun_recoil'] - (decay * ctx['time_scale']))

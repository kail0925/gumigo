import pygame


def build_fonts():
    return {
        'PROG_FONT': pygame.font.SysFont('malgungothic', 30, bold=True),
        'GO_FONT': pygame.font.SysFont('malgungothic', 100, bold=True),
        'DMG_FONT': pygame.font.SysFont('malgungothic', 24, bold=True),
        'ITEM_FONT': pygame.font.SysFont('malgungothic', 20, bold=True),
        'TITLE_FONT': pygame.font.SysFont('malgungothic', 80, bold=True),
        'SMALL_UI_FONT': pygame.font.SysFont('malgungothic', 22, bold=True),
        'INPUT_FONT': pygame.font.SysFont('malgungothic', 32, bold=True),
    }


def create_display(width, height, caption):
    current_win_size = (width, height)
    screen = pygame.display.set_mode(current_win_size, pygame.RESIZABLE)
    virtual_screen = pygame.Surface((width, height))
    pygame.display.set_caption(caption)
    clock = pygame.time.Clock()
    return current_win_size, screen, virtual_screen, clock


def build_background(width, height, fog_color):
    bg_height = height * 2
    bg_surface = pygame.Surface((width, bg_height))
    horizon_y = bg_height // 2

    for y in range(bg_height):
        if y < horizon_y:
            ratio = y / horizon_y
            color = (
                int(10 + fog_color[0] * ratio),
                int(10 + fog_color[1] * ratio),
                int(15 + fog_color[2] * ratio),
            )
        else:
            ratio = (y - horizon_y) / horizon_y
            color = (
                int(fog_color[0] * (1 - ratio) + 50 * ratio),
                int(fog_color[1] * (1 - ratio) + 45 * ratio),
                int(fog_color[2] * (1 - ratio) + 40 * ratio),
            )

        pygame.draw.line(bg_surface, color, (0, y), (width, y))

    return bg_surface

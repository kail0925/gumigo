import colorsys
import math

import pygame


TEXT_PISTOL = "\uad8c\ucd1d"
TEXT_SHOTGUN = "\uc0f7\uac74"
TEXT_SCORE = "\uc810\uc218"
TEXT_HEALTH = "\uccb4\ub825"
TEXT_MELEE = "[F] \uadfc\uc811 \uacf5\uaca9"
TEXT_GRENADE = "[G] \uc218\ub958\ud0c4"
TEXT_GRENADE_READY = "\uc900\ube44\ub428"
TEXT_NEXT_GRENADE = "\ub2e4\uc74c \uc218\ub958\ud0c4\uae4c\uc9c0"
TEXT_RELOADING = "\uc7ac\uc7a5\uc804 \uc911..."
TEXT_AMMO = "\ud0c4\uc57d"
TEXT_EXPLOSION = "\ud3ed\ubc1c"
TEXT_SETTINGS = "\uc124\uc815"
TEXT_SENSITIVITY = "\ub9c8\uc6b0\uc2a4 \uac10\ub3c4 \uc124\uc815"
TEXT_RESET = "\ucd08\uae30\ud654"
TEXT_SAVE = "\uc800\uc7a5"
TEXT_DONT_SAVE = "\uc800\uc7a5 \uc548\ud568"
TEXT_CANCEL = "\ucde8\uc18c"
TEXT_DEFAULT_COLOR = "\uae30\ubcf8\uc0c9"
TEXT_ACTIVE_COLOR = "\ud604\uc7ac \ud3b8\uc9d1"
TEXT_CROSSHAIR_COLOR = "\ud06c\ub85c\uc2a4\ud5e4\uc5b4 \uc0c9\uc0c1"
TEXT_INDICATOR_COLOR = "\uc778\ub514\ucf00\uc774\ud130 \uc0c9\uc0c1"
TEXT_CROSSHAIR = "\ud06c\ub85c\uc2a4\ud5e4\uc5b4"
TEXT_INDICATOR = "\uc778\ub514\ucf00\uc774\ud130"
TEXT_PREVIEW = "\ubbf8\ub9ac\ubcf4\uae30"
TEXT_BACK = "\ub4a4\ub85c\uac00\uae30"
TEXT_PAUSED = "\uc77c\uc2dc\uc815\uc9c0"
TEXT_RESUME = "\uacc4\uc18d\ud558\uae30"
TEXT_RETRY = "\ub2e4\uc2dc\ud558\uae30"
TEXT_MAIN_MENU = "\uba54\uc778 \uba54\ub274\ub85c"
TEXT_QUIT = "\uac8c\uc784 \uc885\ub8cc"
TEXT_DIED = "\uc8fd\uc5c8\uc2b5\ub2c8\ub2e4"
TEXT_FINAL_SCORE = "\ucd5c\uc885 \uc810\uc218"
TEXT_ESC_TO_MENU = "ESC\ub97c \ub20c\ub7ec \uba54\uc778 \ud654\uba74\uc73c\ub85c"
TEXT_HIT = "\uacf5\uaca9\ub2f9\ud588\uc2b5\ub2c8\ub2e4 -10 HP"
TEXT_SINGLE_PLAY = "\uc2f1\uae00 \ud50c\ub808\uc774"
TEXT_INFINITY = "\u221e"
TEXT_HEX = "HEX"
TEXT_RGB = "RGB"
TEXT_HSV = "HSV"
SETTINGS_BG_COLOR = (34, 41, 52)
TEXT_SAVE_DONE = "\uc800\uc7a5\ub418\uc5c8\uc2b5\ub2c8\ub2e4."
TEXT_CONFIRM_UNSAVED = "\ubcc0\uacbd\uc0ac\ud56d\uc744 \uc800\uc7a5\ud558\uc9c0 \uc54a\uc73c\uc168\uc2b5\ub2c8\ub2e4. \uc800\uc7a5\ud558\uc2dc\uaca0\uc2b5\ub2c8\uae4c?"


def build_fonts():
    return {
        'PROG_FONT': pygame.font.SysFont('malgungothic', 30, bold=True),
        'GO_FONT': pygame.font.SysFont('malgungothic', 100, bold=True),
        'DMG_FONT': pygame.font.SysFont('malgungothic', 24, bold=True),
        'ITEM_FONT': pygame.font.SysFont('malgungothic', 20, bold=True),
        'TITLE_FONT': pygame.font.SysFont('malgungothic', 80, bold=True),
        'SMALL_UI_FONT': pygame.font.SysFont('malgungothic', 22, bold=True),
        'INPUT_FONT': pygame.font.SysFont('malgungothic', 32, bold=True),
    }


def create_display(width, height, caption):
    current_win_size = (width, height)
    screen = pygame.display.set_mode(current_win_size, pygame.RESIZABLE)
    virtual_screen = pygame.Surface((width, height))
    pygame.display.set_caption(caption)
    clock = pygame.time.Clock()
    return current_win_size, screen, virtual_screen, clock


def build_background(width, height, fog_color):
    bg_height = height * 2
    bg_surface = pygame.Surface((width, bg_height))
    horizon_y = bg_height // 2

    for y in range(bg_height):
        if y < horizon_y:
            ratio = y / horizon_y
            color = (
                int(10 + fog_color[0] * ratio),
                int(10 + fog_color[1] * ratio),
                int(15 + fog_color[2] * ratio),
            )
        else:
            ratio = (y - horizon_y) / horizon_y
            color = (
                int(fog_color[0] * (1 - ratio) + 50 * ratio),
                int(fog_color[1] * (1 - ratio) + 45 * ratio),
                int(fog_color[2] * (1 - ratio) + 40 * ratio),
            )
        pygame.draw.line(bg_surface, color, (0, y), (width, y))

    return bg_surface


def build_ui_rects(width, height):
    return {
        'sens_minus_btn_rect': pygame.Rect(774, 612, 44, 38),
        'sens_plus_btn_rect': pygame.Rect(830, 612, 44, 38),
        'sens_reset_btn_rect': pygame.Rect(890, 612, 122, 38),
        'pause_sens_minus_btn_rect': pygame.Rect(width // 2 - 130, 220, 40, 40),
        'pause_sens_plus_btn_rect': pygame.Rect(width // 2 + 90, 220, 40, 40),
        'pause_sens_reset_btn_rect': pygame.Rect(width // 2 - 50, 280, 100, 40),
        'pause_settings_btn_rect': pygame.Rect(width // 2 - 150, 466, 300, 45),
        'settings_crosshair_tab_rect': pygame.Rect(78, 124, 176, 44),
        'settings_indicator_tab_rect': pygame.Rect(268, 124, 176, 44),
        'settings_picker_rect': pygame.Rect(78, 184, 560, 286),
        'settings_hue_rect': pygame.Rect(78, 494, 560, 16),
        'settings_color_save_btn_rect': pygame.Rect(740, 612, 140, 38),
        'settings_color_reset_btn_rect': pygame.Rect(896, 612, 140, 38),
        'settings_confirm_save_btn_rect': pygame.Rect(width // 2 - 190, height // 2 + 36, 110, 42),
        'settings_confirm_discard_btn_rect': pygame.Rect(width // 2 - 55, height // 2 + 36, 130, 42),
        'settings_confirm_cancel_btn_rect': pygame.Rect(width // 2 + 100, height // 2 + 36, 110, 42),
        'resume_btn_rect': pygame.Rect(width // 2 - 150, 356, 300, 45),
        'retry_btn_rect': pygame.Rect(width // 2 - 150, 411, 300, 45),
        'mainmenu_btn_rect': pygame.Rect(width // 2 - 150, 521, 300, 45),
        'quit_btn_rect': pygame.Rect(width // 2 - 150, 576, 300, 45),
        'single_btn_rect': pygame.Rect(width // 2 - 175, 260, 350, 60),
        'settings_btn_rect': pygame.Rect(width // 2 - 175, 340, 350, 60),
        'multi_btn_rect': pygame.Rect(-1000, -1000, 0, 0),
        'ip_connect_btn_rect': pygame.Rect(-1000, -1000, 0, 0),
        'ip_back_btn_rect': pygame.Rect(-1000, -1000, 0, 0),
        'ip_input_rect': pygame.Rect(-1000, -1000, 0, 0),
        'main_quit_btn_rect': pygame.Rect(width // 2 - 175, 500, 350, 60),
        'settings_back_btn_rect': pygame.Rect(1062, 612, 130, 38),
    }


def get_virtual_mouse_pos(screen, mouse_x, mouse_y, width, height):
    win_w, win_h = screen.get_size()
    ratio = min(win_w / width, win_h / height)
    scaled_w = int(width * ratio)
    scaled_h = int(height * ratio)
    offset_x = (win_w - scaled_w) // 2
    offset_y = (win_h - scaled_h) // 2
    virtual_x = (mouse_x - offset_x) / ratio
    virtual_y = (mouse_y - offset_y) / ratio
    return virtual_x, virtual_y


def present_scaled_display(screen, virtual_screen, current_win_size, width, height, clear_color):
    screen.fill(clear_color)
    win_w, win_h = current_win_size
    ratio = min(win_w / width, win_h / height)
    scaled_w = int(width * ratio)
    scaled_h = int(height * ratio)
    offset_x = (win_w - scaled_w) // 2
    offset_y = (win_h - scaled_h) // 2
    scaled_screen = pygame.transform.scale(virtual_screen, (scaled_w, scaled_h))
    screen.blit(scaled_screen, (offset_x, offset_y))


def draw_wall(ctx, ray, depth, angle):
    depth *= math.cos(angle - ctx['player_angle'])
    safe_depth = max(1.0, depth)
    wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / safe_depth
    wall_height = min(wall_height, ctx['HEIGHT'] * 4)

    fog_ratio = min(1.0, safe_depth / ctx['MAX_DEPTH'])
    intensity = max(0.0, 1.0 - fog_ratio)
    color = (
        int(ctx['DOOM_WALL_BASE'][0] * intensity + ctx['FOG_COLOR'][0] * (1 - intensity)),
        int(ctx['DOOM_WALL_BASE'][1] * intensity + ctx['FOG_COLOR'][1] * (1 - intensity)),
        int(ctx['DOOM_WALL_BASE'][2] * intensity + ctx['FOG_COLOR'][2] * (1 - intensity)),
    )

    y_start = int(ctx['HEIGHT'] // 2 - wall_height // 2 + ctx['player_pitch'])
    rect_x = int(ray * ctx['SCALE'])
    next_x = int((ray + 1) * ctx['SCALE'])
    rect_w = next_x - rect_x + 2
    pygame.draw.rect(ctx['virtual_screen'], color, (rect_x, y_start, rect_w, int(wall_height)))
    ctx['Z_BUFFER'][ray] = depth


def cast_wall_ray(ctx, ray_angle):
    pos_x = ctx['player_x'] / ctx['TILE_SIZE']
    pos_y = ctx['player_y'] / ctx['TILE_SIZE']
    ray_dir_x = math.cos(ray_angle)
    ray_dir_y = math.sin(ray_angle)

    map_x = int(pos_x)
    map_y = int(pos_y)

    delta_dist_x = float('inf') if abs(ray_dir_x) < 1e-8 else abs(1.0 / ray_dir_x)
    delta_dist_y = float('inf') if abs(ray_dir_y) < 1e-8 else abs(1.0 / ray_dir_y)

    if ray_dir_x < 0:
        step_x = -1
        side_dist_x = (pos_x - map_x) * delta_dist_x
    else:
        step_x = 1
        side_dist_x = (map_x + 1.0 - pos_x) * delta_dist_x

    if ray_dir_y < 0:
        step_y = -1
        side_dist_y = (pos_y - map_y) * delta_dist_y
    else:
        step_y = 1
        side_dist_y = (map_y + 1.0 - pos_y) * delta_dist_y

    hit_side = 0
    max_steps = max(ctx['MAP_W'], ctx['MAP_H']) * 2
    for _ in range(max_steps):
        if side_dist_x < side_dist_y:
            side_dist_x += delta_dist_x
            map_x += step_x
            hit_side = 0
        else:
            side_dist_y += delta_dist_y
            map_y += step_y
            hit_side = 1

        if not (0 <= map_x < ctx['MAP_W'] and 0 <= map_y < ctx['MAP_H']):
            return ctx['MAX_DEPTH'], 0, 0.0

        if ctx['MAP'][map_y][map_x] != 1:
            continue

        if hit_side == 0:
            raw_depth_tiles = side_dist_x - delta_dist_x
            hit_coord = pos_y + raw_depth_tiles * ray_dir_y
        else:
            raw_depth_tiles = side_dist_y - delta_dist_y
            hit_coord = pos_x + raw_depth_tiles * ray_dir_x

        raw_depth = raw_depth_tiles * ctx['TILE_SIZE']
        wall_u = hit_coord - math.floor(hit_coord)
        return raw_depth, hit_side, wall_u

    return ctx['MAX_DEPTH'], 0, 0.0


def draw_wall_column(ctx, ray, depth, angle, hit_side=0, wall_u=0.0):
    corrected_depth = depth * math.cos(angle - ctx['player_angle'])
    safe_depth = max(1.0, corrected_depth)
    wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / safe_depth
    wall_height = min(wall_height, ctx['HEIGHT'] * 4)

    fog_ratio = min(1.0, safe_depth / ctx['MAX_DEPTH'])
    intensity = max(0.0, 1.0 - fog_ratio)
    side_shade = 0.82 if hit_side else 1.0
    stripe = 0.88 + (0.12 * abs(math.sin(wall_u * math.pi * 6.0)))
    brightness = side_shade * stripe
    color = (
        int((ctx['DOOM_WALL_BASE'][0] * brightness) * intensity + ctx['FOG_COLOR'][0] * (1 - intensity)),
        int((ctx['DOOM_WALL_BASE'][1] * brightness) * intensity + ctx['FOG_COLOR'][1] * (1 - intensity)),
        int((ctx['DOOM_WALL_BASE'][2] * brightness) * intensity + ctx['FOG_COLOR'][2] * (1 - intensity)),
    )

    y_start = int(ctx['HEIGHT'] // 2 - wall_height // 2 + ctx['player_pitch'])
    rect_x = int(ray * ctx['SCALE'])
    next_x = int((ray + 1) * ctx['SCALE'])
    rect_w = next_x - rect_x + 2
    pygame.draw.rect(ctx['virtual_screen'], color, (rect_x, y_start, rect_w, int(wall_height)))

    if wall_height > 24:
        edge_color = (
            min(255, color[0] + 12),
            min(255, color[1] + 10),
            min(255, color[2] + 8),
        )
        pygame.draw.line(
            ctx['virtual_screen'],
            edge_color,
            (rect_x, y_start),
            (rect_x + rect_w - 1, y_start),
            1,
        )

    ctx['Z_BUFFER'][ray] = corrected_depth


def build_wall_segments(ctx):
    segments = []
    game_map = ctx['MAP']
    map_w = ctx['MAP_W']
    map_h = ctx['MAP_H']
    tile_size = ctx['TILE_SIZE']

    for grid_y in range(map_h):
        for grid_x in range(map_w):
            if game_map[grid_y][grid_x] != 1:
                continue

            world_x = grid_x * tile_size
            world_y = grid_y * tile_size

            if grid_y == 0 or game_map[grid_y - 1][grid_x] == 0:
                segments.append((world_x, world_y, world_x + tile_size, world_y, 0.98))
            if grid_y == map_h - 1 or game_map[grid_y + 1][grid_x] == 0:
                segments.append((world_x + tile_size, world_y + tile_size, world_x, world_y + tile_size, 0.80))
            if grid_x == 0 or game_map[grid_y][grid_x - 1] == 0:
                segments.append((world_x, world_y + tile_size, world_x, world_y, 0.88))
            if grid_x == map_w - 1 or game_map[grid_y][grid_x + 1] == 0:
                segments.append((world_x + tile_size, world_y, world_x + tile_size, world_y + tile_size, 0.72))

    return segments


def get_wall_segments(ctx):
    map_signature = (id(ctx['MAP']), ctx['MAP_W'], ctx['MAP_H'])
    if ctx.get('_wall_segments_signature') != map_signature:
        ctx['_wall_segments_cache'] = build_wall_segments(ctx)
        ctx['_wall_segments_signature'] = map_signature
    return ctx['_wall_segments_cache']


def clip_camera_segment(cam_x1, depth1, cam_x2, depth2, near_plane):
    if depth1 <= near_plane and depth2 <= near_plane:
        return None

    if depth1 <= near_plane:
        orig_cam_x1 = cam_x1
        orig_depth1 = depth1
        interp = (near_plane - orig_depth1) / max(1e-8, depth2 - orig_depth1)
        cam_x1 = orig_cam_x1 + (cam_x2 - orig_cam_x1) * interp
        depth1 = near_plane
    if depth2 <= near_plane:
        orig_cam_x2 = cam_x2
        orig_depth2 = depth2
        interp = (near_plane - depth1) / max(1e-8, orig_depth2 - depth1)
        cam_x2 = cam_x1 + (orig_cam_x2 - cam_x1) * interp
        depth2 = near_plane

    return cam_x1, depth1, cam_x2, depth2


def project_wall_segment(ctx, segment):
    x1, y1, x2, y2, shade = segment
    sin_a = math.sin(ctx['player_angle'])
    cos_a = math.cos(ctx['player_angle'])

    dx1 = x1 - ctx['player_x']
    dy1 = y1 - ctx['player_y']
    dx2 = x2 - ctx['player_x']
    dy2 = y2 - ctx['player_y']

    cam_x1 = (-sin_a * dx1) + (cos_a * dy1)
    depth1 = (cos_a * dx1) + (sin_a * dy1)
    cam_x2 = (-sin_a * dx2) + (cos_a * dy2)
    depth2 = (cos_a * dx2) + (sin_a * dy2)

    clipped = clip_camera_segment(cam_x1, depth1, cam_x2, depth2, 4.0)
    if clipped is None:
        return None
    cam_x1, depth1, cam_x2, depth2 = clipped

    screen_x1 = ctx['WIDTH'] / 2 + (cam_x1 / depth1) * ctx['current_proj_dist']
    screen_x2 = ctx['WIDTH'] / 2 + (cam_x2 / depth2) * ctx['current_proj_dist']

    if max(screen_x1, screen_x2) < -8 or min(screen_x1, screen_x2) > ctx['WIDTH'] + 8:
        return None

    wall_height1 = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / max(1.0, depth1)
    wall_height2 = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / max(1.0, depth2)
    top1 = ctx['HEIGHT'] / 2 - wall_height1 / 2 + ctx['player_pitch']
    bottom1 = top1 + wall_height1
    top2 = ctx['HEIGHT'] / 2 - wall_height2 / 2 + ctx['player_pitch']
    bottom2 = top2 + wall_height2

    avg_depth = (depth1 + depth2) * 0.5
    fog_ratio = min(1.0, avg_depth / ctx['MAX_DEPTH'])
    intensity = max(0.0, 1.0 - fog_ratio)
    stripe = 0.92 + 0.08 * abs(math.sin((x1 + y1 + x2 + y2) * 0.015625))
    brightness = shade * stripe
    color = (
        int((ctx['DOOM_WALL_BASE'][0] * brightness) * intensity + ctx['FOG_COLOR'][0] * (1 - intensity)),
        int((ctx['DOOM_WALL_BASE'][1] * brightness) * intensity + ctx['FOG_COLOR'][1] * (1 - intensity)),
        int((ctx['DOOM_WALL_BASE'][2] * brightness) * intensity + ctx['FOG_COLOR'][2] * (1 - intensity)),
    )

    polygon = [
        (screen_x1, top1),
        (screen_x2, top2),
        (screen_x2, bottom2),
        (screen_x1, bottom1),
    ]
    return {
        'polygon': polygon,
        'color': color,
        'screen_x1': screen_x1,
        'screen_x2': screen_x2,
        'depth1': depth1,
        'depth2': depth2,
        'avg_depth': avg_depth,
    }


def update_wall_depth_buffer(ctx, wall_projection):
    screen_x1 = wall_projection['screen_x1']
    screen_x2 = wall_projection['screen_x2']
    depth1 = wall_projection['depth1']
    depth2 = wall_projection['depth2']

    if abs(screen_x2 - screen_x1) < 1e-5:
        ray = int(((screen_x1 / ctx['WIDTH']) * ctx['CASTED_RAYS']))
        if 0 <= ray < ctx['CASTED_RAYS']:
            ctx['Z_BUFFER'][ray] = min(ctx['Z_BUFFER'][ray], min(depth1, depth2))
        return

    screen_left = max(0.0, min(screen_x1, screen_x2))
    screen_right = min(float(ctx['WIDTH'] - 1), max(screen_x1, screen_x2))
    start_ray = max(0, int(screen_left / ctx['SCALE']))
    end_ray = min(ctx['CASTED_RAYS'] - 1, int(screen_right / ctx['SCALE']))

    inv_depth1 = 1.0 / max(1.0, depth1)
    inv_depth2 = 1.0 / max(1.0, depth2)
    for ray in range(start_ray, end_ray + 1):
        sample_x = (ray + 0.5) * ctx['SCALE']
        interp = (sample_x - screen_x1) / (screen_x2 - screen_x1)
        interp = max(0.0, min(1.0, interp))
        inv_depth = (inv_depth1 * (1.0 - interp)) + (inv_depth2 * interp)
        if inv_depth <= 0:
            continue
        depth = 1.0 / inv_depth
        ctx['Z_BUFFER'][ray] = min(ctx['Z_BUFFER'][ray], depth)


def render_projected_walls(ctx):
    ctx['Z_BUFFER'] = [ctx['MAX_DEPTH']] * ctx['CASTED_RAYS']
    visible_walls = []
    for segment in get_wall_segments(ctx):
        projection = project_wall_segment(ctx, segment)
        if projection is not None:
            visible_walls.append(projection)

    visible_walls.sort(key=lambda wall: wall['avg_depth'], reverse=True)

    for wall in visible_walls:
        pygame.draw.polygon(ctx['virtual_screen'], wall['color'], wall['polygon'])
        top_left = wall['polygon'][0]
        top_right = wall['polygon'][1]
        pygame.draw.line(ctx['virtual_screen'], tuple(min(255, channel + 10) for channel in wall['color']), top_left, top_right, 1)
        update_wall_depth_buffer(ctx, wall)


def render_dda_walls(ctx):
    ctx['Z_BUFFER'] = [ctx['MAX_DEPTH']] * ctx['CASTED_RAYS']
    start_angle = ctx['player_angle'] - (ctx['current_fov'] / 2)

    for ray in range(ctx['CASTED_RAYS']):
        ray_angle = start_angle + ray * ctx['STEP_ANGLE']
        depth, hit_side, wall_u = cast_wall_ray(ctx, ray_angle)
        draw_wall_column(ctx, ray, depth, ray_angle, hit_side, wall_u)


def draw_bullet_holes(ctx):
    for hole in ctx['bullet_holes'][:]:
        if ctx['game_state'] == ctx['STATE_PLAYING']:
            hole['life'] -= 1 * ctx['time_scale']
            if hole['life'] <= 0:
                ctx['bullet_holes'].remove(hole)
                continue

        dx = hole['x'] - ctx['player_x']
        dy = hole['y'] - ctx['player_y']
        dist = math.hypot(dx, dy)
        angle_diff = math.atan2(dy, dx) - ctx['player_angle']

        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi

        if abs(angle_diff) >= ctx['current_fov'] / 2 or dist <= 1:
            continue

        screen_x = (ctx['WIDTH'] / 2) + (angle_diff / (ctx['current_fov'] / 2)) * (ctx['WIDTH'] / 2)
        wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / dist
        screen_y = ctx['HEIGHT'] // 2 - wall_height * hole['ratio'] + ctx['player_pitch']
        size = max(2, int(150 / dist))
        alpha = min(255, int((max(0, hole['life']) / 300) * 255))

        surface = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        pygame.draw.circle(surface, (20, 20, 20, alpha), (size, size), size)
        pygame.draw.circle(surface, (0, 0, 0, alpha), (size, size), size * 0.5)
        ctx['virtual_screen'].blit(surface, (screen_x - size, screen_y - size))


def draw_damage_texts(ctx):
    for damage_text in ctx['damage_texts'][:]:
        if ctx['game_state'] == ctx['STATE_PLAYING']:
            damage_text['life'] -= 1 * ctx['time_scale']
            damage_text['y'] -= 1 * ctx['time_scale']
            if damage_text['life'] <= 0:
                ctx['damage_texts'].remove(damage_text)
                continue

        text_surface = ctx['DMG_FONT'].render(damage_text['text'], True, damage_text['color'])
        text_surface.set_alpha(min(255, max(0, int(damage_text['life'] * 8))))
        ctx['virtual_screen'].blit(
            text_surface,
            (damage_text['x'] - text_surface.get_width() // 2, damage_text['y']),
        )


def draw_minimap(ctx):
    margin = 20
    tile_size = 5
    map_w = ctx['MAP_W'] * tile_size
    map_h = ctx['MAP_H'] * tile_size
    start_x = ctx['WIDTH'] - map_w - margin
    start_y = margin

    minimap_signature = (id(ctx['MAP']), ctx['MAP_W'], ctx['MAP_H'], tile_size)
    if ctx.get('_minimap_signature') != minimap_signature:
        minimap_surface = pygame.Surface((map_w, map_h), pygame.SRCALPHA)
        minimap_surface.fill((0, 0, 0, 150))
        for y, row in enumerate(ctx['MAP']):
            for x, tile in enumerate(row):
                if tile == 1:
                    pygame.draw.rect(
                        minimap_surface,
                        ctx['GRAY'],
                        (x * tile_size, y * tile_size, tile_size, tile_size),
                    )
        ctx['_minimap_surface'] = minimap_surface
        ctx['_minimap_signature'] = minimap_signature

    ctx['virtual_screen'].blit(ctx['_minimap_surface'], (start_x, start_y))

    player_map_x = int((ctx['player_x'] / ctx['TILE_SIZE']) * tile_size)
    player_map_y = int((ctx['player_y'] / ctx['TILE_SIZE']) * tile_size)
    pygame.draw.circle(
        ctx['virtual_screen'],
        ctx['GREEN'],
        (start_x + player_map_x, start_y + player_map_y),
        tile_size // 2,
    )

    view_x = player_map_x + math.cos(ctx['player_angle']) * (tile_size * 2)
    view_y = player_map_y + math.sin(ctx['player_angle']) * (tile_size * 2)
    pygame.draw.line(
        ctx['virtual_screen'],
        ctx['GREEN'],
        (start_x + player_map_x, start_y + player_map_y),
        (start_x + view_x, start_y + view_y),
        1,
    )

    for enemy in ctx['enemies']:
        if enemy['dead']:
            continue
        enemy_map_x = int((enemy['x'] / ctx['TILE_SIZE']) * tile_size)
        enemy_map_y = int((enemy['y'] / ctx['TILE_SIZE']) * tile_size)
        pygame.draw.circle(
            ctx['virtual_screen'],
            ctx['RED'],
            (start_x + enemy_map_x, start_y + enemy_map_y),
            max(1, tile_size // 3),
        )

    for item in ctx['items']:
        item_map_x = int((item['x'] / ctx['TILE_SIZE']) * tile_size)
        item_map_y = int((item['y'] / ctx['TILE_SIZE']) * tile_size)
        if 'ak' in item['type']:
            color = ctx['YELLOW']
        elif 'shotgun' in item['type']:
            color = ctx['WHITE']
        else:
            color = ctx['GREEN']
        pygame.draw.circle(
            ctx['virtual_screen'],
            color,
            (start_x + item_map_x, start_y + item_map_y),
            max(1, tile_size // 3),
        )


def draw_button(ctx, rect, label, fill_color, border_color=None, text_color=None, font_key='PROG_FONT'):
    border_color = border_color or ctx['WHITE']
    text_color = text_color or ctx['WHITE']
    pygame.draw.rect(ctx['virtual_screen'], fill_color, rect, border_radius=10)
    pygame.draw.rect(ctx['virtual_screen'], border_color, rect, 3, border_radius=10)
    text_rect = rect.inflate(-24, -12)
    blit_text_in_rect(
        ctx,
        text_rect,
        label,
        text_color,
        font_key=font_key,
        align='center',
        valign='center',
    )


def draw_panel(ctx, rect):
    panel_surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    panel_surface.fill((8, 10, 14, 205))
    ctx['virtual_screen'].blit(panel_surface, rect.topleft)
    pygame.draw.rect(ctx['virtual_screen'], (82, 86, 94), rect, 2, border_radius=16)


def format_rgb_text(color):
    return f"RGB ({color[0]}, {color[1]}, {color[2]})"


def scale_surface_to_fit(surface, max_width, max_height):
    if max_width <= 0 or max_height <= 0:
        return surface

    width = max(1, surface.get_width())
    height = max(1, surface.get_height())
    scale = min(1.0, max_width / width, max_height / height)
    if scale >= 1.0:
        return surface

    scaled_size = (
        max(1, int(width * scale)),
        max(1, int(height * scale)),
    )
    return pygame.transform.smoothscale(surface, scaled_size)


def clamp_rect_inside(parent_rect, child_rect, padding=0):
    inner_rect = parent_rect.inflate(-padding * 2, -padding * 2)
    rect = child_rect.copy()

    if rect.width > inner_rect.width:
        rect.width = inner_rect.width
    if rect.height > inner_rect.height:
        rect.height = inner_rect.height

    if rect.left < inner_rect.left:
        rect.left = inner_rect.left
    if rect.top < inner_rect.top:
        rect.top = inner_rect.top
    if rect.right > inner_rect.right:
        rect.right = inner_rect.right
    if rect.bottom > inner_rect.bottom:
        rect.bottom = inner_rect.bottom

    return rect


def render_text_surface(font, text, color, max_width, max_height, wrap=False, line_gap=4):
    text_surface = font.render(text, True, color)
    return scale_surface_to_fit(text_surface, max_width, max_height)


def blit_text_in_rect(ctx, rect, text, color, font_key='PROG_FONT', align='left', valign='top', wrap=False, line_gap=4):
    surface = render_text_surface(
        ctx[font_key],
        text,
        color,
        rect.width,
        rect.height,
        wrap=wrap,
        line_gap=line_gap,
    )

    if align == 'center':
        x = rect.centerx - surface.get_width() // 2
    elif align == 'right':
        x = rect.right - surface.get_width()
    else:
        x = rect.x

    if valign == 'center':
        y = rect.centery - surface.get_height() // 2
    elif valign == 'bottom':
        y = rect.bottom - surface.get_height()
    else:
        y = rect.y

    ctx['virtual_screen'].blit(surface, (x, y))


def draw_info_box(ctx, rect, title, value, accent_color):
    draw_panel(ctx, rect)
    title_rect = pygame.Rect(rect.x + 16, rect.y + 8, rect.width - 32, 16)
    value_rect = pygame.Rect(rect.x + 16, rect.y + 26, rect.width - 32, rect.height - 34)
    blit_text_in_rect(ctx, title_rect, title, ctx['LIGHT_GRAY'], font_key='ITEM_FONT')
    blit_text_in_rect(
        ctx,
        value_rect,
        value,
        accent_color,
        font_key='DMG_FONT',
        valign='center',
    )


def draw_picker_tab(ctx, rect, label, color, is_active, preview_kind):
    fill_color = (34, 36, 44) if is_active else (20, 22, 28)
    border_color = color if is_active else (82, 86, 94)
    text_color = ctx['WHITE'] if is_active else ctx['LIGHT_GRAY']
    pygame.draw.rect(ctx['virtual_screen'], fill_color, rect, border_radius=12)
    pygame.draw.rect(ctx['virtual_screen'], border_color, rect, 3 if is_active else 2, border_radius=12)

    if preview_kind == 'crosshair':
        preview_center = (rect.x + 24, rect.centery)
        pygame.draw.circle(ctx['virtual_screen'], (26, 28, 36), preview_center, 13)
        pygame.draw.line(ctx['virtual_screen'], color, (preview_center[0] - 7, preview_center[1]), (preview_center[0] + 7, preview_center[1]), 2)
        pygame.draw.line(ctx['virtual_screen'], color, (preview_center[0], preview_center[1] - 7), (preview_center[0], preview_center[1] + 7), 2)
    else:
        preview_center = (rect.x + 24, rect.centery)
        preview_arc_rect = pygame.Rect(preview_center[0] - 12, preview_center[1] - 12, 24, 24)
        pygame.draw.circle(ctx['virtual_screen'], (26, 28, 36), preview_center, 13)
        pygame.draw.arc(ctx['virtual_screen'], tuple(max(18, int(channel * 0.35)) for channel in color), preview_arc_rect, 0.75, 2.4, 4)
        pygame.draw.arc(ctx['virtual_screen'], color, preview_arc_rect, 0.75, 2.4, 3)

    text_rect = pygame.Rect(rect.x + 46, rect.y + 6, rect.width - 58, rect.height - 12)
    blit_text_in_rect(
        ctx,
        text_rect,
        label,
        text_color,
        font_key='DMG_FONT',
        valign='center',
    )


def draw_hue_bar(ctx, rect):
    for x in range(rect.width):
        hue = x / max(1, rect.width - 1)
        rgb = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
        color = (int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255))
        pygame.draw.line(
            ctx['virtual_screen'],
            color,
            (rect.x + x, rect.y),
            (rect.x + x, rect.bottom - 1),
        )
    pygame.draw.rect(ctx['virtual_screen'], ctx['WHITE'], rect, 2, border_radius=8)


def draw_sv_picker(ctx, rect, hue):
    pure_rgb = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
    pure_color = (int(pure_rgb[0] * 255), int(pure_rgb[1] * 255), int(pure_rgb[2] * 255))

    picker_surface = pygame.Surface((rect.width, rect.height))
    for x in range(rect.width):
        ratio = x / max(1, rect.width - 1)
        color = (
            int(255 + (pure_color[0] - 255) * ratio),
            int(255 + (pure_color[1] - 255) * ratio),
            int(255 + (pure_color[2] - 255) * ratio),
        )
        pygame.draw.line(picker_surface, color, (x, 0), (x, rect.height - 1))

    shadow_surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    for y in range(rect.height):
        alpha = int((y / max(1, rect.height - 1)) * 255)
        pygame.draw.line(shadow_surface, (0, 0, 0, alpha), (0, y), (rect.width - 1, y))

    picker_surface.blit(shadow_surface, (0, 0))
    ctx['virtual_screen'].blit(picker_surface, rect.topleft)
    pygame.draw.rect(ctx['virtual_screen'], ctx['WHITE'], rect, 2, border_radius=14)


def draw_crosshair(ctx, center_x, center_y, size=10):
    if ctx['current_weapon'] == ctx['WEAPON_SHOTGUN']:
        pygame.draw.circle(ctx['virtual_screen'], ctx['crosshair_color'], (center_x, center_y), 20, 2)
        pygame.draw.circle(ctx['virtual_screen'], ctx['crosshair_color'], (center_x, center_y), 2)
        return

    pygame.draw.line(
        ctx['virtual_screen'],
        ctx['crosshair_color'],
        (center_x - size, center_y),
        (center_x + size, center_y),
        2,
    )
    pygame.draw.line(
        ctx['virtual_screen'],
        ctx['crosshair_color'],
        (center_x, center_y - size),
        (center_x, center_y + size),
        2,
    )


def draw_hit_indicators(ctx, center_x, center_y):
    current_time = pygame.time.get_ticks()
    indicator_life_ms = 2000
    arc_radius = 40
    arc_width = 5
    arc_outline_width = arc_width + 4

    for enemy_id, hit_time_ms in list(ctx['last_hit_enemies'].items()):
        if current_time - hit_time_ms >= indicator_life_ms:
            ctx['last_hit_enemies'].pop(enemy_id, None)
            continue

        hit_enemy = next(
            (
                enemy
                for enemy in ctx['enemies']
                if not enemy.get('dead') and enemy.get('id') == enemy_id
            ),
            None,
        )
        if hit_enemy is None:
            ctx['last_hit_enemies'].pop(enemy_id, None)
            continue

        dx = hit_enemy['x'] - ctx['player_x']
        dy = hit_enemy['y'] - ctx['player_y']
        world_angle = math.atan2(dy, dx)
        angle_diff = world_angle - ctx['player_angle']

        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi

        pygame_angle = -angle_diff + (math.pi / 2)
        start_angle = pygame_angle - 0.35
        end_angle = pygame_angle + 0.35
        arc_rect = pygame.Rect(center_x - arc_radius, center_y - arc_radius, arc_radius * 2, arc_radius * 2)
        pygame.draw.arc(
            ctx['virtual_screen'],
            ctx['indicator_outline_color'],
            arc_rect,
            start_angle,
            end_angle,
            arc_outline_width,
        )
        pygame.draw.arc(
            ctx['virtual_screen'],
            ctx['indicator_color'],
            arc_rect,
            start_angle,
            end_angle,
            arc_width,
        )


def draw_ui(ctx):
    current_time = pygame.time.get_ticks()
    ui_start_x = 20
    ui_start_y = ctx['HEIGHT'] - 52
    weapon_names = [
        f"[1] {TEXT_PISTOL}",
        "[2] AK-47" if ctx['has_ak'] else "[2] None",
        f"[3] {TEXT_SHOTGUN}" if ctx['has_shotgun'] else "[3] None",
    ]

    for index, weapon_name in enumerate(weapon_names):
        is_current = ctx['current_weapon'] == index
        bg_color = (60, 100, 60) if is_current else (40, 40, 40)
        text_color = ctx['WHITE'] if is_current else (150, 150, 150)
        border_color = (100, 255, 100) if is_current else (80, 80, 80)

        if index == 1 and not ctx['has_ak']:
            text_color = ctx['RED']
        if index == 2 and not ctx['has_shotgun']:
            text_color = ctx['RED']

        weapon_surface = ctx['SMALL_UI_FONT'].render(weapon_name, True, text_color)
        box_rect = pygame.Rect(ui_start_x + (index * 120), ui_start_y, 110, 40)
        pygame.draw.rect(ctx['virtual_screen'], bg_color, box_rect, border_radius=6)
        pygame.draw.rect(ctx['virtual_screen'], border_color, box_rect, 2, border_radius=6)
        ctx['virtual_screen'].blit(
            weapon_surface,
            (
                box_rect.centerx - weapon_surface.get_width() // 2,
                box_rect.centery - weapon_surface.get_height() // 2,
            ),
        )

    bar_w = 300
    bar_h = 12
    bar_x = ctx['WIDTH'] // 2 - bar_w // 2

    stamina_y = ctx['HEIGHT'] - 30
    stamina_ratio = max(0, ctx['player_stamina']) / ctx['PLAYER_MAX_STAMINA']
    pygame.draw.rect(ctx['virtual_screen'], (50, 50, 50), (bar_x, stamina_y, bar_w, bar_h))
    pygame.draw.rect(
        ctx['virtual_screen'],
        (100, 200, 255),
        (bar_x, stamina_y, int(bar_w * stamina_ratio), bar_h),
    )
    pygame.draw.rect(ctx['virtual_screen'], ctx['WHITE'], (bar_x, stamina_y, bar_w, bar_h), 1)

    hp_y = stamina_y - bar_h - 6
    hp_ratio = max(0, ctx['player_health']) / ctx['PLAYER_MAX_HEALTH']
    hp_color = (100, 255, 100)
    pygame.draw.rect(ctx['virtual_screen'], (50, 50, 50), (bar_x, hp_y, bar_w, bar_h))
    pygame.draw.rect(ctx['virtual_screen'], hp_color, (bar_x, hp_y, int(bar_w * hp_ratio), bar_h))
    pygame.draw.rect(ctx['virtual_screen'], ctx['WHITE'], (bar_x, hp_y, bar_w, bar_h), 1)

    score_text = ctx['PROG_FONT'].render(f"{TEXT_SCORE}: {ctx['current_score']}", True, ctx['WHITE'])
    health_text = ctx['PROG_FONT'].render(f"{TEXT_HEALTH}: {int(max(0, ctx['player_health']))}", True, hp_color)
    melee_text = ctx['SMALL_UI_FONT'].render(TEXT_MELEE, True, ctx['WHITE'])
    grenade_color = ctx['YELLOW'] if ctx['grenade_ready'] else ctx['WHITE']
    grenade_suffix = f" {TEXT_GRENADE_READY}" if ctx['grenade_ready'] else ""
    grenade_text = ctx['SMALL_UI_FONT'].render(
        f"{TEXT_GRENADE} {ctx['grenade_count']}{grenade_suffix}",
        True,
        grenade_color,
    )
    remaining_kills = ctx['GRENADE_REWARD_KILLS'] - (ctx['enemies_killed'] % ctx['GRENADE_REWARD_KILLS'])
    next_grenade_text = ctx['ITEM_FONT'].render(
        f"{TEXT_NEXT_GRENADE}: {remaining_kills}\ud0ac",
        True,
        ctx['LIGHT_GRAY'],
    )

    utility_x = 20
    utility_base_y = ctx['HEIGHT'] - 130
    utility_surfaces = [health_text, melee_text, grenade_text, next_grenade_text]
    utility_spacings = [10, 10, 10]
    utility_positions = []
    current_y = utility_base_y

    for index, surface in enumerate(utility_surfaces):
        utility_positions.append(current_y)
        if index < len(utility_spacings):
            current_y += surface.get_height() + utility_spacings[index]

    last_line_limit = ctx['HEIGHT'] - 110
    if utility_positions[-1] > last_line_limit:
        shift_up = utility_positions[-1] - last_line_limit
        utility_positions = [y - shift_up for y in utility_positions]

    panel_top = utility_positions[0] - 10
    panel_bottom = utility_positions[-1] + utility_surfaces[-1].get_height() + 10
    panel_width = max(surface.get_width() for surface in utility_surfaces) + 5
    panel_rect = pygame.Rect(utility_x - 8, panel_top, panel_width + 16, panel_bottom - panel_top)
    panel_surface = pygame.Surface((panel_rect.width, panel_rect.height), pygame.SRCALPHA)
    panel_surface.fill((8, 10, 14, 160))
    ctx['virtual_screen'].blit(panel_surface, panel_rect.topleft)
    pygame.draw.rect(ctx['virtual_screen'], (82, 86, 94), panel_rect, 2, border_radius=10)

    ctx['virtual_screen'].blit(score_text, (20, 20))
    for surface, text_y in zip(utility_surfaces, utility_positions):
        ctx['virtual_screen'].blit(surface, (utility_x, text_y))

    if ctx['is_reloading']:
        time_left = max(0.0, (ctx['reload_end'] - current_time) / 1000.0)
        ammo_text = ctx['PROG_FONT'].render(f"{TEXT_RELOADING} {time_left:.1f}\ucd08", True, ctx['YELLOW'])
    elif ctx['current_weapon'] == ctx['WEAPON_PISTOL']:
        ammo_text = ctx['PROG_FONT'].render(
            f"{TEXT_AMMO}: {ctx['current_pistol_ammo']} / {TEXT_INFINITY}",
            True,
            ctx['WHITE'],
        )
    elif ctx['current_weapon'] == ctx['WEAPON_AK']:
        ammo_text = ctx['PROG_FONT'].render(
            f"{TEXT_AMMO}: {ctx['current_ak_ammo']} / {ctx['ak_reserve_ammo']}",
            True,
            ctx['YELLOW'],
        )
    else:
        ammo_text = ctx['PROG_FONT'].render(
            f"{TEXT_AMMO}: {ctx['current_shotgun_ammo']} / {ctx['shotgun_reserve_ammo']}",
            True,
            ctx['BROWN'],
        )
    ctx['virtual_screen'].blit(ammo_text, (ctx['WIDTH'] - 250, ctx['HEIGHT'] - 40))

    center_x = ctx['WIDTH'] // 2
    center_y = ctx['HEIGHT'] // 2
    draw_hit_indicators(ctx, center_x, center_y)
    draw_crosshair(ctx, center_x, center_y)

    if ctx['grenade_ready']:
        cook_seconds = max(0.0, ctx['grenade_cook_fuse'] / 60.0)
        cook_color = ctx['RED'] if cook_seconds <= 1.5 else ctx['YELLOW']
        cook_text = ctx['ITEM_FONT'].render(f"{cook_seconds:.1f}\ucd08", True, cook_color)
        cook_text.set_alpha(120)
        ctx['virtual_screen'].blit(
            cook_text,
            (center_x - cook_text.get_width() // 2, center_y + 24),
        )
    elif ctx['grenades']:
        min_fuse = min(grenade.get('fuse', ctx['GRENADE_FUSE_FRAMES']) for grenade in ctx['grenades'])
        explosion_seconds = max(0.0, min_fuse / 60.0)
        explosion_color = ctx['RED'] if explosion_seconds <= 1.5 else ctx['YELLOW']
        explosion_text = ctx['ITEM_FONT'].render(
            f"{TEXT_EXPLOSION}: {explosion_seconds:.1f}\ucd08",
            True,
            explosion_color,
        )
        explosion_text.set_alpha(120)
        ctx['virtual_screen'].blit(
            explosion_text,
            (center_x - explosion_text.get_width() // 2, center_y + 24),
        )

    for index, notice in enumerate(ctx['pickup_notices']):
        notice_surface = ctx['SMALL_UI_FONT'].render(notice['text'], True, notice['color'])
        notice_surface.set_alpha(min(255, max(0, int(notice['timer'] * 10))))
        ctx['virtual_screen'].blit(
            notice_surface,
            (ctx['WIDTH'] - notice_surface.get_width() - 20, ctx['HEIGHT'] // 2 + index * 30),
        )


def draw_settings_screen(ctx):
    ctx['virtual_screen'].fill(SETTINGS_BG_COLOR)

    blit_text_in_rect(
        ctx,
        pygame.Rect(60, 24, 220, 40),
        TEXT_SETTINGS,
        ctx['WHITE'],
        font_key='PROG_FONT',
    )
    blit_text_in_rect(
        ctx,
        pygame.Rect(60, 64, 560, 26),
        "\uc0c9\uc0c1\ud310\uacfc hue \ubc14\ub97c \ud074\ub9ad\ud558\uac70\ub098 \ub4dc\ub798\uadf8\ud574\uc11c \uc0c9\uc744 \uc120\ud0dd\ud558\uc138\uc694",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )
    picker_shell_rect = pygame.Rect(48, 104, 620, 430)
    side_panel_rect = pygame.Rect(684, 104, 548, 430)
    footer_panel_rect = pygame.Rect(48, 556, 1184, 122)
    footer_info_rect = pygame.Rect(70, 576, 604, 82)
    footer_actions_rect = pygame.Rect(694, 576, 516, 82)
    draw_panel(ctx, picker_shell_rect)
    draw_panel(ctx, side_panel_rect)
    draw_panel(ctx, footer_panel_rect)
    draw_panel(ctx, footer_info_rect)
    draw_panel(ctx, footer_actions_rect)
    side_inner_rect = side_panel_rect.inflate(-28 * 2, -24 * 2)
    footer_info_inner_rect = footer_info_rect.inflate(-18 * 2, -12 * 2)
    footer_actions_inner_rect = footer_actions_rect.inflate(-18 * 2, -12 * 2)

    active_label = TEXT_CROSSHAIR if ctx['settings_active_color'] == 'crosshair' else TEXT_INDICATOR
    active_color = ctx['settings_preview_crosshair_color'] if ctx['settings_active_color'] == 'crosshair' else ctx['settings_preview_indicator_color']
    active_hsv = ctx['crosshair_color_hsv'] if ctx['settings_active_color'] == 'crosshair' else ctx['indicator_color_hsv']
    active_hex = f"#{active_color[0]:02x}{active_color[1]:02x}{active_color[2]:02x}"
    active_hsv_text = (
        f"{round(active_hsv[0] * 360)}\u00b0, "
        f"{round(active_hsv[1] * 100)}%, "
        f"{round(active_hsv[2] * 100)}%"
    )

    draw_picker_tab(
        ctx,
        ctx['settings_crosshair_tab_rect'],
        TEXT_CROSSHAIR,
        ctx['settings_preview_crosshair_color'],
        ctx['settings_active_color'] == 'crosshair',
        'crosshair',
    )
    draw_picker_tab(
        ctx,
        ctx['settings_indicator_tab_rect'],
        TEXT_INDICATOR,
        ctx['settings_preview_indicator_color'],
        ctx['settings_active_color'] == 'indicator',
        'indicator',
    )

    draw_sv_picker(ctx, ctx['settings_picker_rect'], active_hsv[0])
    draw_hue_bar(ctx, ctx['settings_hue_rect'])

    picker_cursor_x = ctx['settings_picker_rect'].x + int(active_hsv[1] * ctx['settings_picker_rect'].width)
    picker_cursor_y = ctx['settings_picker_rect'].y + int((1.0 - active_hsv[2]) * ctx['settings_picker_rect'].height)
    picker_cursor_x = max(ctx['settings_picker_rect'].left, min(ctx['settings_picker_rect'].right, picker_cursor_x))
    picker_cursor_y = max(ctx['settings_picker_rect'].top, min(ctx['settings_picker_rect'].bottom, picker_cursor_y))
    pygame.draw.circle(ctx['virtual_screen'], ctx['WHITE'], (picker_cursor_x, picker_cursor_y), 12, 3)
    pygame.draw.circle(ctx['virtual_screen'], (16, 18, 22), (picker_cursor_x, picker_cursor_y), 8, 2)

    hue_cursor_x = ctx['settings_hue_rect'].x + int(active_hsv[0] * ctx['settings_hue_rect'].width)
    hue_cursor_x = max(ctx['settings_hue_rect'].left, min(ctx['settings_hue_rect'].right, hue_cursor_x))
    pygame.draw.circle(ctx['virtual_screen'], ctx['WHITE'], (hue_cursor_x, ctx['settings_hue_rect'].centery), 11, 3)
    pygame.draw.circle(ctx['virtual_screen'], (16, 18, 22), (hue_cursor_x, ctx['settings_hue_rect'].centery), 7)

    blit_text_in_rect(
        ctx,
        pygame.Rect(side_inner_rect.x, side_panel_rect.y + 20, 180, 40),
        TEXT_PREVIEW,
        ctx['WHITE'],
        font_key='PROG_FONT',
    )
    blit_text_in_rect(
        ctx,
        pygame.Rect(side_inner_rect.x, side_panel_rect.y + 60, side_inner_rect.width, 26),
        "\uc120\ud0dd\ud55c \uc0c9\uc774 \ubc14\ub85c \uc801\uc6a9\ub418\ub294 \ubaa8\uc2b5\uc785\ub2c8\ub2e4",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )

    side_content_top = side_panel_rect.y + 104
    side_content_gap = 16
    preview_showcase_rect = clamp_rect_inside(
        side_panel_rect,
        pygame.Rect(side_inner_rect.x, side_content_top, side_inner_rect.width, 136),
        padding=16,
    )
    draw_panel(ctx, preview_showcase_rect)
    preview_center_x = preview_showcase_rect.centerx
    preview_center_y = preview_showcase_rect.centery
    preview_arc_rect = pygame.Rect(preview_center_x - 42, preview_center_y - 42, 84, 84)
    pygame.draw.arc(ctx['virtual_screen'], ctx['settings_preview_indicator_outline_color'], preview_arc_rect, 0.75, 2.4, 9)
    pygame.draw.arc(ctx['virtual_screen'], ctx['settings_preview_indicator_outline_color'], preview_arc_rect, 3.8, 5.45, 9)
    pygame.draw.arc(ctx['virtual_screen'], ctx['settings_preview_indicator_color'], preview_arc_rect, 0.75, 2.4, 5)
    pygame.draw.arc(ctx['virtual_screen'], ctx['settings_preview_indicator_color'], preview_arc_rect, 3.8, 5.45, 5)
    pygame.draw.line(ctx['virtual_screen'], ctx['settings_preview_crosshair_color'], (preview_center_x - 14, preview_center_y), (preview_center_x + 14, preview_center_y), 2)
    pygame.draw.line(ctx['virtual_screen'], ctx['settings_preview_crosshair_color'], (preview_center_x, preview_center_y - 14), (preview_center_x, preview_center_y + 14), 2)

    info_box_y = preview_showcase_rect.bottom + side_content_gap
    info_box_gap = 10
    info_box_w = (side_inner_rect.width - (info_box_gap * 2)) // 3
    info_box_h = 58
    side_info_rects = [
        clamp_rect_inside(
            side_panel_rect,
            pygame.Rect(side_inner_rect.x + ((info_box_w + info_box_gap) * index), info_box_y, info_box_w, info_box_h),
            padding=16,
        )
        for index in range(3)
    ]
    draw_info_box(
        ctx,
        side_info_rects[0],
        TEXT_HEX,
        active_hex,
        ctx['WHITE'],
    )
    draw_info_box(
        ctx,
        side_info_rects[1],
        TEXT_RGB,
        f"{active_color[0]}, {active_color[1]}, {active_color[2]}",
        ctx['WHITE'],
    )
    draw_info_box(
        ctx,
        side_info_rects[2],
        TEXT_HSV,
        active_hsv_text,
        ctx['WHITE'],
    )

    bottom_cards_y = side_info_rects[0].bottom + side_content_gap
    bottom_card_gap = 18
    bottom_card_h = max(56, side_inner_rect.bottom - bottom_cards_y)
    target_card_w = int((side_inner_rect.width - bottom_card_gap) * 0.42)
    swatch_card_w = side_inner_rect.width - bottom_card_gap - target_card_w
    target_card_rect = clamp_rect_inside(
        side_panel_rect,
        pygame.Rect(side_inner_rect.x, bottom_cards_y, target_card_w, bottom_card_h),
        padding=16,
    )
    swatch_card_rect = clamp_rect_inside(
        side_panel_rect,
        pygame.Rect(target_card_rect.right + bottom_card_gap, bottom_cards_y, swatch_card_w, bottom_card_h),
        padding=16,
    )
    draw_panel(ctx, target_card_rect)
    draw_panel(ctx, swatch_card_rect)

    blit_text_in_rect(
        ctx,
        pygame.Rect(target_card_rect.x + 16, target_card_rect.y + 10, target_card_rect.width - 32, 20),
        "\uc801\uc6a9 \ub300\uc0c1",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )
    blit_text_in_rect(
        ctx,
        pygame.Rect(target_card_rect.x + 16, target_card_rect.y + 34, target_card_rect.width - 32, 24),
        active_label,
        ctx['WHITE'],
        font_key='DMG_FONT',
        valign='center',
    )
    blit_text_in_rect(
        ctx,
        pygame.Rect(swatch_card_rect.x + 16, swatch_card_rect.y + 10, swatch_card_rect.width - 32, 20),
        "\uc120\ud0dd \uc0c9\uc0c1",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )
    swatch_rect = pygame.Rect(swatch_card_rect.x + 16, swatch_card_rect.y + 38, swatch_card_rect.width - 32, 22)
    pygame.draw.rect(ctx['virtual_screen'], active_color, swatch_rect, border_radius=10)
    pygame.draw.rect(ctx['virtual_screen'], ctx['WHITE'], swatch_rect, 2, border_radius=10)

    blit_text_in_rect(
        ctx,
        pygame.Rect(footer_info_inner_rect.x, footer_info_inner_rect.y, 88, 20),
        "\ub3c4\uc6c0\ub9d0",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )
    blit_text_in_rect(
        ctx,
        pygame.Rect(footer_info_inner_rect.x, footer_info_inner_rect.y + 22, footer_info_inner_rect.width, footer_info_inner_rect.height - 22),
        "\uac10\ub3c4\ub294 ESC \uc77c\uc2dc\uc815\uc9c0 \ud654\uba74\uc5d0\uc11c \uc870\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
        valign='center',
    )

    blit_text_in_rect(
        ctx,
        pygame.Rect(footer_actions_inner_rect.x, footer_actions_inner_rect.y, 120, 20),
        "\uc0c9\uc0c1 \uc124\uc815",
        ctx['LIGHT_GRAY'],
        font_key='ITEM_FONT',
    )
    preview_dirty = (
        ctx['settings_preview_crosshair_color'] != ctx['crosshair_color']
        or ctx['settings_preview_indicator_color'] != ctx['indicator_color']
    )
    save_fill_color = (36, 120, 72) if preview_dirty else (58, 68, 64)
    save_border_color = (130, 255, 180) if preview_dirty else (150, 150, 150)
    draw_button(
        ctx,
        ctx['settings_color_save_btn_rect'],
        TEXT_SAVE,
        save_fill_color,
        border_color=save_border_color,
        font_key='DMG_FONT',
    )
    draw_button(ctx, ctx['settings_color_reset_btn_rect'], TEXT_DEFAULT_COLOR, (70, 70, 90), font_key='DMG_FONT')
    draw_button(ctx, ctx['settings_back_btn_rect'], TEXT_BACK, ctx['GRAY'], font_key='DMG_FONT')

    current_time = pygame.time.get_ticks()
    if ctx.get('settings_status_message') and current_time < ctx.get('settings_status_until', 0):
        status_rect = pygame.Rect(986, 70, 196, 42)
        draw_panel(ctx, status_rect)
        blit_text_in_rect(
            ctx,
            status_rect.inflate(-18, -12),
            ctx['settings_status_message'],
            ctx['WHITE'],
            font_key='ITEM_FONT',
            align='center',
            valign='center',
        )

    if ctx.get('settings_confirm_exit_open'):
        overlay = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 120))
        ctx['virtual_screen'].blit(overlay, (0, 0))

        dialog_rect = pygame.Rect(ctx['WIDTH'] // 2 - 270, ctx['HEIGHT'] // 2 - 90, 540, 180)
        draw_panel(ctx, dialog_rect)
        blit_text_in_rect(
            ctx,
            pygame.Rect(dialog_rect.x + 24, dialog_rect.y + 20, dialog_rect.width - 48, 56),
            TEXT_CONFIRM_UNSAVED,
            ctx['WHITE'],
            font_key='DMG_FONT',
            align='center',
            valign='center',
        )
        draw_button(ctx, ctx['settings_confirm_save_btn_rect'], TEXT_SAVE, (36, 120, 72), border_color=(130, 255, 180), font_key='DMG_FONT')
        draw_button(ctx, ctx['settings_confirm_discard_btn_rect'], TEXT_DONT_SAVE, (82, 82, 92), font_key='DMG_FONT')
        draw_button(ctx, ctx['settings_confirm_cancel_btn_rect'], TEXT_CANCEL, ctx['GRAY'], font_key='DMG_FONT')


def draw_pause_screen(ctx):
    overlay = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']))
    overlay.set_alpha(180)
    overlay.fill(ctx['BLACK'])
    ctx['virtual_screen'].blit(overlay, (0, 0))
    pause_text = ctx['TITLE_FONT'].render(TEXT_PAUSED, True, ctx['WHITE'])
    ctx['virtual_screen'].blit(pause_text, (ctx['WIDTH'] // 2 - pause_text.get_width() // 2, 80))

    sens_text = ctx['PROG_FONT'].render(TEXT_SENSITIVITY, True, ctx['WHITE'])
    sens_value_text = ctx['PROG_FONT'].render(f"{ctx['sens_mult']:.1f} x", True, ctx['YELLOW'])
    ctx['virtual_screen'].blit(sens_text, (ctx['WIDTH'] // 2 - sens_text.get_width() // 2, 175))
    ctx['virtual_screen'].blit(
        sens_value_text,
        (ctx['WIDTH'] // 2 - sens_value_text.get_width() // 2, ctx['pause_sens_minus_btn_rect'].centery - sens_value_text.get_height() // 2),
    )

    minus_color = ctx['GRAY'] if ctx['sens_mult'] <= 0.1 else ctx['RED']
    plus_color = ctx['GREEN']
    reset_color = (50, 100, 200)
    pygame.draw.rect(ctx['virtual_screen'], minus_color, ctx['pause_sens_minus_btn_rect'], border_radius=5)
    pygame.draw.rect(ctx['virtual_screen'], plus_color, ctx['pause_sens_plus_btn_rect'], border_radius=5)
    pygame.draw.rect(ctx['virtual_screen'], reset_color, ctx['pause_sens_reset_btn_rect'], border_radius=5)

    minus_text = ctx['PROG_FONT'].render("-", True, ctx['WHITE'])
    plus_text = ctx['PROG_FONT'].render("+", True, ctx['WHITE'])
    reset_text = ctx['DMG_FONT'].render(TEXT_RESET, True, ctx['WHITE'])
    ctx['virtual_screen'].blit(
        minus_text,
        (
            ctx['pause_sens_minus_btn_rect'].centerx - minus_text.get_width() // 2,
            ctx['pause_sens_minus_btn_rect'].centery - minus_text.get_height() // 2,
        ),
    )
    ctx['virtual_screen'].blit(
        plus_text,
        (
            ctx['pause_sens_plus_btn_rect'].centerx - plus_text.get_width() // 2,
            ctx['pause_sens_plus_btn_rect'].centery - plus_text.get_height() // 2,
        ),
    )
    ctx['virtual_screen'].blit(
        reset_text,
        (
            ctx['pause_sens_reset_btn_rect'].centerx - reset_text.get_width() // 2,
            ctx['pause_sens_reset_btn_rect'].centery - reset_text.get_height() // 2,
        ),
    )

    draw_button(ctx, ctx['resume_btn_rect'], TEXT_RESUME, ctx['GRAY'])
    draw_button(ctx, ctx['retry_btn_rect'], TEXT_RETRY, ctx['GRAY'])
    draw_button(ctx, ctx['pause_settings_btn_rect'], TEXT_SETTINGS, ctx['GRAY'])
    draw_button(ctx, ctx['mainmenu_btn_rect'], TEXT_MAIN_MENU, ctx['GRAY'])
    draw_button(ctx, ctx['quit_btn_rect'], TEXT_QUIT, ctx['RED'])


def draw_gameover_screen(ctx):
    overlay = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
    overlay.fill((150, 0, 0, 100))
    ctx['virtual_screen'].blit(overlay, (0, 0))

    died_text = ctx['GO_FONT'].render(TEXT_DIED, True, ctx['RED'])
    final_score_text = ctx['PROG_FONT'].render(f"{TEXT_FINAL_SCORE}: {ctx['current_score']}", True, ctx['WHITE'])
    restart_text = ctx['PROG_FONT'].render(TEXT_ESC_TO_MENU, True, ctx['GREEN'])

    ctx['virtual_screen'].blit(
        died_text,
        (ctx['WIDTH'] // 2 - died_text.get_width() // 2, ctx['HEIGHT'] // 2 - died_text.get_height() // 2 - 50),
    )
    ctx['virtual_screen'].blit(
        final_score_text,
        (ctx['WIDTH'] // 2 - final_score_text.get_width() // 2, ctx['HEIGHT'] // 2 + 50),
    )
    if pygame.time.get_ticks() % 1000 < 600:
        ctx['virtual_screen'].blit(
            restart_text,
            (ctx['WIDTH'] // 2 - restart_text.get_width() // 2, ctx['HEIGHT'] // 2 + 120),
        )


def draw_damage_overlay(ctx):
    if ctx['damage_flash_timer'] > 0 and ctx['game_state'] == ctx['STATE_PLAYING']:
        alpha = min(30, max(0, int(ctx['damage_flash_timer'] * 2)))
        flash_surface = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
        flash_surface.fill((255, 0, 0, alpha))
        ctx['virtual_screen'].blit(flash_surface, (0, 0))

    if ctx['damage_text_timer'] > 0 and ctx['game_state'] == ctx['STATE_PLAYING']:
        box_w = 400
        box_h = 60
        box_x = ctx['WIDTH'] // 2 - box_w // 2
        box_y = 50
        box_surface = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        box_surface.fill((0, 0, 0, 200))
        pygame.draw.rect(box_surface, ctx['RED'], (0, 0, box_w, box_h), 2, border_radius=5)
        msg_surface = ctx['PROG_FONT'].render(TEXT_HIT, True, ctx['RED'])
        ctx['virtual_screen'].blit(box_surface, (box_x, box_y))
        ctx['virtual_screen'].blit(
            msg_surface,
            (
                box_x + (box_w - msg_surface.get_width()) // 2,
                box_y + (box_h - msg_surface.get_height()) // 2,
            ),
        )


def draw_heal_overlay(ctx):
    if ctx['heal_effect_timer'] <= 0:
        return

    heal_surface = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
    alpha = min(20, int((ctx['heal_effect_timer'] / 40) * 20))
    heal_surface.fill((0, 255, 0, alpha))
    ctx['virtual_screen'].blit(heal_surface, (0, 0))


def render_scene(ctx):
    ctx['virtual_screen'].fill(ctx['FOG_COLOR'])

    if ctx['game_state'] == ctx['STATE_MAIN_MENU']:
        title_text = ctx['TITLE_FONT'].render("RETRO FPS", True, ctx['RED'])
        ctx['virtual_screen'].blit(title_text, (ctx['WIDTH'] // 2 - title_text.get_width() // 2, 100))
        draw_button(ctx, ctx['single_btn_rect'], TEXT_SINGLE_PLAY, ctx['GRAY'])
        draw_button(ctx, ctx['settings_btn_rect'], TEXT_SETTINGS, ctx['GRAY'])
        draw_button(ctx, ctx['main_quit_btn_rect'], TEXT_QUIT, ctx['RED'])
        return

    if ctx['game_state'] == ctx['STATE_SETTINGS']:
        draw_settings_screen(ctx)
        return

    ctx['virtual_screen'].blit(ctx['bg_surface'], (0, -ctx['HEIGHT'] // 2 + ctx['player_pitch']))
    render_projected_walls(ctx)

    draw_bullet_holes(ctx)
    ctx['draw_items_and_enemies']()
    draw_damage_texts(ctx)
    ctx['draw_grenade_preview']()
    ctx['draw_grenades_and_explosions']()

    if not ctx['player_dead']:
        ctx['draw_weapon']()
        draw_ui(ctx)
        draw_minimap(ctx)

    if ctx['game_state'] == ctx['STATE_COUNTDOWN']:
        elapsed = pygame.time.get_ticks() - ctx['countdown_start']
        remains = 3 - (elapsed // 1000)
        if remains > 0:
            overlay = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']))
            overlay.set_alpha(100)
            overlay.fill(ctx['BLACK'])
            ctx['virtual_screen'].blit(overlay, (0, 0))
            count_text = ctx['GO_FONT'].render(str(remains), True, ctx['YELLOW'])
            ctx['virtual_screen'].blit(
                count_text,
                (ctx['WIDTH'] // 2 - count_text.get_width() // 2, ctx['HEIGHT'] // 2 - count_text.get_height() // 2),
            )
        elif remains == 0:
            go_text = ctx['GO_FONT'].render("GO!", True, ctx['GREEN'])
            ctx['virtual_screen'].blit(
                go_text,
                (ctx['WIDTH'] // 2 - go_text.get_width() // 2, ctx['HEIGHT'] // 2 - go_text.get_height() // 2),
            )

    if ctx['game_state'] == ctx['STATE_PAUSED']:
        draw_pause_screen(ctx)

    if ctx['game_state'] == ctx['STATE_GAMEOVER']:
        draw_gameover_screen(ctx)

    draw_damage_overlay(ctx)
    draw_heal_overlay(ctx)

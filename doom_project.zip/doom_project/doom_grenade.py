import math
import random

import pygame


def is_safe_grenade(ctx, target_x, target_y):
    if math.isnan(target_x) or math.isnan(target_y):
        return False

    margin = 4
    for dx in [-margin, margin]:
        for dy in [-margin, margin]:
            check_x = int((target_x + dx) / ctx['TILE_SIZE'])
            check_y = int((target_y + dy) / ctx['TILE_SIZE'])
            if check_x < 0 or check_x >= ctx['MAP_W'] or check_y < 0 or check_y >= ctx['MAP_H']:
                return False
            if ctx['MAP'][check_y][check_x] != 0:
                return False
    return True


def get_grenade_launch_state(ctx):
    pitch_ratio = max(-1.0, min(1.0, ctx['player_pitch'] / (ctx['HEIGHT'] / 2)))
    pitch_angle = max(-0.55, min(0.82, pitch_ratio * 0.92))
    look_up = max(0.0, pitch_ratio)
    look_down = max(0.0, -pitch_ratio)
    dir_x = math.cos(ctx['player_angle'])
    dir_y = math.sin(ctx['player_angle'])
    right_x = -math.sin(ctx['player_angle'])
    right_y = math.cos(ctx['player_angle'])
    start_x = ctx['player_x'] + dir_x * 16 + right_x * 14
    start_y = ctx['player_y'] + dir_y * 16 + right_y * 14
    if not is_safe_grenade(ctx, start_x, start_y):
        start_x = ctx['player_x']
        start_y = ctx['player_y']

    target_x = ctx['player_x'] + dir_x * 140
    target_y = ctx['player_y'] + dir_y * 140
    throw_dx = target_x - start_x
    throw_dy = target_y - start_y
    throw_len = max(1.0, math.hypot(throw_dx, throw_dy))
    throw_power = ctx['GRENADE_THROW_SPEED'] * (0.92 + look_up * 0.35 - look_down * 0.14)
    throw_power = max(ctx['GRENADE_THROW_SPEED'] * 0.8, throw_power)
    horizontal_speed = throw_power * max(0.96, math.cos(pitch_angle) + look_up * 0.28)
    throw_vx = (throw_dx / throw_len) * horizontal_speed
    throw_vy = (throw_dy / throw_len) * horizontal_speed
    vertical_speed = ctx['GRENADE_BASE_VZ'] + math.sin(pitch_angle) * throw_power * 0.82
    vertical_speed += look_up * 0.35

    return {
        'x': start_x,
        'y': start_y,
        'z': 10.0,
        'vx': throw_vx,
        'vy': throw_vy,
        'vz': vertical_speed,
        'fuse': ctx['GRENADE_FUSE_FRAMES'],
        'bounces': 0,
    }


def simulate_grenade_motion(ctx, grenade, scale):
    next_x = grenade['x'] + grenade['vx'] * scale
    if is_safe_grenade(ctx, next_x, grenade['y']):
        grenade['x'] = next_x
    else:
        grenade['bounces'] += 1
        grenade['vx'] *= -ctx['GRENADE_BOUNCE_DAMPING']
        grenade['vy'] *= 0.75

    next_y = grenade['y'] + grenade['vy'] * scale
    if is_safe_grenade(ctx, grenade['x'], next_y):
        grenade['y'] = next_y
    else:
        grenade['bounces'] += 1
        grenade['vy'] *= -ctx['GRENADE_BOUNCE_DAMPING']
        grenade['vx'] *= 0.75

    grenade['z'] += grenade['vz'] * scale
    grenade['vz'] -= ctx['GRENADE_GRAVITY'] * scale

    if grenade['z'] <= 0:
        grenade['z'] = 0
        if abs(grenade['vz']) > 0.65 and grenade['bounces'] < 3:
            grenade['bounces'] += 1
            grenade['vz'] = -grenade['vz'] * ctx['GRENADE_BOUNCE_DAMPING']
            grenade['vx'] *= ctx['GRENADE_GROUND_FRICTION']
            grenade['vy'] *= ctx['GRENADE_GROUND_FRICTION']
        else:
            grenade['vz'] = 0
            grenade['vx'] *= ctx['GRENADE_GROUND_FRICTION']
            grenade['vy'] *= ctx['GRENADE_GROUND_FRICTION']
            if abs(grenade['vx']) < 0.05:
                grenade['vx'] = 0
            if abs(grenade['vy']) < 0.05:
                grenade['vy'] = 0

        if grenade['bounces'] >= 3:
            grenade['vz'] = 0
            grenade['vx'] *= 0.72
            grenade['vy'] *= 0.72
            if abs(grenade['vx']) < 0.12:
                grenade['vx'] = 0
            if abs(grenade['vy']) < 0.12:
                grenade['vy'] = 0


def project_world_point(ctx, world_x, world_y, world_z=0.0):
    dx = world_x - ctx['player_x']
    dy = world_y - ctx['player_y']
    dist = math.hypot(dx, dy)
    if dist <= 1:
        return None

    angle_to_point = math.atan2(dy, dx)
    angle_diff = angle_to_point - ctx['player_angle']
    while angle_diff < -math.pi:
        angle_diff += 2 * math.pi
    while angle_diff > math.pi:
        angle_diff -= 2 * math.pi

    if abs(angle_diff) > ctx['current_fov'] / 2 + 0.25:
        return None

    safe_dist = max(1.0, dist)
    screen_x = (ctx['WIDTH'] / 2) + (angle_diff / (ctx['current_fov'] / 2)) * (ctx['WIDTH'] / 2)
    wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / safe_dist
    ground_y = ctx['HEIGHT'] // 2 + wall_height // 2 + ctx['player_pitch']
    screen_y = ground_y - (world_z * ctx['current_proj_dist'] / safe_dist)

    ray_idx = int(screen_x / ctx['SCALE'])
    if 0 <= ray_idx < ctx['CASTED_RAYS'] and dist <= ctx['Z_BUFFER'][ray_idx] + 20:
        return screen_x, screen_y, dist, wall_height
    return None


def throw_grenade(ctx):
    if not ctx['grenade_ready'] or ctx['grenade_count'] <= 0:
        return

    ctx['grenade_count'] -= 1
    thrown_grenade = get_grenade_launch_state(ctx)
    thrown_grenade['fuse'] = ctx['grenade_cook_fuse']
    ctx['grenade_ready'] = False
    ctx['grenade_cook_fuse'] = ctx['GRENADE_FUSE_FRAMES']
    ctx['stop_grenade_cooking_sound']()
    ctx['grenades'].append(thrown_grenade)
    ctx['fire_cooldown_end'] = max(ctx['fire_cooldown_end'], pygame.time.get_ticks() + 250)


def explode_held_grenade(ctx):
    if ctx['grenade_count'] <= 0:
        ctx['grenade_ready'] = False
        ctx['grenade_cook_fuse'] = ctx['GRENADE_FUSE_FRAMES']
        ctx['stop_grenade_cooking_sound']()
        return

    ctx['grenade_count'] -= 1
    ctx['grenade_ready'] = False
    ctx['grenade_cook_fuse'] = ctx['GRENADE_FUSE_FRAMES']
    ctx['stop_grenade_cooking_sound']()
    explode_grenade(
        ctx,
        {
            'x': ctx['player_x'] + math.cos(ctx['player_angle']) * 10,
            'y': ctx['player_y'] + math.sin(ctx['player_angle']) * 10,
        },
    )


def explode_grenade(ctx, grenade):
    ctx['stop_grenade_cooking_sound']()
    ctx['play_positional_sound'](
        'bomb_boom',
        grenade['x'],
        grenade['y'],
        ctx['GRENADE_EXPLOSION_SOUND_RADIUS'],
        ctx['GRENADE_EXPLOSION_MAX_VOLUME'],
    )
    sparks = []
    for _ in range(72):
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(4.0, 16.0)
        sparks.append(
            {
                'vx': math.cos(angle) * speed,
                'vy': math.sin(angle) * speed,
                'size': random.randint(4, 13),
                'color': random.choice(
                    [
                        (255, 220, 120),
                        (255, 170, 70),
                        (255, 120, 50),
                        (255, 250, 210),
                    ]
                ),
            }
        )

    ctx['grenade_explosions'].append(
        {
            'x': grenade['x'],
            'y': grenade['y'],
            'life': ctx['GRENADE_EXPLOSION_LIFE'],
            'max_life': ctx['GRENADE_EXPLOSION_LIFE'],
            'sparks': sparks,
        }
    )

    for enemy in ctx['enemies']:
        if enemy['dead']:
            continue

        dist = math.hypot(enemy['x'] - grenade['x'], enemy['y'] - grenade['y'])
        if dist > ctx['GRENADE_BLAST_RADIUS']:
            continue

        damage_ratio = 1.0 - (dist / ctx['GRENADE_BLAST_RADIUS'])
        damage = int(
            ctx['GRENADE_MIN_DAMAGE']
            + (ctx['GRENADE_MAX_DAMAGE'] - ctx['GRENADE_MIN_DAMAGE']) * damage_ratio
        )
        enemy['hp'] -= damage

        projected = project_world_point(ctx, enemy['x'], enemy['y'], 36)
        if projected:
            screen_x, screen_y, _, _ = projected
            ctx['damage_texts'].append(
                {
                    'text': f"{damage}",
                    'x': int(screen_x),
                    'y': int(screen_y),
                    'color': ctx['YELLOW'],
                    'life': 55,
                }
            )

        if enemy['hp'] <= 0 and not enemy['dead']:
            ctx['kill_enemy'](enemy, False)


def update_grenades(ctx):
    for grenade in ctx['grenades'][:]:
        simulate_grenade_motion(ctx, grenade, ctx['time_scale'])
        grenade['fuse'] -= 1 * ctx['time_scale']
        if grenade['fuse'] <= 0:
            explode_grenade(ctx, grenade)
            ctx['grenades'].remove(grenade)

    for explosion in ctx['grenade_explosions'][:]:
        explosion['life'] -= 1 * ctx['time_scale']
        if explosion['life'] <= 0:
            ctx['grenade_explosions'].remove(explosion)


def draw_grenade_preview(ctx):
    if (
        not ctx['grenade_ready']
        or ctx['grenade_count'] <= 0
        or ctx['game_state'] != ctx['STATE_PLAYING']
        or ctx['player_dead']
    ):
        return

    preview_state = dict(get_grenade_launch_state(ctx))
    landing_marker = None
    for idx in range(ctx['GRENADE_PREVIEW_STEPS']):
        next_x = preview_state['x'] + preview_state['vx'] * ctx['GRENADE_PREVIEW_STEP_SCALE']
        next_y = preview_state['y'] + preview_state['vy'] * ctx['GRENADE_PREVIEW_STEP_SCALE']
        next_z = preview_state['z'] + preview_state['vz'] * ctx['GRENADE_PREVIEW_STEP_SCALE']

        if not is_safe_grenade(ctx, next_x, preview_state['y']) or not is_safe_grenade(
            ctx, preview_state['x'], next_y
        ):
            break
        if next_z <= 0:
            landing_marker = project_world_point(ctx, next_x, next_y, 0)
            break

        preview_state['x'] = next_x
        preview_state['y'] = next_y
        preview_state['z'] = next_z
        preview_state['vz'] -= ctx['GRENADE_GRAVITY'] * ctx['GRENADE_PREVIEW_STEP_SCALE']

        projected = project_world_point(ctx, preview_state['x'], preview_state['y'], preview_state['z'])
        if not projected:
            continue

        screen_x, screen_y, _, _ = projected
        alpha = max(18, 90 - idx * 3)
        radius = max(2, 6 - idx // 6)
        preview_surf = pygame.Surface((radius * 2 + 2, radius * 2 + 2), pygame.SRCALPHA)
        pygame.draw.circle(preview_surf, (255, 220, 120, alpha), (radius + 1, radius + 1), radius)
        ctx['virtual_screen'].blit(preview_surf, (screen_x - radius - 1, screen_y - radius - 1))

    if landing_marker:
        marker_x, marker_y, marker_dist, _ = landing_marker
        marker_r = max(10, int(340 / max(70.0, marker_dist)))
        marker_surf = pygame.Surface((marker_r * 4, marker_r * 4), pygame.SRCALPHA)
        center = marker_r * 2
        pygame.draw.circle(marker_surf, (255, 210, 120, 70), (center, center), marker_r, max(2, marker_r // 6))
        pygame.draw.circle(
            marker_surf,
            (255, 120, 60, 38),
            (center, center),
            int(marker_r * 1.55),
            max(2, marker_r // 10),
        )
        pygame.draw.circle(marker_surf, (255, 245, 190, 24), (center, center), max(2, int(marker_r * 0.22)))
        ctx['virtual_screen'].blit(marker_surf, (marker_x - center, marker_y - center))


def draw_grenades_and_explosions(ctx):
    for grenade in ctx['grenades']:
        projected = project_world_point(ctx, grenade['x'], grenade['y'], grenade['z'])
        if not projected:
            continue

        screen_x, screen_y, dist, _ = projected
        radius = max(6, int(340 / max(40.0, dist)))

        shadow_surf = pygame.Surface((radius * 4, radius * 2), pygame.SRCALPHA)
        pygame.draw.ellipse(shadow_surf, (0, 0, 0, 90), (0, 0, radius * 4, radius * 2))
        ctx['virtual_screen'].blit(shadow_surf, (screen_x - radius * 2, screen_y + radius))

        grenade_surf = pygame.Surface((radius * 2 + 6, radius * 2 + 6), pygame.SRCALPHA)
        pygame.draw.circle(grenade_surf, (70, 110, 70, 255), (radius + 3, radius + 3), radius)
        pygame.draw.circle(grenade_surf, (30, 40, 30, 255), (radius + 3, radius + 3), max(2, radius // 2), 2)
        ctx['virtual_screen'].blit(grenade_surf, (screen_x - radius - 3, screen_y - radius - 3))

    for explosion in ctx['grenade_explosions']:
        projected = project_world_point(ctx, explosion['x'], explosion['y'], 0)
        if not projected:
            continue

        screen_x, screen_y, dist, _ = projected
        pulse = max(0.0, explosion['life'] / explosion.get('max_life', ctx['GRENADE_EXPLOSION_LIFE']))
        radius = max(44, int((1320 / max(46.0, dist)) * (1.95 - pulse * 0.6)))
        blast_surf = pygame.Surface((radius * 10, radius * 10), pygame.SRCALPHA)
        center = radius * 5
        smoke_radius = int(radius * (2.55 - pulse * 0.12))
        pygame.draw.circle(blast_surf, (65, 65, 70, int(85 * pulse * 0.5)), (center, center), smoke_radius)
        pygame.draw.circle(blast_surf, (25, 25, 30, int(75 * pulse * 0.5)), (center, center), int(radius * 3.4))
        pygame.draw.circle(blast_surf, (120, 25, 20, int(125 * pulse * 0.5)), (center, center), int(radius * 2.85))
        pygame.draw.circle(blast_surf, (210, 55, 20, int(170 * pulse * 0.5)), (center, center), int(radius * 2.35))
        pygame.draw.circle(blast_surf, (255, 90, 25, int(205 * pulse * 0.5)), (center, center), int(radius * 1.9))
        pygame.draw.circle(blast_surf, (255, 135, 35, int(225 * pulse * 0.5)), (center, center), int(radius * 1.55))
        pygame.draw.circle(blast_surf, (255, 185, 60, int(240 * pulse * 0.5)), (center, center), int(radius * 1.2))
        pygame.draw.circle(blast_surf, (255, 230, 125, int(248 * pulse * 0.5)), (center, center), radius)
        pygame.draw.circle(
            blast_surf,
            (255, 250, 205, int(190 * pulse * 0.5)),
            (center, center),
            max(12, int(radius * 0.62)),
        )
        pygame.draw.circle(blast_surf, (255, 255, 250, int(150 * pulse * 0.5)), (center, center), int(radius * 0.36))

        shockwave_radius = int(radius * (2.95 - pulse * 0.55))
        pygame.draw.circle(
            blast_surf,
            (255, 225, 130, int(230 * pulse * 0.5)),
            (center, center),
            shockwave_radius,
            max(5, radius // 6),
        )
        pygame.draw.circle(
            blast_surf,
            (255, 145, 70, int(165 * pulse * 0.5)),
            (center, center),
            int(shockwave_radius * 1.22),
            max(4, radius // 8),
        )
        pygame.draw.circle(
            blast_surf,
            (255, 250, 190, int(120 * pulse * 0.5)),
            (center, center),
            int(shockwave_radius * 0.76),
            max(2, radius // 14),
        )

        flare_len = int(radius * (2.7 - pulse * 0.3))
        flare_color = (255, 240, 180, int(150 * pulse * 0.5))
        pygame.draw.line(
            blast_surf,
            flare_color,
            (center - flare_len, center),
            (center + flare_len, center),
            max(3, radius // 10),
        )
        pygame.draw.line(
            blast_surf,
            flare_color,
            (center, center - flare_len),
            (center, center + flare_len),
            max(3, radius // 10),
        )
        pygame.draw.line(
            blast_surf,
            flare_color,
            (center - int(flare_len * 0.7), center - int(flare_len * 0.7)),
            (center + int(flare_len * 0.7), center + int(flare_len * 0.7)),
            max(2, radius // 12),
        )
        pygame.draw.line(
            blast_surf,
            flare_color,
            (center - int(flare_len * 0.7), center + int(flare_len * 0.7)),
            (center + int(flare_len * 0.7), center - int(flare_len * 0.7)),
            max(2, radius // 12),
        )

        for spark in explosion.get('sparks', []):
            spark_x = center + int(spark['vx'] * (1.0 - pulse) * radius * 0.95)
            spark_y = center + int(spark['vy'] * (1.0 - pulse) * radius * 0.95)
            spark_r = max(1, int(spark['size'] * max(0.2, pulse)))
            spark_color = spark.get('color', (255, 210, 120))
            pygame.draw.line(
                blast_surf,
                (*spark_color, int(190 * pulse * 0.5)),
                (center, center),
                (spark_x, spark_y),
                max(1, spark_r // 2),
            )
            pygame.draw.circle(blast_surf, (*spark_color, int(230 * pulse * 0.5)), (spark_x, spark_y), spark_r)

        ctx['virtual_screen'].blit(blast_surf, (screen_x - center, screen_y - center))

        if dist < ctx['GRENADE_BLAST_RADIUS'] * 1.6:
            flash_alpha = int(max(0, (1.0 - (dist / (ctx['GRENADE_BLAST_RADIUS'] * 1.6))) * 210) * pulse * 0.5)
            if flash_alpha > 0:
                flash = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
                flash.fill((255, 220, 150, flash_alpha))
                ctx['virtual_screen'].blit(flash, (0, 0))
                heat_flash = pygame.Surface((ctx['WIDTH'], ctx['HEIGHT']), pygame.SRCALPHA)
                heat_flash.fill((255, 120, 60, int(flash_alpha * 0.65)))
                ctx['virtual_screen'].blit(heat_flash, (0, 0))

import math
import random

import pygame

from doom_settings import (
    BASE_FOV,
    CASTED_RAYS,
    GRENADE_FUSE_FRAMES,
    GRENADE_START_COUNT,
    MAP_DEFAULT_HEIGHT,
    MAP_DEFAULT_WIDTH,
    MAX_DEPTH,
    generate_random_map,
)
from doom_weapons import build_weapon_state


PLAYER_MAX_HEALTH = 100.0
PLAYER_WALK_SPEED = 2.5
PLAYER_SPRINT_SPEED = 5.0
PLAYER_AIM_SPEED_MULTIPLIER = 0.5
PLAYER_MAX_STAMINA = 100.0
PLAYER_DEFAULT_SENSITIVITY = 1.0
PLAYER_MIN_SENSITIVITY = 0.1
PLAYER_MAX_SENSITIVITY = 5.0
PLAYER_START_ANGLE = math.pi / 2
PLAYER_START_PITCH = 0.0
PLAYER_MOUSE_ANGLE_SCALE = 0.002
PLAYER_MOUSE_PITCH_SCALE = 2.0
PLAYER_PITCH_LIMIT_MARGIN = 50
PLAYER_MELEE_STAMINA_COST = 15.0
PLAYER_SPRINT_START_DRAIN = 0.1
PLAYER_SPRINT_MOVE_DRAIN = 0.5
PLAYER_STAMINA_RECOVERY = 0.2
PLAYER_HEAL_AMOUNT = 20.0


def build_player_state():
    return {
        'x': 0.0,
        'y': 0.0,
        'angle': PLAYER_START_ANGLE,
        'pitch': PLAYER_START_PITCH,
        'health': PLAYER_MAX_HEALTH,
        'dead': False,
        'is_moving': False,
        'walk_timer': 0.0,
        'stamina': PLAYER_MAX_STAMINA,
        'invincible_end': 0,
        'sensitivity': PLAYER_DEFAULT_SENSITIVITY,
    }


def init_game(ctx):
    ctx['stop_grenade_cooking_sound']()

    ctx['player_health'] = PLAYER_MAX_HEALTH
    ctx['player_stamina'] = PLAYER_MAX_STAMINA
    ctx['player_dead'] = False
    ctx['player_angle'] = PLAYER_START_ANGLE
    ctx['player_pitch'] = PLAYER_START_PITCH
    ctx['current_score'] = 0
    ctx['spawn_timer'] = 0

    weapon_state = build_weapon_state()
    ctx['current_weapon'] = weapon_state['current_weapon']
    ctx['has_ak'] = weapon_state['has_ak']
    ctx['has_shotgun'] = weapon_state['has_shotgun']
    ctx['current_pistol_ammo'] = weapon_state['current_pistol_ammo']
    ctx['current_ak_ammo'] = weapon_state['current_ak_ammo']
    ctx['ak_reserve_ammo'] = weapon_state['ak_reserve_ammo']
    ctx['current_shotgun_ammo'] = weapon_state['current_shotgun_ammo']
    ctx['shotgun_reserve_ammo'] = weapon_state['shotgun_reserve_ammo']

    ctx['is_reloading'] = False
    ctx['is_melee_attacking'] = False
    ctx['reload_end'] = 0
    ctx['fire_cooldown_end'] = 0
    ctx['player_invincible_end'] = 0
    ctx['heal_effect_timer'] = 0
    ctx['damage_flash_timer'] = 0
    ctx['damage_text_timer'] = 0
    ctx['grenade_count'] = GRENADE_START_COUNT
    ctx['grenade_ready'] = False
    ctx['grenade_cook_fuse'] = GRENADE_FUSE_FRAMES
    ctx['grenades'] = []
    ctx['grenade_explosions'] = []
    ctx['enemies_killed'] = 0
    ctx['current_fov'] = BASE_FOV
    ctx['current_proj_dist'] = (ctx['WIDTH'] / 2) / math.tan(BASE_FOV / 2)

    ctx['bullet_holes'] = []
    ctx['damage_texts'] = []
    ctx['pickup_notices'].clear()
    ctx['enemies'] = []
    ctx['items'] = []
    ctx['FLOW_FIELD'] = []
    ctx['Z_BUFFER'] = [MAX_DEPTH] * CASTED_RAYS

    (
        ctx['MAP'],
        ctx['MAP_W'],
        ctx['MAP_H'],
        ctx['player_x'],
        ctx['player_y'],
    ) = generate_random_map(MAP_DEFAULT_WIDTH, MAP_DEFAULT_HEIGHT, ctx['TILE_SIZE'])

    ctx['update_flow_field']()
    ctx['last_grid_x'] = int(ctx['player_x'] / ctx['TILE_SIZE'])
    ctx['last_grid_y'] = int(ctx['player_y'] / ctx['TILE_SIZE'])
    ctx['spawn_enemies'](10)
    ctx['game_state'] = ctx['STATE_COUNTDOWN']
    ctx['countdown_start'] = pygame.time.get_ticks()


def check_collision(ctx, dx, dy):
    margin = 15

    next_x = ctx['player_x'] + dx
    hit_box_x = next_x + (margin if dx > 0 else -margin)
    if ctx['MAP'][int(ctx['player_y'] / ctx['TILE_SIZE'])][int(hit_box_x / ctx['TILE_SIZE'])] == 0:
        ctx['player_x'] = next_x

    next_y = ctx['player_y'] + dy
    hit_box_y = next_y + (margin if dy > 0 else -margin)
    if ctx['MAP'][int(hit_box_y / ctx['TILE_SIZE'])][int(ctx['player_x'] / ctx['TILE_SIZE'])] == 0:
        ctx['player_y'] = next_y


def is_safe(ctx, target_x, target_y):
    if math.isnan(target_x) or math.isnan(target_y):
        return False

    margin = 12
    for dx in (-margin, margin):
        for dy in (-margin, margin):
            check_x = int((target_x + dx) / ctx['TILE_SIZE'])
            check_y = int((target_y + dy) / ctx['TILE_SIZE'])
            if check_x < 0 or check_x >= ctx['MAP_W'] or check_y < 0 or check_y >= ctx['MAP_H']:
                return False
            if ctx['MAP'][check_y][check_x] != 0:
                return False
    return True


def is_safe_enemy(ctx, target_x, target_y):
    if math.isnan(target_x) or math.isnan(target_y):
        return False

    margin = 8
    for dx in (-margin, margin):
        for dy in (-margin, margin):
            check_x = int((target_x + dx) / ctx['TILE_SIZE'])
            check_y = int((target_y + dy) / ctx['TILE_SIZE'])
            if check_x < 0 or check_x >= ctx['MAP_W'] or check_y < 0 or check_y >= ctx['MAP_H']:
                return False
            if ctx['MAP'][check_y][check_x] != 0:
                return False
    return True


def update_player_movement(ctx, keys, current_time):
    mouse_dx, mouse_dy = pygame.mouse.get_rel()
    ctx['player_angle'] += mouse_dx * PLAYER_MOUSE_ANGLE_SCALE * ctx['sens_mult']
    ctx['player_pitch'] -= mouse_dy * PLAYER_MOUSE_PITCH_SCALE * ctx['sens_mult']
    ctx['player_pitch'] = max(
        -ctx['HEIGHT'] // 2 + PLAYER_PITCH_LIMIT_MARGIN,
        min(ctx['HEIGHT'] // 2 - PLAYER_PITCH_LIMIT_MARGIN, ctx['player_pitch']),
    )

    dx = 0
    dy = 0
    is_sprinting = False

    if keys[pygame.K_LSHIFT] and ctx['player_stamina'] > 0:
        speed = PLAYER_SPRINT_SPEED
        ctx['player_stamina'] -= PLAYER_SPRINT_START_DRAIN
        is_sprinting = True
    else:
        speed = PLAYER_WALK_SPEED

    if ctx['is_aiming']:
        speed *= PLAYER_AIM_SPEED_MULTIPLIER

    if is_sprinting and (keys[pygame.K_w] or keys[pygame.K_s] or keys[pygame.K_a] or keys[pygame.K_d]):
        ctx['player_stamina'] = max(
            0,
            ctx['player_stamina'] - PLAYER_SPRINT_MOVE_DRAIN * ctx['time_scale'],
        )
    else:
        ctx['player_stamina'] = min(
            PLAYER_MAX_STAMINA,
            ctx['player_stamina'] + PLAYER_STAMINA_RECOVERY * ctx['time_scale'],
        )

    if keys[pygame.K_w]:
        dx += math.cos(ctx['player_angle']) * speed
        dy += math.sin(ctx['player_angle']) * speed
    if keys[pygame.K_s]:
        dx -= math.cos(ctx['player_angle']) * speed
        dy -= math.sin(ctx['player_angle']) * speed
    if keys[pygame.K_a]:
        dx += math.sin(ctx['player_angle']) * speed
        dy -= math.cos(ctx['player_angle']) * speed
    if keys[pygame.K_d]:
        dx -= math.sin(ctx['player_angle']) * speed
        dy += math.cos(ctx['player_angle']) * speed

    ctx['player_is_moving'] = dx != 0 or dy != 0
    check_collision(ctx, dx, dy)

    if ctx['player_is_moving']:
        delay = 300 if speed > 5.0 else 500
        if current_time - ctx['last_player_footstep_time'] >= delay:
            ctx['last_player_footstep_time'] = current_time
            if 'player_footstep' in ctx['sounds']:
                ctx['sounds']['player_footstep'].stop()
                ctx['sounds']['player_footstep'].set_volume(1.0)
            ctx['play_sound']('player_footstep')
    elif 'player_footstep' in ctx['sounds']:
        ctx['sounds']['player_footstep'].stop()


def pickup_items(ctx):
    for item in ctx['items'][:]:
        dist = math.hypot(ctx['player_x'] - item['x'], ctx['player_y'] - item['y'])
        if dist >= 40:
            continue

        msg = ""
        msg_color = ctx['WHITE']

        if item['type'] == 'ak':
            if not ctx['has_ak']:
                ctx['play_sound']('item_pickup')
                ctx['has_ak'] = True
                msg = "AK-47 획득"
                msg_color = ctx['YELLOW']
            else:
                ctx['play_sound']('ammo_pickup')
                ctx['ak_reserve_ammo'] += ctx['AK_AMMO_PICKUP_LARGE']
                msg = f"AK 탄약 획득 (+{ctx['AK_AMMO_PICKUP_LARGE']}발)"
                msg_color = ctx['YELLOW']
        elif item['type'] == 'shotgun':
            if not ctx['has_shotgun']:
                ctx['play_sound']('item_pickup')
                ctx['has_shotgun'] = True
                msg = "SHOTGUN 획득"
                msg_color = ctx['WHITE']
            else:
                ctx['play_sound']('ammo_pickup')
                ctx['shotgun_reserve_ammo'] += ctx['SHOTGUN_AMMO_PICKUP']
                msg = f"샷건 탄약 획득 (+{ctx['SHOTGUN_AMMO_PICKUP']}발)"
                msg_color = ctx['WHITE']
        elif item['type'] == 'ak_ammo':
            ctx['play_sound']('ammo_pickup')
            ctx['ak_reserve_ammo'] += ctx['AK_AMMO_PICKUP_SMALL']
            msg = f"AK 탄약 획득 (+{ctx['AK_AMMO_PICKUP_SMALL']}발)"
            msg_color = ctx['YELLOW']
        elif item['type'] == 'shotgun_ammo':
            ctx['play_sound']('ammo_pickup')
            ctx['shotgun_reserve_ammo'] += ctx['SHOTGUN_AMMO_PICKUP']
            msg = f"샷건 탄약 획득 (+{ctx['SHOTGUN_AMMO_PICKUP']}발)"
            msg_color = ctx['RED']
        elif item['type'] == 'health':
            ctx['play_sound']('heal_sound')
            ctx['player_health'] = min(
                PLAYER_MAX_HEALTH,
                ctx['player_health'] + PLAYER_HEAL_AMOUNT,
            )
            msg = f"체력 회복 (+{int(PLAYER_HEAL_AMOUNT)})"
            msg_color = ctx['GREEN']
            ctx['heal_effect_timer'] = 40

        if msg:
            ctx['pickup_notices'].append({'text': msg, 'color': msg_color, 'timer': 120})
        ctx['items'].remove(item)


def trigger_melee(ctx):
    if (
        ctx['is_melee_attacking']
        or ctx['is_reloading']
        or ctx['player_dead']
        or ctx['player_stamina'] < PLAYER_MELEE_STAMINA_COST
    ):
        return

    ctx['play_sound']('sword_sound')
    ctx['is_melee_attacking'] = True
    ctx['melee_timer'] = 15
    ctx['player_stamina'] -= PLAYER_MELEE_STAMINA_COST

    target_enemy = None
    min_dist = 60

    for enemy in ctx['enemies']:
        if enemy['dead']:
            continue

        dx = enemy['x'] - ctx['player_x']
        dy = enemy['y'] - ctx['player_y']
        dist = math.hypot(dx, dy)
        if dist >= min_dist:
            continue

        angle_to_enemy = math.atan2(dy, dx)
        angle_diff = angle_to_enemy - ctx['player_angle']
        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi

        if abs(angle_diff) < math.pi / 2.5:
            target_enemy = enemy
            min_dist = dist

    if target_enemy is None:
        return

    target_enemy['hp'] -= 40
    ctx['play_sound']('monster_dmg')
    ctx['damage_texts'].append(
        {
            'text': "40",
            'x': ctx['WIDTH'] // 2 + random.randint(-30, 30),
            'y': ctx['HEIGHT'] // 2,
            'color': ctx['WHITE'],
            'life': 45,
        }
    )
    if target_enemy['hp'] <= 0 and not target_enemy['dead']:
        ctx['kill_enemy'](target_enemy, False)

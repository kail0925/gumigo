import pygame
import math
import random
import collections
import socket
import threading
import json 

# --- 초기화 및 기본 설정 ---
pygame.init()
pygame.font.init()
pygame.mixer.init() # 사운드 모듈 초기화 추가
pygame.mixer.set_num_channels(50)

# 사운드 파일 로드 (파일이 없을 경우 에러 방지 처리)
sounds = {}
try:
    sounds['pistol_shoot'] = pygame.mixer.Sound('pistol_shoot.mp3')
    sounds['pistol_reload'] = pygame.mixer.Sound('pistol_reload.mp3')
    
    sounds['ak_shoot'] = pygame.mixer.Sound('ak_shoot.mp3')
    sounds['ak_reload'] = pygame.mixer.Sound('ak_reload.mp3')
    
    sounds['shotgun_shoot'] = pygame.mixer.Sound('shotgun_shoot.mp3')
    sounds['shotgun_reload'] = pygame.mixer.Sound('shotgun_reload.mp3')

    sounds['no_ammo'] = pygame.mixer.Sound('no_ammo.mp3')

    sounds['player_footstep'] = pygame.mixer.Sound('player_footstep.mp3')
    sounds['monster_footstep'] = pygame.mixer.Sound('monster_footstep.mp3')

    sounds['sword_sound'] = pygame.mixer.Sound('sword_sound.mp3')
    sounds['heal_sound'] = pygame.mixer.Sound('heal_sound.mp3')
    sounds['item_pickup'] = pygame.mixer.Sound('item_pickup.mp3')
    sounds['ammo_pickup'] = pygame.mixer.Sound('ammo_pickup.mp3')

except Exception as e:
    print("사운드 로드 실패. 파일이 같은 폴더에 있는지 확인하세요:", e)

PROG_FONT = pygame.font.SysFont('malgungothic', 30, bold=True)
GO_FONT = pygame.font.SysFont('malgungothic', 100, bold=True)
DMG_FONT = pygame.font.SysFont('malgungothic', 24, bold=True)
ITEM_FONT = pygame.font.SysFont('malgungothic', 20, bold=True)
TITLE_FONT = pygame.font.SysFont('malgungothic', 80, bold=True) 
SMALL_UI_FONT = pygame.font.SysFont('malgungothic', 22, bold=True)
INPUT_FONT = pygame.font.SysFont('malgungothic', 32, bold=True)

# 렌더링 해상도 (16:9 비율)
WIDTH, HEIGHT = 1280, 720

infoObject = pygame.display.Info()
current_win_size = (WIDTH, HEIGHT)
screen = pygame.display.set_mode(current_win_size, pygame.RESIZABLE)
virtual_screen = pygame.Surface((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame Retro FPS - Ultimate Balance (Fixed)")
clock = pygame.time.Clock()

# --- 상수 ---
TILE_SIZE = 64
BASE_FOV = math.pi / 3  

CASTED_RAYS = 320
MAX_DEPTH = 20 * TILE_SIZE
SCALE = WIDTH / CASTED_RAYS

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
YELLOW = (255, 220, 0)
GRAY = (80, 80, 80)
LIGHT_GRAY = (150, 150, 150)
BROWN = (139, 69, 19)

FOG_COLOR = (30, 30, 35)
DOOM_WALL_BASE = (150, 120, 90)  

STATE_PLAYING = 0
STATE_GAMEOVER = 1
STATE_PAUSED = 2
STATE_MAIN_MENU = 3 
STATE_COUNTDOWN = 4
STATE_IP_INPUT = 5

WEAPON_PISTOL = 0
WEAPON_AK = 1
WEAPON_SHOTGUN = 2

last_no_ammo_time = 0

last_player_footstep_time = 0
last_monster_footstep_time = 0

# --- 배경 그라데이션 렌더링 ---
bg_h = HEIGHT * 2
bg_surface = pygame.Surface((WIDTH, bg_h))
horizon_y = bg_h // 2

for y in range(bg_h):
    if y < horizon_y:
        ratio = y / horizon_y
        r = int(10 + FOG_COLOR[0] * ratio)
        g = int(10 + FOG_COLOR[1] * ratio)
        b = int(15 + FOG_COLOR[2] * ratio)
        pygame.draw.line(bg_surface, (r, g, b), (0, y), (WIDTH, y))
    else:
        ratio = (y - horizon_y) / horizon_y
        r = int(FOG_COLOR[0] * (1 - ratio) + 50 * ratio)
        g = int(FOG_COLOR[1] * (1 - ratio) + 45 * ratio)
        b = int(FOG_COLOR[2] * (1 - ratio) + 40 * ratio)
        pygame.draw.line(bg_surface, (r, g, b), (0, y), (WIDTH, y))

# --- 전역 변수 초기화 ---
player_x, player_y = 0.0, 0.0
player_angle = 0.0
player_pitch = 0.0
player_health = 100.0

player_speed = 2.5 
player_dead = False
player_is_moving = False 
walk_timer = 0.0

game_state = STATE_MAIN_MENU 
countdown_start = 0 

max_stamina = 100.0
player_stamina = 100.0
is_fullscreen = False
sens_mult = 1.0  

MAP = []
MAP_W, MAP_H = 24, 24
FLOW_FIELD = [] 
last_grid_x, last_grid_y = -1, -1 

enemies = []
items = [] 
bullet_holes = []
damage_texts = []
pickup_notices = [] 
is_shooting, shoot_timer = False, 0
is_melee_attacking, melee_timer = False, 0 
gun_recoil = 0
current_score = 0
spawn_timer = 0  

current_weapon = WEAPON_PISTOL
has_ak = False
has_shotgun = False 

max_pistol_ammo = 6
current_pistol_ammo = 6
max_ak_ammo = 30
current_ak_ammo = 30
ak_reserve_ammo = 30 
max_shotgun_ammo = 4   
current_shotgun_ammo = 4
shotgun_reserve_ammo = 4 

is_reloading = False
reload_end = 0
fire_cooldown_end = 0
player_invincible_end = 0

heal_effect_timer = 0
damage_flash_timer = 0 
damage_text_timer = 0  

is_aiming = False
current_fov = BASE_FOV
STEP_ANGLE = current_fov / CASTED_RAYS
current_proj_dist = (WIDTH / 2) / math.tan(BASE_FOV / 2)
time_scale = 1.0 

Z_BUFFER = [MAX_DEPTH] * CASTED_RAYS

CLIENT_SEND_RATE = 20
CLIENT_SEND_INTERVAL_MS = int(1000 / CLIENT_SEND_RATE)
last_state_send_time = 0
last_sent_state = None

# --- 멀티플레이 전용 변수 ---
is_multiplayer = False
mp_socket = None
mp_pid = None
mp_other_players = {}
mp_recv_thread = None
mp_connected = False
mp_connect_error = ''

# IP 입력창 전용
ip_input_text = ''
ip_cursor_visible = True
ip_cursor_timer = 0
ip_connecting = False

# UI 컴포넌트 
sens_minus_btn_rect = pygame.Rect(WIDTH//2 - 130, 220, 40, 40)
sens_plus_btn_rect = pygame.Rect(WIDTH//2 + 90, 220, 40, 40)
sens_reset_btn_rect = pygame.Rect(WIDTH//2 - 50, 280, 100, 40)

resume_btn_rect = pygame.Rect(WIDTH//2 - 150, 350, 300, 45)
retry_btn_rect = pygame.Rect(WIDTH//2 - 150, 410, 300, 45)
mainmenu_btn_rect = pygame.Rect(WIDTH//2 - 150, 470, 300, 45)
quit_btn_rect = pygame.Rect(WIDTH//2 - 150, 530, 300, 45)

single_btn_rect = pygame.Rect(WIDTH//2 - 175, 260, 350, 60)
multi_btn_rect = pygame.Rect(WIDTH//2 - 175, 340, 350, 60)
main_quit_btn_rect = pygame.Rect(WIDTH//2 - 175, 420, 350, 60)

# IP 입력창 버튼
ip_connect_btn_rect = pygame.Rect(WIDTH//2 - 150, 420, 300, 50)
ip_back_btn_rect = pygame.Rect(WIDTH//2 - 150, 490, 300, 50)
ip_input_rect = pygame.Rect(WIDTH//2 - 220, 330, 440, 55)

def get_virtual_mouse_pos(mouse_x, mouse_y):
    win_w, win_h = screen.get_size()
    ratio = min(win_w / WIDTH, win_h / HEIGHT)
    scaled_w, scaled_h = int(WIDTH * ratio), int(HEIGHT * ratio)
    offset_x = (win_w - scaled_w) // 2
    offset_y = (win_h - scaled_h) // 2
    v_x = (mouse_x - offset_x) / ratio
    v_y = (mouse_y - offset_y) / ratio
    return (v_x, v_y)

def update_flow_field():
    global FLOW_FIELD, MAP_W, MAP_H
    
    integration_field = [[float('inf')] * MAP_W for _ in range(MAP_H)]
    FLOW_FIELD = [[(0, 0)] * MAP_W for _ in range(MAP_H)]
    
    px, py = int(player_x / TILE_SIZE), int(player_y / TILE_SIZE)
    if not (0 <= px < MAP_W and 0 <= py < MAP_H): return
        
    queue = collections.deque([(px, py)])
    integration_field[py][px] = 0
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (1, -1), (-1, 1), (1, 1)]
    
    while queue:
        cx, cy = queue.popleft()
        for dx, dy in directions:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < MAP_W and 0 <= ny < MAP_H and MAP[ny][nx] == 0:
                cost = 1.414 if dx != 0 and dy != 0 else 1.0
                new_cost = integration_field[cy][cx] + cost
                if new_cost < integration_field[ny][nx]:
                    integration_field[ny][nx] = new_cost
                    queue.append((nx, ny))
                    
    for y in range(MAP_H):
        for x in range(MAP_W):
            if MAP[y][x] == 1: continue
            
            # 💡 [버그 픽스] 도달할 수 없는 공간(고립된 방)의 inf - inf 연산으로 인한 NaN 발생 방지
            if integration_field[y][x] == float('inf'): 
                FLOW_FIELD[y][x] = (0, 0)
                continue
            
            left = integration_field[y][x-1] if x > 0 and MAP[y][x-1] == 0 else integration_field[y][x]
            right = integration_field[y][x+1] if x < MAP_W-1 and MAP[y][x+1] == 0 else integration_field[y][x]
            up = integration_field[y-1][x] if y > 0 and MAP[y-1][x] == 0 else integration_field[y][x]
            down = integration_field[y+1][x] if y < MAP_H-1 and MAP[y+1][x] == 0 else integration_field[y][x]
            
            vx = left - right
            vy = up - down
            
            if vx == 0 and vy == 0:
                min_cost = float('inf')
                best_dir = (0, 0)
                for dx, dy in directions:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < MAP_W and 0 <= ny < MAP_H and MAP[ny][nx] == 0:
                        if integration_field[ny][nx] < min_cost:
                            min_cost = integration_field[ny][nx]
                            dist = math.hypot(dx, dy)
                            best_dir = (dx / dist, dy / dist)
                FLOW_FIELD[y][x] = best_dir
            else:
                v_len = math.hypot(vx, vy)
                # v_len이 0이 아닐 때만 정규화 진행
                if v_len > 0:
                    FLOW_FIELD[y][x] = (vx / v_len, vy / v_len)
                else:
                    FLOW_FIELD[y][x] = (0, 0)

def check_line_of_sight(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    dist = math.hypot(dx, dy)
    if dist == 0: return True
    
    steps = int(dist / 16.0) 
    if steps == 0: return True
    
    for i in range(1, steps):
        chk_x = x1 + (dx * i / steps)
        chk_y = y1 + (dy * i / steps)
        grid_x, grid_y = int(chk_x / TILE_SIZE), int(chk_y / TILE_SIZE)
        if 0 <= grid_x < MAP_W and 0 <= grid_y < MAP_H:
            if MAP[grid_y][grid_x] == 1:
                return False 
    return True

def init_game():
    global player_angle, player_pitch, player_health, player_dead, game_state
    global enemies, items, bullet_holes, damage_texts, current_score, Z_BUFFER, spawn_timer
    global current_weapon, has_ak, has_shotgun, current_pistol_ammo, current_ak_ammo, ak_reserve_ammo
    global current_shotgun_ammo, shotgun_reserve_ammo
    global is_reloading, reload_end, heal_effect_timer, damage_flash_timer, damage_text_timer, is_melee_attacking
    global player_stamina, fire_cooldown_end, player_invincible_end, current_fov, current_proj_dist
    global pickup_notices, countdown_start, last_grid_x, last_grid_y, FLOW_FIELD

    player_health = 100.0
    player_stamina = max_stamina
    player_dead = False
    player_angle = math.pi / 2
    player_pitch = 0.0
    current_score = 0
    spawn_timer = 0

    current_weapon = WEAPON_PISTOL
    has_ak = False
    has_shotgun = False
    current_pistol_ammo = max_pistol_ammo
    current_ak_ammo = max_ak_ammo
    ak_reserve_ammo = 30
    current_shotgun_ammo = max_shotgun_ammo
    shotgun_reserve_ammo = 4

    is_reloading = False
    is_melee_attacking = False
    reload_end = 0
    fire_cooldown_end = 0
    player_invincible_end = 0
    heal_effect_timer = 0
    damage_flash_timer = 0
    damage_text_timer = 0
    current_fov = BASE_FOV
    current_proj_dist = (WIDTH / 2) / math.tan(BASE_FOV / 2)

    bullet_holes = []
    damage_texts = []
    pickup_notices.clear()
    enemies = []
    items = []
    FLOW_FIELD = []
    Z_BUFFER = [MAX_DEPTH] * CASTED_RAYS

    if not is_multiplayer:
        generate_random_map(24, 24)
        update_flow_field()
        last_grid_x = int(player_x / TILE_SIZE)
        last_grid_y = int(player_y / TILE_SIZE)
        spawn_enemies(10)
        game_state = STATE_COUNTDOWN
        countdown_start = pygame.time.get_ticks()

def generate_random_map(w, h):
    global MAP, MAP_W, MAP_H, player_x, player_y
    MAP_W, MAP_H = w, h
    MAP = [[1 for _ in range(w)] for _ in range(h)]
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if random.random() > 0.3: MAP[y][x] = 0
    cx, cy = w // 2, h // 2
    for dy in range(-1, 2):
        for dx in range(-1, 2): MAP[cy + dy][cx + dx] = 0
    visited = set()
    regions = []
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if MAP[y][x] == 0 and (x, y) not in visited:
                region = []
                q = [(x, y)]
                visited.add((x, y))
                while q:
                    curr_x, curr_y = q.pop(0)
                    region.append((curr_x, curr_y))
                    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                        nx, ny = curr_x + dx, curr_y + dy
                        if 0 < nx < w - 1 and 0 < ny < h - 1:
                            if MAP[ny][nx] == 0 and (nx, ny) not in visited:
                                visited.add((nx, ny))
                                q.append((nx, ny))
                regions.append(region)
    if regions:
        regions.sort(key=len, reverse=True)
        main_region = regions[0]
        for isolated_region in regions[1:]:
            r1_x, r1_y = random.choice(isolated_region)
            r2_x, r2_y = random.choice(main_region)
            if random.choice([True, False]):
                for x in range(min(r1_x, r2_x), max(r1_x, r2_x) + 1): MAP[r1_y][x] = 0
                for y in range(min(r1_y, r2_y), max(r1_y, r2_y) + 1): MAP[y][r2_x] = 0
            else:
                for y in range(min(r1_y, r2_y), max(r1_y, r2_y) + 1): MAP[y][r1_x] = 0
                for x in range(min(r1_x, r2_x), max(r1_x, r2_x) + 1): MAP[r2_y][x] = 0

    for _ in range(2):
        for y in range(h - 1):
            for x in range(w - 1):
                if MAP[y][x] == 1 and MAP[y+1][x+1] == 1:
                    if MAP[y+1][x] == 0 and MAP[y][x+1] == 0:
                        MAP[y+1][x] = 1 
                        MAP[y][x+1] = 1 
                if MAP[y][x+1] == 1 and MAP[y+1][x] == 1:
                    if MAP[y][x] == 0 and MAP[y+1][x+1] == 0:
                        MAP[y][x] = 1 
                        MAP[y+1][x+1] = 1

    player_x = cx * TILE_SIZE + TILE_SIZE // 2
    player_y = cy * TILE_SIZE + TILE_SIZE // 2

def spawn_enemies(count):
    global enemies
    existing_ids = {e.get('id') for e in enemies if 'id' in e}
    for _ in range(count):
        for attempts in range(50):
            gx = random.randint(1, MAP_W - 2)
            gy = random.randint(1, MAP_H - 2)
            dist_to_p = math.hypot(gx * TILE_SIZE - player_x, gy * TILE_SIZE - player_y)
            if MAP[gy][gx] == 0 and dist_to_p > 300:
                enemy_id = random.randint(0, 999999)
                while enemy_id in existing_ids:
                    enemy_id = random.randint(0, 999999)
                existing_ids.add(enemy_id)
                enemies.append({
                    'id': enemy_id,
                    'x': gx * TILE_SIZE + TILE_SIZE // 2,
                    'y': gy * TILE_SIZE + TILE_SIZE // 2,
                    'hp': 150,
                    'speed': random.uniform(0.6, 1.4),
                    'dead': False,
                    'next_attack_time': 0,
                    'anim_offset': random.uniform(0, math.pi * 2)
                })
                break


def mp_recv_loop():
    global mp_connected
    buf = ''
    try:
        while mp_connected and mp_socket:
            data = mp_socket.recv(8192)
            if not data:
                break
            buf += data.decode('utf-8', errors='ignore')
            while '\n' in buf:
                line, buf = buf.split('\n', 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    handle_server_msg(msg)
                except json.JSONDecodeError:
                    pass
    except Exception as e:
        if mp_connected:
            print(f"[클라이언트] 수신 오류: {e}")
    finally:
        mp_connected = False


def handle_server_msg(msg):
    global enemies, items, MAP, MAP_W, MAP_H, player_x, player_y
    global mp_other_players, mp_pid, game_state, countdown_start
    global player_health, player_dead, damage_flash_timer, damage_text_timer, current_score
    global player_angle, player_pitch, current_weapon, has_ak, has_shotgun
    global current_pistol_ammo, current_ak_ammo, ak_reserve_ammo
    global current_shotgun_ammo, shotgun_reserve_ammo, is_reloading, reload_end
    global heal_effect_timer, is_melee_attacking, player_stamina, fire_cooldown_end
    global player_invincible_end, current_fov, current_proj_dist, pickup_notices
    global bullet_holes, damage_texts, Z_BUFFER, FLOW_FIELD, last_grid_x, last_grid_y, spawn_timer

    mtype = msg.get('type')

    if mtype == 'init':
        mp_pid = msg['pid']
        MAP = msg['map']
        MAP_W = msg['map_w']
        MAP_H = msg['map_h']
        player_x = msg['spawn_x']
        player_y = msg['spawn_y']

        player_health = 100.0
        player_stamina = max_stamina
        player_dead = False
        player_angle = math.pi / 2
        player_pitch = 0.0
        current_score = 0
        spawn_timer = 0

        current_weapon = WEAPON_PISTOL
        has_ak = False
        has_shotgun = False
        current_pistol_ammo = max_pistol_ammo
        current_ak_ammo = max_ak_ammo
        ak_reserve_ammo = 30
        current_shotgun_ammo = max_shotgun_ammo
        shotgun_reserve_ammo = 4

        is_reloading = False
        is_melee_attacking = False
        reload_end = 0
        fire_cooldown_end = 0
        player_invincible_end = 0
        heal_effect_timer = 0
        damage_flash_timer = 0
        damage_text_timer = 0
        current_fov = BASE_FOV
        current_proj_dist = (WIDTH / 2) / math.tan(BASE_FOV / 2)

        bullet_holes = []
        damage_texts = []
        pickup_notices.clear()
        Z_BUFFER = [MAX_DEPTH] * CASTED_RAYS
        FLOW_FIELD = []
        last_grid_x = int(player_x / TILE_SIZE)
        last_grid_y = int(player_y / TILE_SIZE)

        enemies = []
        for e in msg.get('enemies', []):
            enemy = dict(e)
            enemy.setdefault('next_attack_time', 0)
            enemy.setdefault('anim_offset', random.uniform(0, math.pi * 2))
            enemies.append(enemy)

        items = []
        for item in msg.get('items', []):
            obj = dict(item)
            obj.setdefault('anim', random.random() * 10)
            items.append(obj)

        game_state = STATE_COUNTDOWN
        countdown_start = pygame.time.get_ticks()

    elif mtype == 'world':
        local_enemies = {e['id']: e for e in enemies if 'id' in e}
        new_enemies = []
        for se in msg.get('enemies', []):
            local_enemy = local_enemies.get(se['id'], {})
            merged = dict(local_enemy)
            merged.update(se)
            if local_enemy.get('dead', False) and not se.get('dead', False):
                merged['dead'] = True
                merged['hp'] = local_enemy.get('hp', se.get('hp', 0))
            merged.setdefault('next_attack_time', 0)
            merged.setdefault('anim_offset', random.uniform(0, math.pi * 2))
            new_enemies.append(merged)
        enemies[:] = new_enemies

        items[:] = []
        for si in msg.get('items', []):
            new_i = dict(si)
            new_i.setdefault('anim', random.random() * 10)
            items.append(new_i)

        mp_other_players.clear()
        for p in msg.get('players', []):
            if p['pid'] != mp_pid:
                mp_other_players[p['pid']] = p

    elif mtype == 'hit':
        damage = msg.get('damage', 10)
        if not player_dead:
            player_health -= damage
            damage_flash_timer = 20
            damage_text_timer = 60
            if player_health <= 0:
                player_dead = True
                game_state = STATE_GAMEOVER
                pygame.mouse.set_visible(True)
                pygame.event.set_grab(False)

    elif mtype == 'enemy_killed':
        eid = msg.get('enemy_id')
        for enemy in enemies:
            if enemy.get('id') == eid:
                enemy['dead'] = True
        if msg.get('by') == mp_pid:
            current_score += msg.get('score', 100)

    elif mtype == 'enemy_hp':
        eid = msg.get('enemy_id')
        for enemy in enemies:
            if enemy.get('id') == eid:
                enemy['hp'] = msg.get('hp', enemy.get('hp', 0))
                break

    elif mtype == 'item_removed':
        iid = msg.get('item_id')
        items[:] = [item for item in items if item.get('id') != iid]

    # 👉 서버로부터 사운드 재생 메시지를 받았을 때
    elif mtype == 'play_sound':
            snd = msg.get('sound')
            sx = msg.get('x', player_x)
            sy = msg.get('y', player_y)
            if snd in sounds:
                dist = math.hypot(player_x - sx, player_y - sy)
                # 거리에 따른 볼륨 조절 (약 15칸 밖이면 소리가 안 들림)
                vol = max(0.0, 1.0 - (dist / (TILE_SIZE * 15)))
                sounds[snd].set_volume(vol)
                sounds[snd].play()


def mp_send(msg):
    if mp_socket and mp_connected:
        try:
            mp_socket.sendall((json.dumps(msg) + '\n').encode())
        except Exception:
            pass

# 👉 내 화면에서 소리를 재생하고, 다른 플레이어에게도 들리도록 서버로 전송하는 함수
def play_and_broadcast_sound(sound_key):
    # 1. 내 컴퓨터에서 재생
    if sound_key in sounds:
        sounds[sound_key].set_volume(1.0)
        sounds[sound_key].play()
    
    # 2. 멀티플레이 모드일 경우 서버로 전송
    if is_multiplayer:
        mp_send({
            'type': 'play_sound', 
            'sound': sound_key, 
            'x': player_x, 
            'y': player_y
        })


def maybe_send_state(current_time):
    global last_state_send_time, last_sent_state
    if not (is_multiplayer and mp_connected):
        return

    if (current_time - last_state_send_time) < CLIENT_SEND_INTERVAL_MS:
        return

    state = {
        'type': 'state',
        'x': round(player_x, 2),
        'y': round(player_y, 2),
        'angle': round(player_angle, 4),
        'hp': round(player_health, 1),
        'score': current_score,
        'weapon': current_weapon,
        'dead': player_dead,
        'has_ak': has_ak,
        'has_shotgun': has_shotgun,
        'pistol_ammo': current_pistol_ammo,
        'ak_ammo': current_ak_ammo,
        'ak_reserve': ak_reserve_ammo,
        'sg_ammo': current_shotgun_ammo,
        'sg_reserve': shotgun_reserve_ammo,
    }

    if state != last_sent_state:
        mp_send(state)
        last_state_send_time = current_time
        last_sent_state = state


def mp_connect(ip, port=55555):
    global mp_socket, mp_connected, mp_recv_thread, mp_connect_error
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((ip, port))
        s.settimeout(None)
        mp_socket = s
        mp_connected = True
        mp_connect_error = ''
        mp_recv_thread = threading.Thread(target=mp_recv_loop, daemon=True)
        mp_recv_thread.start()
        return True
    except Exception as e:
        mp_connect_error = str(e)
        return False


def mp_disconnect():
    global mp_socket, mp_connected, is_multiplayer, mp_other_players, mp_pid, last_state_send_time, last_sent_state
    mp_connected = False
    if mp_socket:
        try:
            mp_socket.close()
        except Exception:
            pass
        mp_socket = None
    is_multiplayer = False
    mp_other_players = {}
    mp_pid = None
    last_state_send_time = 0
    last_sent_state = None

def check_collision(dx, dy):
    global player_x, player_y
    margin = 15 
    next_x = player_x + dx
    hit_box_x = next_x + (margin if dx > 0 else -margin)
    if MAP[int(player_y / TILE_SIZE)][int(hit_box_x / TILE_SIZE)] == 0: player_x = next_x
    next_y = player_y + dy
    hit_box_y = next_y + (margin if dy > 0 else -margin)
    if MAP[int(hit_box_y / TILE_SIZE)][int(player_x / TILE_SIZE)] == 0: player_y = next_y

def is_safe(target_x, target_y):
    if math.isnan(target_x) or math.isnan(target_y): return False # NaN 2중 안전장치
    margin = 12
    for dx in [-margin, margin]:
        for dy in [-margin, margin]:
            check_x = int((target_x + dx) / TILE_SIZE)
            check_y = int((target_y + dy) / TILE_SIZE)
            if check_x < 0 or check_x >= MAP_W or check_y < 0 or check_y >= MAP_H: return False
            if MAP[check_y][check_x] != 0: return False
    return True

def is_safe_enemy(target_x, target_y):
    if math.isnan(target_x) or math.isnan(target_y): return False # NaN 2중 안전장치
    margin = 8 
    for dx in [-margin, margin]:
        for dy in [-margin, margin]:
            check_x = int((target_x + dx) / TILE_SIZE)
            check_y = int((target_y + dy) / TILE_SIZE)
            if check_x < 0 or check_x >= MAP_W or check_y < 0 or check_y >= MAP_H: return False
            if MAP[check_y][check_x] != 0: return False
    return True

def start_reload():
    global is_reloading, reload_end, last_no_ammo_time
    if is_reloading: return
    
    current_time = pygame.time.get_ticks()

    if current_weapon == WEAPON_PISTOL:
        if current_pistol_ammo < max_pistol_ammo:
            is_reloading = True
            reload_end = current_time + 1500
            play_and_broadcast_sound('pistol_reload')
            
    elif current_weapon == WEAPON_AK:
        if current_ak_ammo < max_ak_ammo:
            if ak_reserve_ammo > 0: 
                # 여분 총알이 있을 때만 장전 및 소리 재생
                is_reloading = True
                reload_end = current_time + 3000
                play_and_broadcast_sound('ak_reload')
            else: 
                # 여분 총알이 없을 때는 찰칵 소리만 (0.5초 쿨다운)
                if current_time - last_no_ammo_time > 500:
                    if 'no_ammo' in sounds: 
                        sounds['no_ammo'].set_volume(1.0)
                        sounds['no_ammo'].play()
                    last_no_ammo_time = current_time
                    
    elif current_weapon == WEAPON_SHOTGUN:
        if current_shotgun_ammo < max_shotgun_ammo:
            if shotgun_reserve_ammo > 0: 
                # 여분 총알이 있을 때만 장전 및 소리 재생
                is_reloading = True
                reload_end = current_time + 4000
                play_and_broadcast_sound('shotgun_reload')
            else: 
                # 여분 총알이 없을 때는 찰칵 소리만 (0.5초 쿨다운)
                if current_time - last_no_ammo_time > 500:
                    if 'no_ammo' in sounds: 
                        sounds['no_ammo'].set_volume(1.0)
                        sounds['no_ammo'].play()
                    last_no_ammo_time = current_time

def kill_enemy(target_enemy, is_headshot):
    global current_score
    target_enemy['dead'] = True
    score_gain = 200 if is_headshot else 100

    if is_multiplayer:
        mp_send({'type': 'shoot', 'enemy_id': target_enemy['id'], 'damage': 9999, 'headshot': is_headshot})
        return

    current_score += score_gain

    drop_x = target_enemy['x'] + random.randint(-10, 10)
    drop_y = target_enemy['y'] + random.randint(-10, 10)
    r = random.random()
    drop_type = None

    if r < 0.15:
        drop_type = 'shotgun_ammo' if has_shotgun else 'shotgun'
    elif r < 0.40:
        drop_type = 'ak_ammo' if has_ak else 'ak'
    elif r < 0.60:
        drop_type = 'health'

    if drop_type:
        items.append({
            'id': random.randint(0, 999999),
            'x': drop_x,
            'y': drop_y,
            'type': drop_type,
            'anim': random.random() * 10,
        })

def trigger_melee():
    global is_melee_attacking, melee_timer, player_stamina
    if is_melee_attacking or is_reloading or player_dead or player_stamina < 15:
        return

    play_and_broadcast_sound('sword_sound')
    
    is_melee_attacking = True
    melee_timer = 15
    player_stamina -= 15
    target_enemy = None
    min_dist = 60

    for enemy in enemies:
        if enemy['dead']:
            continue
        dx, dy = enemy['x'] - player_x, enemy['y'] - player_y
        dist = math.hypot(dx, dy)
        if dist < min_dist:
            angle_to_enemy = math.atan2(dy, dx)
            angle_diff = angle_to_enemy - player_angle
            while angle_diff < -math.pi:
                angle_diff += 2 * math.pi
            while angle_diff > math.pi:
                angle_diff -= 2 * math.pi
            if abs(angle_diff) < math.pi / 2.5:
                target_enemy = enemy
                min_dist = dist

    if target_enemy:
        target_enemy['hp'] -= 40
        damage_texts.append({'text': "40", 'x': WIDTH // 2 + random.randint(-30, 30), 'y': HEIGHT // 2, 'color': WHITE, 'life': 45})
        if target_enemy['hp'] <= 0 and not target_enemy['dead']:
            kill_enemy(target_enemy, False)
        elif is_multiplayer:
            mp_send({'type': 'shoot', 'enemy_id': target_enemy['id'], 'damage': 40, 'headshot': False})

def shoot():
    global is_shooting, shoot_timer, gun_recoil, current_score, damage_texts
    global current_pistol_ammo, current_ak_ammo, current_shotgun_ammo, fire_cooldown_end
    global player_pitch, player_angle

    current_time = pygame.time.get_ticks()

    if player_dead or is_reloading or is_melee_attacking or game_state != STATE_PLAYING:
        return
    if current_time < fire_cooldown_end:
        return

    pellet_count = 1
    move_penalty = 1.3 if player_is_moving else 1.0

    if current_weapon == WEAPON_PISTOL:
        if current_pistol_ammo <= 0:
            start_reload()
            return
        current_pistol_ammo -= 1
        play_and_broadcast_sound('pistol_shoot') # 👉 발사 소리 재생 및 전송
        fire_cooldown_end = current_time + 800
        gun_recoil = 80
        base_damage = random.randint(30, 45)
        max_dmg_dist = 600.0
        player_pitch += 25
        player_angle += random.uniform(-0.01, 0.01) * move_penalty
        spread_angle_range = 0.005 * move_penalty
        spread_pitch_range = 2.0 * move_penalty

    elif current_weapon == WEAPON_AK:
        if current_ak_ammo <= 0:
            start_reload()
            return
        current_ak_ammo -= 1
        play_and_broadcast_sound('ak_shoot') # 👉 발사 소리 재생 및 전송
        fire_cooldown_end = current_time + 130
        gun_recoil = 20
        base_damage = random.randint(20, 30)
        max_dmg_dist = 600.0
        player_pitch += random.uniform(10, 18)
        player_angle += random.uniform(-0.015, 0.015) * move_penalty
        spread_angle_range = 0.02 * move_penalty
        spread_pitch_range = 5.0 * move_penalty

    elif current_weapon == WEAPON_SHOTGUN:
        if current_shotgun_ammo <= 0:
            start_reload()
            return
        current_shotgun_ammo -= 1
        play_and_broadcast_sound('shotgun_shoot') # 👉 샷건 발사 소리
        fire_cooldown_end = current_time + 900
        gun_recoil = 160
        base_damage = 20
        max_dmg_dist = 250.0
        pellet_count = 5

        player_pitch += random.uniform(50, 90)
        player_angle += random.uniform(-0.1, 0.1) * (1.5 if player_is_moving else 1.0)

        sg_penalty = 1.2 if player_is_moving else 1.0
        spread_angle_range = 0.06 * sg_penalty
        spread_pitch_range = 15.0 * sg_penalty
    else:
        return

    player_pitch = max(-HEIGHT // 2 + 50, min(HEIGHT // 2 - 50, player_pitch))
    is_shooting = True
    shoot_timer = 8

    for _ in range(pellet_count):
        angle_offset = random.uniform(-spread_angle_range, spread_angle_range)
        pitch_offset = random.uniform(-spread_pitch_range, spread_pitch_range)
        shot_angle = player_angle + angle_offset
        shot_pitch = player_pitch + pitch_offset

        ray_idx = int(((shot_angle - (player_angle - current_fov / 2)) / current_fov) * CASTED_RAYS)
        ray_idx = max(0, min(CASTED_RAYS - 1, ray_idx))
        wall_dist = Z_BUFFER[ray_idx]

        target_enemy, min_dist, is_headshot = None, wall_dist, False

        for enemy in enemies:
            if enemy['dead']:
                continue
            dx, dy = enemy['x'] - player_x, enemy['y'] - player_y
            dist = math.hypot(dx, dy)
            safe_dist = max(1.0, dist)

            angle_to_enemy = math.atan2(dy, dx)
            angle_diff = angle_to_enemy - shot_angle
            while angle_diff < -math.pi:
                angle_diff += 2 * math.pi
            while angle_diff > math.pi:
                angle_diff -= 2 * math.pi

            if abs(angle_diff) < current_fov / 2 and dist < min_dist:
                wall_height = (TILE_SIZE * current_proj_dist) / safe_dist
                sprite_height = wall_height * 0.8
                sprite_width = sprite_height * 0.6

                monster_bottom = HEIGHT // 2 + wall_height // 2 + shot_pitch
                monster_top = monster_bottom - sprite_height

                pixel_offset = (angle_diff / (current_fov / 2)) * (WIDTH / 2)
                hit_y = HEIGHT // 2

                if abs(pixel_offset) < sprite_width / 2:
                    if monster_top <= hit_y <= monster_bottom:
                        target_enemy, min_dist = enemy, dist
                        is_headshot = (monster_top <= hit_y <= monster_top + sprite_height * 0.3)

        if target_enemy:
            distance_ratio = min(min_dist / max_dmg_dist, 1.0)
            damage_multiplier = 1.0 - (0.8 * distance_ratio)

            if current_weapon == WEAPON_SHOTGUN:
                damage = 30 if is_headshot else 20
            else:
                final_base_damage = base_damage * damage_multiplier
                damage = int(final_base_damage * 1.5) if is_headshot else int(final_base_damage)

            if damage > 0:
                target_enemy['hp'] -= damage
                offset_x, offset_y = random.randint(-40, 40), random.randint(-40, 0)
                damage_texts.append({'text': f"{damage}", 'x': WIDTH // 2 + offset_x, 'y': HEIGHT // 2 + offset_y, 'color': YELLOW if is_headshot else WHITE, 'life': 45})
                if target_enemy['hp'] <= 0 and not target_enemy['dead']:
                    kill_enemy(target_enemy, is_headshot)
                elif is_multiplayer:
                    mp_send({'type': 'shoot', 'enemy_id': target_enemy['id'], 'damage': damage, 'headshot': is_headshot})
        else:
            target_x = player_x + math.cos(shot_angle) * (min_dist - 2)
            target_y = player_y + math.sin(shot_angle) * (min_dist - 2)
            wall_h_at_shot = (TILE_SIZE * current_proj_dist) / max(1.0, min_dist)
            hit_ratio = (-shot_pitch) / wall_h_at_shot if wall_h_at_shot > 0 else 0
            hole = {'x': target_x, 'y': target_y, 'ratio': hit_ratio, 'life': 300}
            bullet_holes.append(hole)
            if is_multiplayer:
                mp_send({'type': 'bullet_hole', 'hole': hole})

def draw_wall(ray, depth, angle):
    global Z_BUFFER
    depth *= math.cos(angle - player_angle)
    safe_depth = max(1.0, depth) 
    wall_height = (TILE_SIZE * current_proj_dist) / safe_depth
    wall_height = min(wall_height, HEIGHT * 4) 
    
    fog_ratio = min(1.0, safe_depth / MAX_DEPTH)
    intensity = max(0.0, 1.0 - fog_ratio)
    
    r = int(DOOM_WALL_BASE[0] * intensity + FOG_COLOR[0] * (1 - intensity))
    g = int(DOOM_WALL_BASE[1] * intensity + FOG_COLOR[1] * (1 - intensity))
    b = int(DOOM_WALL_BASE[2] * intensity + FOG_COLOR[2] * (1 - intensity))
    
    y_start = int(HEIGHT // 2 - wall_height // 2 + player_pitch)
    rect_x = int(ray * SCALE)
    next_x = int((ray + 1) * SCALE) 
    rect_w = next_x - rect_x + 2
    
    pygame.draw.rect(virtual_screen, (r, g, b), (rect_x, y_start, rect_w, int(wall_height)))
    Z_BUFFER[ray] = depth

def draw_items_and_enemies():
    render_list = []
    current_t = pygame.time.get_ticks()

    for item in items:
        render_list.append({'type': 'item', 'obj': item, 'dist': math.hypot(item['x'] - player_x, item['y'] - player_y)})
    for enemy in enemies:
        if not enemy['dead']:
            render_list.append({'type': 'enemy', 'obj': enemy, 'dist': math.hypot(enemy['x'] - player_x, enemy['y'] - player_y)})
    for pid, p in mp_other_players.items():
        if not p.get('dead', False):
            render_list.append({'type': 'other_player', 'obj': p, 'dist': math.hypot(p['x'] - player_x, p['y'] - player_y)})

    render_list.sort(key=lambda x: x['dist'], reverse=True)

    for entity in render_list:
        obj = entity['obj']
        dist = entity['dist']
        safe_dist = max(1.0, dist)

        dx, dy = obj['x'] - player_x, obj['y'] - player_y
        angle_to_obj = math.atan2(dy, dx)
        angle_diff = angle_to_obj - player_angle
        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi

        if abs(angle_diff) < current_fov / 2 + 0.3:
            screen_x = (WIDTH / 2) + (angle_diff / (current_fov / 2)) * (WIDTH / 2)
            wall_height = (TILE_SIZE * current_proj_dist) / safe_dist

            ray_idx = int(screen_x / SCALE)
            if 0 <= ray_idx < CASTED_RAYS and dist < Z_BUFFER[ray_idx] + 20:
                fog_ratio = min(1.0, dist / MAX_DEPTH)
                intensity = max(0.0, 1.0 - fog_ratio)

                if entity['type'] == 'enemy':
                    sprite_height = wall_height * 0.8
                    sprite_width = sprite_height * 0.7

                    bob_offset = math.sin((current_t / 150.0) + obj['anim_offset']) * (wall_height * 0.05)
                    monster_bottom = HEIGHT // 2 + wall_height // 2 + player_pitch + bob_offset
                    monster_top = monster_bottom - sprite_height

                    shadow_w = sprite_width * 0.8
                    shadow_h = wall_height * 0.1
                    pygame.draw.ellipse(virtual_screen, (10, 10, 10, int(100 * intensity)),
                                        (screen_x - shadow_w / 2, HEIGHT // 2 + wall_height // 2 + player_pitch - shadow_h / 2, shadow_w, shadow_h))

                    body_color = (int(160 * intensity + FOG_COLOR[0] * (1 - intensity)), int(40 * intensity + FOG_COLOR[1] * (1 - intensity)), int(50 * intensity + FOG_COLOR[2] * (1 - intensity)))
                    leg_color = (int(100 * intensity), int(20 * intensity), int(30 * intensity))

                    pygame.draw.polygon(virtual_screen, leg_color, [
                        (screen_x - sprite_width * 0.3, monster_bottom - sprite_height * 0.2),
                        (screen_x - sprite_width * 0.4, monster_bottom),
                        (screen_x - sprite_width * 0.1, monster_bottom)
                    ])
                    pygame.draw.polygon(virtual_screen, leg_color, [
                        (screen_x + sprite_width * 0.3, monster_bottom - sprite_height * 0.2),
                        (screen_x + sprite_width * 0.4, monster_bottom),
                        (screen_x + sprite_width * 0.1, monster_bottom)
                    ])

                    body_rect = pygame.Rect(screen_x - sprite_width // 2, monster_top + sprite_height * 0.1, sprite_width, sprite_height * 0.8)
                    pygame.draw.ellipse(virtual_screen, body_color, body_rect)

                    horn_color = (int(220 * intensity), int(200 * intensity), int(150 * intensity))
                    pygame.draw.polygon(virtual_screen, horn_color, [
                        (screen_x - sprite_width * 0.25, monster_top + sprite_height * 0.2),
                        (screen_x - sprite_width * 0.45, monster_top - sprite_height * 0.1),
                        (screen_x - sprite_width * 0.1, monster_top + sprite_height * 0.1)
                    ])
                    pygame.draw.polygon(virtual_screen, horn_color, [
                        (screen_x + sprite_width * 0.25, monster_top + sprite_height * 0.2),
                        (screen_x + sprite_width * 0.45, monster_top - sprite_height * 0.1),
                        (screen_x + sprite_width * 0.1, monster_top + sprite_height * 0.1)
                    ])

                    eye_bg_color = (int(255 * intensity), int(255 * intensity), int(0))
                    eye_pupil_color = (int(255 * intensity), 0, 0)
                    eye_w = sprite_width * 0.4
                    eye_h = sprite_height * 0.2
                    eye_y = monster_top + sprite_height * 0.25
                    pygame.draw.ellipse(virtual_screen, eye_bg_color, (screen_x - eye_w / 2, eye_y, eye_w, eye_h))
                    pygame.draw.ellipse(virtual_screen, eye_pupil_color, (screen_x - eye_w * 0.15, eye_y + eye_h * 0.2, eye_w * 0.3, eye_h * 0.6))

                    mouth_y = monster_top + sprite_height * 0.6
                    pygame.draw.arc(virtual_screen, BLACK, (screen_x - sprite_width * 0.3, mouth_y, sprite_width * 0.6, sprite_height * 0.2), math.pi, 0, 3)

                    hp_ratio = max(0, obj['hp']) / 150.0
                    bar_w = sprite_width * 0.8
                    bar_h = max(4, int(sprite_height * 0.05))
                    bar_x = screen_x - bar_w // 2
                    bar_y = monster_top - bar_h - max(5, int(wall_height * 0.05))
                    pygame.draw.rect(virtual_screen, (80, 0, 0), (bar_x, bar_y, bar_w, bar_h))
                    pygame.draw.rect(virtual_screen, (0, 180, 0), (bar_x, bar_y, int(bar_w * hp_ratio), bar_h))

                elif entity['type'] == 'item':
                    item_anim_y = math.sin(current_t / 200.0 + obj['anim']) * (wall_height * 0.05)
                    item_size = max(8, int(wall_height * 0.18))
                    item_bottom = HEIGHT // 2 + wall_height // 2 + player_pitch + item_anim_y

                    shadow_w = item_size * 2
                    pygame.draw.ellipse(virtual_screen, (10, 10, 10), (screen_x - shadow_w / 2, HEIGHT // 2 + wall_height // 2 + player_pitch, shadow_w, item_size * 0.3))

                    txt = None
                    if obj['type'] == 'ak':
                        color = (int(139 * intensity), int(69 * intensity), int(19 * intensity))
                        dark_gray = (int(50 * intensity), int(50 * intensity), int(50 * intensity))
                        pygame.draw.rect(virtual_screen, color, (screen_x - item_size, item_bottom - item_size, item_size * 2, item_size * 0.4))
                        pygame.draw.rect(virtual_screen, dark_gray, (screen_x - item_size * 1.2, item_bottom - item_size * 1.2, item_size * 1.5, item_size * 0.4))
                        pygame.draw.polygon(virtual_screen, dark_gray, [(screen_x - item_size * 0.2, item_bottom - item_size * 0.6), (screen_x + item_size * 0.2, item_bottom - item_size * 0.6), (screen_x + item_size * 0.4, item_bottom), (screen_x, item_bottom)])
                        txt = ITEM_FONT.render("AK-47", True, YELLOW)
                    elif obj['type'] == 'shotgun':
                        wood = (int(120 * intensity), int(60 * intensity), int(20 * intensity))
                        dark_metal = (int(40 * intensity), int(40 * intensity), int(40 * intensity))
                        pygame.draw.rect(virtual_screen, wood, (screen_x - item_size * 1.2, item_bottom - item_size * 0.8, item_size * 0.8, item_size * 0.6))
                        pygame.draw.rect(virtual_screen, dark_metal, (screen_x - item_size * 0.4, item_bottom - item_size * 1.1, item_size * 1.6, item_size * 0.4))
                        pygame.draw.rect(virtual_screen, wood, (screen_x + item_size * 0.2, item_bottom - item_size * 0.7, item_size * 0.6, item_size * 0.3))
                        txt = ITEM_FONT.render("SHOTGUN", True, WHITE)
                    elif obj['type'] == 'ak_ammo':
                        box_color = (int(100 * intensity), int(120 * intensity), int(100 * intensity))
                        pygame.draw.rect(virtual_screen, box_color, (screen_x - item_size * 0.8, item_bottom - item_size, item_size * 1.6, item_size), border_radius=2)
                        for i in range(3):
                            pygame.draw.line(virtual_screen, (int(200 * intensity), int(180 * intensity), 0), (screen_x - item_size * 0.4 + i * item_size * 0.4, item_bottom - item_size * 0.8), (screen_x - item_size * 0.4 + i * item_size * 0.4, item_bottom - item_size * 0.2), max(1, int(item_size * 0.1)))
                        txt = ITEM_FONT.render("AK AMMO", True, YELLOW)
                    elif obj['type'] == 'shotgun_ammo':
                        box_color = (int(150 * intensity), int(40 * intensity), int(40 * intensity))
                        gold = (int(200 * intensity), int(180 * intensity), 0)
                        pygame.draw.rect(virtual_screen, box_color, (screen_x - item_size * 0.8, item_bottom - item_size * 0.8, item_size * 1.6, item_size * 0.8), border_radius=2)
                        pygame.draw.circle(virtual_screen, gold, (screen_x - item_size * 0.3, item_bottom - item_size * 0.5), item_size * 0.2)
                        pygame.draw.circle(virtual_screen, gold, (screen_x + item_size * 0.3, item_bottom - item_size * 0.5), item_size * 0.2)
                        txt = ITEM_FONT.render("SG AMMO", True, RED)
                    elif obj['type'] == 'health':
                        box_color = (int(220 * intensity), int(220 * intensity), int(220 * intensity))
                        cross_color = (int(200 * intensity), 0, 0)
                        pygame.draw.rect(virtual_screen, box_color, (screen_x - item_size, item_bottom - item_size * 1.2, item_size * 2, item_size * 1.2), border_radius=3)
                        pygame.draw.rect(virtual_screen, cross_color, (screen_x - item_size * 0.2, item_bottom - item_size * 0.9, item_size * 0.4, item_size * 0.6))
                        pygame.draw.rect(virtual_screen, cross_color, (screen_x - item_size * 0.5, item_bottom - item_size * 0.75, item_size * 1.0, item_size * 0.3))
                        txt = ITEM_FONT.render("HP", True, RED)

                    if txt:
                        txt.set_alpha(int(255 * max(0.3, intensity)))
                        virtual_screen.blit(txt, (screen_x - txt.get_width() // 2, item_bottom - item_size - 30))

                elif entity['type'] == 'other_player':
                    _draw_other_player_sprite(obj, screen_x, wall_height, intensity)


def _draw_other_player_sprite(obj, screen_x, wall_height, intensity):
    sprite_height = wall_height * 0.85
    sprite_width = sprite_height * 0.55
    player_bottom = HEIGHT // 2 + wall_height // 2 + player_pitch
    player_top = player_bottom - sprite_height

    body_color = (int(30 * intensity + FOG_COLOR[0] * (1 - intensity)),
                  int(80 * intensity + FOG_COLOR[1] * (1 - intensity)),
                  int(200 * intensity + FOG_COLOR[2] * (1 - intensity)))
    leg_color = (int(20 * intensity), int(50 * intensity), int(150 * intensity))
    head_color = (int(200 * intensity), int(160 * intensity), int(100 * intensity))

    pygame.draw.polygon(virtual_screen, leg_color, [
        (screen_x - sprite_width * 0.25, player_bottom - sprite_height * 0.25),
        (screen_x - sprite_width * 0.35, player_bottom),
        (screen_x - sprite_width * 0.05, player_bottom)])
    pygame.draw.polygon(virtual_screen, leg_color, [
        (screen_x + sprite_width * 0.25, player_bottom - sprite_height * 0.25),
        (screen_x + sprite_width * 0.35, player_bottom),
        (screen_x + sprite_width * 0.05, player_bottom)])

    body_rect = pygame.Rect(screen_x - sprite_width // 2, player_top + sprite_height * 0.2, sprite_width, sprite_height * 0.6)
    pygame.draw.ellipse(virtual_screen, body_color, body_rect)

    head_r = sprite_width * 0.35
    pygame.draw.circle(virtual_screen, head_color, (int(screen_x), int(player_top + sprite_height * 0.15)), int(head_r))

    name_surf = ITEM_FONT.render("TEAM", True, (100, 200, 255))
    name_surf.set_alpha(int(255 * max(0.3, intensity)))
    virtual_screen.blit(name_surf, (screen_x - name_surf.get_width() // 2, player_top - 20))

    hp_ratio = max(0, obj.get('hp', 100)) / 100.0
    bar_w = sprite_width * 0.9
    bar_h = max(3, int(sprite_height * 0.04))
    bar_x = screen_x - bar_w // 2
    bar_y = player_top - bar_h - 22
    pygame.draw.rect(virtual_screen, (80, 0, 0), (bar_x, bar_y, bar_w, bar_h))
    pygame.draw.rect(virtual_screen, (0, 180, 0), (bar_x, bar_y, int(bar_w * hp_ratio), bar_h))

def draw_bullet_holes():
    global time_scale
    for hole in bullet_holes[:]:
        if game_state == STATE_PLAYING:
            hole['life'] -= 1 * time_scale
            if hole['life'] <= 0:
                bullet_holes.remove(hole); continue
        
        dx, dy = hole['x'] - player_x, hole['y'] - player_y
        dist = math.hypot(dx, dy)
        angle_diff = math.atan2(dy, dx) - player_angle
        
        while angle_diff < -math.pi: angle_diff += 2 * math.pi
        while angle_diff > math.pi: angle_diff -= 2 * math.pi
        
        if abs(angle_diff) < current_fov / 2 and dist > 1:
            screen_x = (WIDTH / 2) + (angle_diff / (current_fov / 2)) * (WIDTH / 2)
            wall_h_at_hole = (TILE_SIZE * current_proj_dist) / dist
            screen_y = HEIGHT // 2 - wall_h_at_hole * hole['ratio'] + player_pitch
            
            size = max(2, int(150 / dist))
            alpha = min(255, int((max(0, hole['life']) / 300) * 255))
            
            surf = pygame.Surface((size*2, size*2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (20, 20, 20, alpha), (size, size), size)
            pygame.draw.circle(surf, (0, 0, 0, alpha), (size, size), size*0.5)
            virtual_screen.blit(surf, (screen_x - size, screen_y - size))

def draw_damage_texts():
    global time_scale
    for dt in damage_texts[:]:
        if game_state == STATE_PLAYING:
            dt['life'] -= 1 * time_scale
            dt['y'] -= 1 * time_scale
            if dt['life'] <= 0:
                damage_texts.remove(dt); continue
        
        txt_surf = DMG_FONT.render(dt['text'], True, dt['color'])
        txt_surf.set_alpha(min(255, max(0, int(dt['life'] * 8))))
        virtual_screen.blit(txt_surf, (dt['x'] - txt_surf.get_width()//2, dt['y']))

def draw_weapon():
    global gun_recoil, walk_timer, time_scale
    
    bob_x = 0
    bob_y = 0
    if player_is_moving and not is_aiming and game_state == STATE_PLAYING:
        walk_timer += 0.15 * time_scale
        bob_x = math.cos(walk_timer) * 15
        bob_y = abs(math.sin(walk_timer)) * 15
    else:
        walk_timer = 0
        
    actual_recoil = gun_recoil * 4.0 if current_weapon == WEAPON_SHOTGUN else gun_recoil
    gun_base_pos = HEIGHT + 250 if is_reloading else HEIGHT + 80 + actual_recoil + bob_y
    center_x = WIDTH // 2 + bob_x
    
    SKIN_COLOR = (224, 172, 105)
    
    if is_melee_attacking:
        progress = melee_timer / 15.0
        offset_y = math.sin(progress * math.pi) * 80
        blade_color = (200, 200, 200)
        handle_color = (50, 50, 50)
        pygame.draw.polygon(virtual_screen, blade_color, [(center_x + 20, HEIGHT - offset_y), (center_x + 35, HEIGHT - 150 - offset_y), (center_x + 45, HEIGHT - offset_y)])
        pygame.draw.rect(virtual_screen, handle_color, (center_x + 25, HEIGHT - offset_y, 15, 80))
        return 
    
    if current_weapon == WEAPON_PISTOL:
        metal_light = (110, 110, 110) 
        metal_dark = (50, 50, 50)     
        grip_color = (20, 20, 20)      
        SKIN_COLOR = (210, 160, 120)  

        if is_aiming:
            weapon_x = WIDTH // 2
            ZOOM_Y_OFFSET_PISTOL = 290 
            weapon_y = HEIGHT // 2 + ZOOM_Y_OFFSET_PISTOL
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        slide_top = weapon_y - 250 

        if is_shooting:
            flash_y = slide_top
            pygame.draw.circle(virtual_screen, (255, 150, 0), (weapon_x, flash_y), 25)
            pygame.draw.circle(virtual_screen, (255, 255, 200), (weapon_x, flash_y), 15)
            pygame.draw.polygon(virtual_screen, (255, 200, 0), [
                (weapon_x, flash_y - 40), (weapon_x - 8, flash_y - 10),
                (weapon_x - 30, flash_y), (weapon_x - 8, flash_y + 10),
                (weapon_x, flash_y + 20), (weapon_x + 8, flash_y + 10),
                (weapon_x + 30, flash_y), (weapon_x + 8, flash_y - 10)
            ])

        if is_aiming:
            arm_width = 180 
            arm_top = HEIGHT 
            arm_bottom = weapon_y - 120 
            pygame.draw.polygon(virtual_screen, SKIN_COLOR, [
                (weapon_x - 180, arm_top),                
                (weapon_x - 90, arm_bottom + 30),         
                (weapon_x - 20, arm_bottom - 20),         
                (weapon_x - 80, arm_top)                   
            ])
            pygame.draw.polygon(virtual_screen, SKIN_COLOR, [
                (weapon_x + 180, arm_top),                
                (weapon_x + 90, arm_bottom + 30),         
                (weapon_x + 20, arm_bottom - 20),         
                (weapon_x + 80, arm_top)                   
            ])

        grip_top = weapon_y - 150
        grip_bottom = weapon_y + 100 
        pygame.draw.polygon(virtual_screen, grip_color, [
            (weapon_x - 45, grip_top),        
            (weapon_x + 45, grip_top),        
            (weapon_x + 65, grip_bottom),     
            (weapon_x - 65, grip_bottom),     
        ])
        for i in range(1, 4):
             pygame.draw.line(virtual_screen, (40, 40, 40), (weapon_x - 30, grip_top + i*30), (weapon_x + 30, grip_top + i*30), 4)

        body_top = weapon_y - 180
        pygame.draw.rect(virtual_screen, metal_dark, (weapon_x - 40, body_top, 80, 100)) 
        pygame.draw.polygon(virtual_screen, metal_dark, [
            (weapon_x - 35, body_top + 90), (weapon_x + 35, body_top + 90),
            (weapon_x + 30, body_top + 130), (weapon_x - 30, body_top + 130)
        ], 8)

        pygame.draw.rect(virtual_screen, metal_light, (weapon_x - 35, slide_top, 70, 140), border_radius=3)
        pygame.draw.rect(virtual_screen, (10, 10, 10), (weapon_x - 12, slide_top - 10, 24, 15))
        pygame.draw.rect(virtual_screen, BLACK, (weapon_x + 18, slide_top + 30, 12, 50))

    elif current_weapon == WEAPON_AK:
        if is_aiming:
            weapon_x = WIDTH // 2
            ZOOM_Y_OFFSET_AK = 350
            weapon_y = HEIGHT // 2 + ZOOM_Y_OFFSET_AK
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        if is_shooting and random.random() > 0.4:
            flash_y = weapon_y - 330
            pygame.draw.circle(virtual_screen, (255, 150, 0), (weapon_x, flash_y), 20)
            pygame.draw.circle(virtual_screen, (255, 255, 200), (weapon_x, flash_y), 10)
            pygame.draw.polygon(virtual_screen, (255, 200, 0), [
                (weapon_x, flash_y - 25), (weapon_x - 6, flash_y - 6),
                (weapon_x - 20, flash_y), (weapon_x - 6, flash_y + 6),
                (weapon_x, flash_y + 12), (weapon_x + 6, flash_y + 6),
                (weapon_x + 20, flash_y), (weapon_x + 6, flash_y - 6)])

        wood = (120, 60, 20)
        pygame.draw.rect(virtual_screen, wood, (weapon_x - 40, weapon_y - 150, 80, 150), border_radius=10)
        pygame.draw.polygon(virtual_screen, (30, 30, 30), [(weapon_x - 20, weapon_y - 150), (weapon_x + 20, weapon_y - 150), (weapon_x + 40, weapon_y - 50), (weapon_x, weapon_y - 30)])
        pygame.draw.rect(virtual_screen, (40, 40, 40), (weapon_x - 25, weapon_y - 320, 50, 200), border_radius=2)
        pygame.draw.rect(virtual_screen, wood, (weapon_x - 30, weapon_y - 280, 60, 80), border_radius=5)
        pygame.draw.rect(virtual_screen, (20, 20, 20), (weapon_x - 5, weapon_y - 330, 10, 10))

        if is_aiming:
            SKIN_COLOR = (210, 160, 120)
            pygame.draw.rect(virtual_screen, SKIN_COLOR, (weapon_x - 50, weapon_y - 280, 25, 70), border_radius=12)
            pygame.draw.rect(virtual_screen, SKIN_COLOR, (weapon_x + 20, weapon_y - 150, 35, 90), border_radius=15)

    elif current_weapon == WEAPON_SHOTGUN:
        if is_aiming:
            weapon_x = WIDTH // 2
            ZOOM_Y_OFFSET = 90
            weapon_y = HEIGHT // 2 + ZOOM_Y_OFFSET
        else:
            weapon_x = center_x
            weapon_y = gun_base_pos

        if is_shooting:
            flash_y = weapon_y - 380
            pygame.draw.circle(virtual_screen, (255, 100, 0), (weapon_x, flash_y), 45)
            pygame.draw.circle(virtual_screen, (255, 255, 150), (weapon_x, flash_y), 25)
            pygame.draw.polygon(virtual_screen, (255, 150, 0), [
                (weapon_x, flash_y - 60), (weapon_x - 15, flash_y - 15),
                (weapon_x - 50, flash_y), (weapon_x - 15, flash_y + 15),
                (weapon_x, flash_y + 30), (weapon_x + 15, flash_y + 15),
                (weapon_x + 50, flash_y), (weapon_x + 15, flash_y - 15)])

        wood = (120, 60, 20)
        metal = (50, 50, 50)
        dark_metal = (35, 35, 35)

        pygame.draw.rect(virtual_screen, wood, (weapon_x - 38, weapon_y - 155, 76, 155), border_radius=8)
        pygame.draw.rect(virtual_screen, metal, (weapon_x - 35, weapon_y - 260, 70, 110))
        pygame.draw.rect(virtual_screen, wood, (weapon_x - 38, weapon_y - 240, 76, 60), border_radius=5)

        barrel_width = 25
        barrel_spacing = 6
        barrel_x1 = weapon_x - barrel_width - (barrel_spacing // 2)
        barrel_x2 = weapon_x + (barrel_spacing // 2)

        pygame.draw.rect(virtual_screen, dark_metal, (barrel_x1, weapon_y - 370, barrel_width, 110))
        pygame.draw.rect(virtual_screen, dark_metal, (barrel_x2, weapon_y - 370, barrel_width, 110))
        pygame.draw.rect(virtual_screen, (10, 10, 10), (weapon_x - 6, weapon_y - 380, 12, 10))

    if game_state == STATE_PLAYING:
        decay = 10 if current_weapon == WEAPON_AK else 5
        gun_recoil = max(0, gun_recoil - (decay * time_scale))

def draw_minimap():
    margin, tile_size = 20, 5
    map_w, map_h = MAP_W * tile_size, MAP_H * tile_size
    start_x, start_y = WIDTH - map_w - margin, margin
    
    minimap_surf = pygame.Surface((map_w, map_h), pygame.SRCALPHA)
    minimap_surf.fill((0, 0, 0, 150))
    virtual_screen.blit(minimap_surf, (start_x, start_y))
    
    for y, row in enumerate(MAP):
        for x, tile in enumerate(row):
            if tile == 1: pygame.draw.rect(virtual_screen, GRAY, (start_x + x * tile_size, start_y + y * tile_size, tile_size, tile_size))
            
    p_map_x, p_map_y = int((player_x / TILE_SIZE) * tile_size), int((player_y / TILE_SIZE) * tile_size)
    pygame.draw.circle(virtual_screen, GREEN, (start_x + p_map_x, start_y + p_map_y), tile_size // 2)
    view_x = p_map_x + math.cos(player_angle) * (tile_size * 2)
    view_y = p_map_y + math.sin(player_angle) * (tile_size * 2)
    pygame.draw.line(virtual_screen, GREEN, (start_x + p_map_x, start_y + p_map_y), (start_x + view_x, start_y + view_y), 1)
    
    for enemy in enemies:
        if enemy['dead']: continue
        e_map_x, e_map_y = int((enemy['x'] / TILE_SIZE) * tile_size), int((enemy['y'] / TILE_SIZE) * tile_size)
        pygame.draw.circle(virtual_screen, RED, (start_x + e_map_x, start_y + e_map_y), max(1, tile_size // 3))
        
    for item in items:
        i_map_x, i_map_y = int((item['x'] / TILE_SIZE) * tile_size), int((item['y'] / TILE_SIZE) * tile_size)
        color = YELLOW if 'ak' in item['type'] else WHITE if 'shotgun' in item['type'] else GREEN
        pygame.draw.circle(virtual_screen, color, (start_x + i_map_x, start_y + i_map_y), max(1, tile_size // 3))

    for pid, p in mp_other_players.items():
        if p.get('dead', False):
            continue
        pm_x = int((p['x'] / TILE_SIZE) * tile_size)
        pm_y = int((p['y'] / TILE_SIZE) * tile_size)
        pygame.draw.circle(virtual_screen, (100, 200, 255), (start_x + pm_x, start_y + pm_y), max(1, tile_size // 2))

def draw_ui():
    global player_health, current_score, current_pistol_ammo, current_ak_ammo, ak_reserve_ammo, current_shotgun_ammo, shotgun_reserve_ammo

    ui_start_x = 20
    ui_start_y = HEIGHT - 80 
    ak_status = "AK-47" if has_ak else "Empty"
    sg_status = "샷건" if has_shotgun else "Empty"
    weapon_names = ["[1] 권총", f"[2] {ak_status}", f"[3] {sg_status}"]
    
    for i, w_name in enumerate(weapon_names):
        is_current = (current_weapon == i)
        bg_color = (60, 100, 60) if is_current else (40, 40, 40)
        text_color = WHITE if is_current else (150, 150, 150)
        border_color = (100, 255, 100) if is_current else (80, 80, 80)
        
        if i == 1 and not has_ak: text_color = RED
        if i == 2 and not has_shotgun: text_color = RED
            
        w_surf = SMALL_UI_FONT.render(w_name, True, text_color)
        w_rect = w_surf.get_rect()
        
        box_rect = pygame.Rect(ui_start_x + (i * 120), ui_start_y, 110, 40)
        pygame.draw.rect(virtual_screen, bg_color, box_rect, border_radius=6)
        pygame.draw.rect(virtual_screen, border_color, box_rect, 2, border_radius=6)
        
        w_rect.center = box_rect.center
        virtual_screen.blit(w_surf, w_rect)

    bar_w = 300
    bar_h = 12
    bar_x = WIDTH // 2 - bar_w // 2
    
    stamina_y = HEIGHT - 30
    stamina_ratio = max(0, player_stamina) / max_stamina
    stamina_color = (100, 200, 255) 
    pygame.draw.rect(virtual_screen, (50, 50, 50), (bar_x, stamina_y, bar_w, bar_h))
    pygame.draw.rect(virtual_screen, stamina_color, (bar_x, stamina_y, int(bar_w * stamina_ratio), bar_h))
    pygame.draw.rect(virtual_screen, WHITE, (bar_x, stamina_y, bar_w, bar_h), 1)

    hp_y = stamina_y - bar_h - 6
    hp_ratio = max(0, player_health) / 100.0
    hp_color = (100, 255, 100) 
    pygame.draw.rect(virtual_screen, (50, 50, 50), (bar_x, hp_y, bar_w, bar_h))
    pygame.draw.rect(virtual_screen, hp_color, (bar_x, hp_y, int(bar_w * hp_ratio), bar_h))
    pygame.draw.rect(virtual_screen, WHITE, (bar_x, hp_y, bar_w, bar_h), 1)

    virtual_screen.blit(PROG_FONT.render(f"점수: {current_score}", True, WHITE), (20, 20))
    virtual_screen.blit(PROG_FONT.render(f"체력: {int(max(0, player_health))}", True, hp_color), (20, HEIGHT - 160))
    virtual_screen.blit(SMALL_UI_FONT.render(f"[F] 근접공격", True, WHITE), (20, HEIGHT - 110))

    if is_multiplayer:
        y_off = 50
        for pid, p in mp_other_players.items():
            short_id = pid.split(':')[-1]
            team_txt = SMALL_UI_FONT.render(f"팀원 {short_id}  HP:{int(p.get('hp', 0))}  점수:{p.get('score', 0)}", True, (100, 200, 255))
            virtual_screen.blit(team_txt, (20, y_off))
            y_off += 28

    if is_reloading:
        time_left = max(0.0, (reload_end - pygame.time.get_ticks()) / 1000.0)
        ammo_text = PROG_FONT.render(f"장전 중... {time_left:.1f}초", True, YELLOW)
    else:
        if current_weapon == WEAPON_PISTOL:
            ammo_text = PROG_FONT.render(f"탄약: {current_pistol_ammo} / ∞", True, WHITE)
        elif current_weapon == WEAPON_AK:
            ammo_text = PROG_FONT.render(f"탄약: {current_ak_ammo} / {ak_reserve_ammo}", True, YELLOW)
        elif current_weapon == WEAPON_SHOTGUN:
            ammo_text = PROG_FONT.render(f"탄약: {current_shotgun_ammo} / {shotgun_reserve_ammo}", True, BROWN)
    virtual_screen.blit(ammo_text, (WIDTH - 250, HEIGHT - 40))

    if current_weapon == WEAPON_SHOTGUN:
        pygame.draw.circle(virtual_screen, RED, (WIDTH // 2, HEIGHT // 2), 20, 2)  
        pygame.draw.circle(virtual_screen, RED, (WIDTH // 2, HEIGHT // 2), 2)   
    else:
        c_size = 15 
        pygame.draw.line(virtual_screen, RED, (WIDTH // 2 - c_size, HEIGHT // 2), (WIDTH // 2 + c_size, HEIGHT // 2), 2)
        pygame.draw.line(virtual_screen, RED, (WIDTH // 2, HEIGHT // 2 - c_size), (WIDTH // 2, HEIGHT // 2 + c_size), 2)

    for i, notice in enumerate(pickup_notices):
        n_surf = SMALL_UI_FONT.render(notice['text'], True, notice['color'])
        n_surf.set_alpha(min(255, max(0, int(notice['timer'] * 10))))
        virtual_screen.blit(n_surf, (WIDTH - n_surf.get_width() - 20, HEIGHT // 2 + i * 30))

def draw_ip_input_screen():
    global ip_cursor_visible, ip_cursor_timer

    title_txt = TITLE_FONT.render("멀티플레이", True, (100, 170, 255))
    guide_txt = PROG_FONT.render("서버 IP 주소를 입력하세요", True, WHITE)

    virtual_screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 120))
    virtual_screen.blit(guide_txt, (WIDTH // 2 - guide_txt.get_width() // 2, 240))

    pygame.draw.rect(virtual_screen, (25, 25, 35), ip_input_rect, border_radius=8)
    pygame.draw.rect(virtual_screen, (100, 170, 255), ip_input_rect, 2, border_radius=8)

    now = pygame.time.get_ticks()
    if now - ip_cursor_timer > 500:
        ip_cursor_timer = now
        ip_cursor_visible = not ip_cursor_visible

    shown_text = ip_input_text
    if ip_cursor_visible and not ip_connecting:
        shown_text += '|'

    txt_surf = INPUT_FONT.render(shown_text if shown_text else "예: 192.168.0.10:55555", True, WHITE if shown_text else LIGHT_GRAY)
    virtual_screen.blit(txt_surf, (ip_input_rect.x + 12, ip_input_rect.centery - txt_surf.get_height() // 2))

    if ip_connecting:
        conn_txt = PROG_FONT.render("접속 중...", True, YELLOW)
        virtual_screen.blit(conn_txt, (WIDTH // 2 - conn_txt.get_width() // 2, 400))
    else:
        pygame.draw.rect(virtual_screen, (30, 100, 30), ip_connect_btn_rect, border_radius=10)
        pygame.draw.rect(virtual_screen, GREEN, ip_connect_btn_rect, 2, border_radius=10)
        conn_btn_txt = PROG_FONT.render("접속", True, WHITE)
        virtual_screen.blit(conn_btn_txt, (ip_connect_btn_rect.centerx - conn_btn_txt.get_width() // 2, ip_connect_btn_rect.centery - conn_btn_txt.get_height() // 2))

        pygame.draw.rect(virtual_screen, GRAY, ip_back_btn_rect, border_radius=10)
        pygame.draw.rect(virtual_screen, WHITE, ip_back_btn_rect, 2, border_radius=10)
        back_txt = PROG_FONT.render("뒤로", True, WHITE)
        virtual_screen.blit(back_txt, (ip_back_btn_rect.centerx - back_txt.get_width() // 2, ip_back_btn_rect.centery - back_txt.get_height() // 2))

    if mp_connect_error:
        err_txt = SMALL_UI_FONT.render(f"오류: {mp_connect_error}", True, RED)
        virtual_screen.blit(err_txt, (WIDTH // 2 - err_txt.get_width() // 2, 560))

    hint_txt = SMALL_UI_FONT.render("포트 기본값: 55555  |  서버 실행: python doom_server_updated.py", True, GRAY)
    virtual_screen.blit(hint_txt, (WIDTH // 2 - hint_txt.get_width() // 2, 610))


def try_connect_to_server(ip_str):
    global ip_connecting, game_state, is_multiplayer, mp_connect_error

    ip_str = ip_str.strip()
    port = 55555
    if ':' in ip_str:
        parts = ip_str.rsplit(':', 1)
        try:
            port = int(parts[1])
            ip_str = parts[0]
        except ValueError:
            pass

    success = mp_connect(ip_str, port)
    ip_connecting = False

    if success:
        is_multiplayer = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
    else:
        game_state = STATE_IP_INPUT

def render_scene():
    virtual_screen.fill(FOG_COLOR)

    if game_state == STATE_MAIN_MENU:
        title_txt = TITLE_FONT.render("RETRO FPS", True, RED)
        virtual_screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 100))
        pygame.draw.rect(virtual_screen, GRAY, single_btn_rect, border_radius=10)
        pygame.draw.rect(virtual_screen, WHITE, single_btn_rect, 3, border_radius=10)
        pygame.draw.rect(virtual_screen, (30, 60, 120), multi_btn_rect, border_radius=10)
        pygame.draw.rect(virtual_screen, (100, 150, 255), multi_btn_rect, 3, border_radius=10)
        pygame.draw.rect(virtual_screen, RED, main_quit_btn_rect, border_radius=10)
        pygame.draw.rect(virtual_screen, WHITE, main_quit_btn_rect, 3, border_radius=10)
        single_txt = PROG_FONT.render("싱글플레이", True, WHITE)
        multi_txt = PROG_FONT.render("멀티플레이", True, (150, 200, 255))
        quit_txt = PROG_FONT.render("게임 종료", True, WHITE)
        virtual_screen.blit(single_txt, (single_btn_rect.centerx - single_txt.get_width() // 2, single_btn_rect.centery - single_txt.get_height() // 2))
        virtual_screen.blit(multi_txt, (multi_btn_rect.centerx - multi_txt.get_width() // 2, multi_btn_rect.centery - multi_txt.get_height() // 2))
        virtual_screen.blit(quit_txt, (main_quit_btn_rect.centerx - quit_txt.get_width() // 2, main_quit_btn_rect.centery - quit_txt.get_height() // 2))

    elif game_state == STATE_IP_INPUT:
        draw_ip_input_screen()

    else:
        virtual_screen.blit(bg_surface, (0, -HEIGHT // 2 + player_pitch))
        start_angle = player_angle - (current_fov / 2)

        for ray in range(CASTED_RAYS):
            ray_angle = start_angle + ray * STEP_ANGLE
            sin_a, cos_a = math.sin(ray_angle), math.cos(ray_angle)
            hit = False
            for depth in range(1, int(MAX_DEPTH), 8):
                test_x, test_y = player_x + cos_a * depth, player_y + sin_a * depth
                if not (0 <= test_x < MAP_W * TILE_SIZE and 0 <= test_y < MAP_H * TILE_SIZE):
                    break
                if MAP[int(test_y / TILE_SIZE)][int(test_x / TILE_SIZE)] == 1:
                    refined_depth = depth - 7
                    for _ in range(8):
                        test_x, test_y = player_x + cos_a * refined_depth, player_y + sin_a * refined_depth
                        if MAP[int(test_y / TILE_SIZE)][int(test_x / TILE_SIZE)] == 1:
                            draw_wall(ray, refined_depth, ray_angle)
                            hit = True
                            break
                        refined_depth += 1
                    if hit:
                        break

        draw_bullet_holes()
        draw_items_and_enemies()
        draw_damage_texts()

        if not player_dead:
            draw_weapon()
            draw_ui()
            draw_minimap()

        if game_state == STATE_COUNTDOWN:
            elapsed = pygame.time.get_ticks() - countdown_start
            remains = 3 - (elapsed // 1000)
            if remains > 0:
                overlay = pygame.Surface((WIDTH, HEIGHT))
                overlay.set_alpha(100)
                overlay.fill(BLACK)
                virtual_screen.blit(overlay, (0, 0))
                count_txt = GO_FONT.render(str(remains), True, YELLOW)
                virtual_screen.blit(count_txt, (WIDTH // 2 - count_txt.get_width() // 2, HEIGHT // 2 - count_txt.get_height() // 2))
            elif remains == 0:
                go_txt = GO_FONT.render("GO!", True, GREEN)
                virtual_screen.blit(go_txt, (WIDTH // 2 - go_txt.get_width() // 2, HEIGHT // 2 - go_txt.get_height() // 2))

        if game_state == STATE_PAUSED:
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(180)
            overlay.fill(BLACK)
            virtual_screen.blit(overlay, (0, 0))

            pause_text = TITLE_FONT.render("일시정지", True, WHITE)
            virtual_screen.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, 80))

            sens_txt = PROG_FONT.render("마우스 감도 설정", True, WHITE)
            virtual_screen.blit(sens_txt, (WIDTH // 2 - sens_txt.get_width() // 2, 175))

            minus_color = GRAY if sens_mult <= 0.1 else RED
            plus_color = GREEN
            reset_color = (50, 100, 200)

            pygame.draw.rect(virtual_screen, minus_color, sens_minus_btn_rect, border_radius=5)
            pygame.draw.rect(virtual_screen, plus_color, sens_plus_btn_rect, border_radius=5)
            pygame.draw.rect(virtual_screen, reset_color, sens_reset_btn_rect, border_radius=5)

            minus_text, plus_text = PROG_FONT.render("-", True, WHITE), PROG_FONT.render("+", True, WHITE)
            reset_text = DMG_FONT.render("초기화", True, WHITE)

            virtual_screen.blit(minus_text, (sens_minus_btn_rect.centerx - minus_text.get_width() // 2, sens_minus_btn_rect.centery - minus_text.get_height() // 2))
            virtual_screen.blit(plus_text, (sens_plus_btn_rect.centerx - plus_text.get_width() // 2, sens_plus_btn_rect.centery - plus_text.get_height() // 2))
            virtual_screen.blit(reset_text, (sens_reset_btn_rect.centerx - reset_text.get_width() // 2, sens_reset_btn_rect.centery - reset_text.get_height() // 2))

            sens_val_text = PROG_FONT.render(f"{sens_mult:.1f} x", True, YELLOW)
            virtual_screen.blit(sens_val_text, (WIDTH // 2 - sens_val_text.get_width() // 2, sens_minus_btn_rect.centery - sens_val_text.get_height() // 2))

            pygame.draw.rect(virtual_screen, GRAY, resume_btn_rect, border_radius=10)
            pygame.draw.rect(virtual_screen, WHITE, resume_btn_rect, 3, border_radius=10)
            pygame.draw.rect(virtual_screen, GRAY, retry_btn_rect, border_radius=10)
            pygame.draw.rect(virtual_screen, WHITE, retry_btn_rect, 3, border_radius=10)
            pygame.draw.rect(virtual_screen, GRAY, mainmenu_btn_rect, border_radius=10)
            pygame.draw.rect(virtual_screen, WHITE, mainmenu_btn_rect, 3, border_radius=10)
            pygame.draw.rect(virtual_screen, RED, quit_btn_rect, border_radius=10)
            pygame.draw.rect(virtual_screen, WHITE, quit_btn_rect, 3, border_radius=10)

            resume_text = PROG_FONT.render("계속하기", True, WHITE)
            retry_text = PROG_FONT.render("다시하기", True, WHITE)
            mainmenu_text = PROG_FONT.render("메인 메뉴로", True, WHITE)
            quit_text = PROG_FONT.render("게임 종료", True, WHITE)

            virtual_screen.blit(resume_text, (resume_btn_rect.centerx - resume_text.get_width() // 2, resume_btn_rect.centery - resume_text.get_height() // 2))
            virtual_screen.blit(retry_text, (retry_btn_rect.centerx - retry_text.get_width() // 2, retry_btn_rect.centery - retry_text.get_height() // 2))
            virtual_screen.blit(mainmenu_text, (mainmenu_btn_rect.centerx - mainmenu_text.get_width() // 2, mainmenu_btn_rect.centery - mainmenu_text.get_height() // 2))
            virtual_screen.blit(quit_text, (quit_btn_rect.centerx - quit_text.get_width() // 2, quit_btn_rect.centery - quit_text.get_height() // 2))

        if game_state == STATE_GAMEOVER:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((150, 0, 0, 100))
            virtual_screen.blit(overlay, (0, 0))

            died_text = GO_FONT.render("사망했습니다", True, RED)
            virtual_screen.blit(died_text, (WIDTH // 2 - died_text.get_width() // 2, HEIGHT // 2 - died_text.get_height() // 2 - 50))

            final_score_text = PROG_FONT.render(f"최종 점수: {current_score}", True, WHITE)
            virtual_screen.blit(final_score_text, (WIDTH // 2 - final_score_text.get_width() // 2, HEIGHT // 2 + 50))

            restart_text = PROG_FONT.render("ESC를 눌러 메인 화면으로", True, GREEN)
            if pygame.time.get_ticks() % 1000 < 600:
                virtual_screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 120))

    if damage_flash_timer > 0 and game_state == STATE_PLAYING:
        alpha = min(30, max(0, int(damage_flash_timer * 2)))
        flash_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        flash_surf.fill((255, 0, 0, alpha))
        virtual_screen.blit(flash_surf, (0, 0))

    if damage_text_timer > 0 and game_state == STATE_PLAYING:
        box_w, box_h = 400, 60
        box_x, box_y = WIDTH // 2 - box_w // 2, 50
        box_surf = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        box_surf.fill((0, 0, 0, 200))
        msg_surf = PROG_FONT.render("피격당했습니다! -10 HP", True, RED)
        box_padding_x = (box_w - msg_surf.get_width()) // 2
        box_padding_y = (box_h - msg_surf.get_height()) // 2
        pygame.draw.rect(box_surf, RED, (0, 0, box_w, box_h), 2, border_radius=5)
        virtual_screen.blit(box_surf, (box_x, box_y))
        virtual_screen.blit(msg_surf, (box_x + box_padding_x, box_y + box_padding_y))

    if heal_effect_timer > 0:
        alpha = min(255, int(heal_effect_timer * 8))
        heal_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        heal_surf.fill((0, 255, 0, min(20, int((heal_effect_timer / 40) * 20))))
        virtual_screen.blit(heal_surf, (0, 0))

# ==========================================
# --- 메인 게임 루프 ---
# ==========================================
while True:
    dt = clock.tick(60) / 1000.0
    time_scale = min(dt * 60.0, 3.0)

    keys = pygame.key.get_pressed()
    current_time = pygame.time.get_ticks()

    is_aiming = pygame.mouse.get_pressed()[2] and not is_reloading and not player_dead and game_state == STATE_PLAYING and not is_melee_attacking and current_weapon != WEAPON_SHOTGUN
    target_fov = (math.pi / 6) if is_aiming else BASE_FOV
    current_fov += (target_fov - current_fov) * 0.15 * time_scale
    STEP_ANGLE = current_fov / CASTED_RAYS
    current_proj_dist = (WIDTH / 2) / math.tan(current_fov / 2)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            mp_disconnect()
            pygame.quit(); exit()

        if event.type == pygame.VIDEORESIZE and not is_fullscreen:
            current_win_size = (event.w, event.h)
            screen = pygame.display.set_mode(current_win_size, pygame.RESIZABLE)

        if game_state == STATE_IP_INPUT:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    game_state = STATE_MAIN_MENU
                elif event.key == pygame.K_BACKSPACE:
                    ip_input_text = ip_input_text[:-1]
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if ip_input_text.strip() and not ip_connecting:
                        ip_connecting = True
                        t = threading.Thread(target=try_connect_to_server, args=(ip_input_text,), daemon=True)
                        t.start()
                else:
                    ch = event.unicode
                    if ch and (ch.isdigit() or ch in '.:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_'):
                        if len(ip_input_text) < 40:
                            ip_input_text += ch
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                virtual_mouse_pos = get_virtual_mouse_pos(mouse_x, mouse_y)
                if ip_connect_btn_rect.collidepoint(virtual_mouse_pos) and not ip_connecting:
                    if ip_input_text.strip():
                        ip_connecting = True
                        t = threading.Thread(target=try_connect_to_server, args=(ip_input_text,), daemon=True)
                        t.start()
                elif ip_back_btn_rect.collidepoint(virtual_mouse_pos):
                    game_state = STATE_MAIN_MENU
            continue

        if game_state == STATE_GAMEOVER:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # 👉 ESC 키인지 확인하는 조건 추가
                    if is_multiplayer:
                        mp_disconnect()
                    game_state = STATE_MAIN_MENU
                    pygame.mouse.set_visible(True)
                    pygame.event.set_grab(False)

        elif event.type == pygame.MOUSEWHEEL and game_state == STATE_PLAYING and not player_dead:
            if event.y != 0:
                step = -1 if event.y > 0 else 1
                for _ in range(3):
                    current_weapon = (current_weapon + step) % 3
                    if current_weapon == WEAPON_PISTOL:
                        break
                    if current_weapon == WEAPON_AK and has_ak:
                        break
                    if current_weapon == WEAPON_SHOTGUN and has_shotgun:
                        break
                is_reloading = False

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if game_state == STATE_PLAYING and not player_dead:
                if current_weapon in [WEAPON_PISTOL, WEAPON_SHOTGUN]:
                    shoot()
            elif game_state == STATE_PAUSED:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                virtual_mouse_pos = get_virtual_mouse_pos(mouse_x, mouse_y)
                if sens_minus_btn_rect.collidepoint(virtual_mouse_pos):
                    sens_mult = max(0.1, sens_mult - 0.1)
                elif sens_plus_btn_rect.collidepoint(virtual_mouse_pos):
                    sens_mult = min(5.0, sens_mult + 0.1)
                elif sens_reset_btn_rect.collidepoint(virtual_mouse_pos):
                    sens_mult = 1.0
                elif resume_btn_rect.collidepoint(virtual_mouse_pos):
                    game_state = STATE_PLAYING
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()
                elif retry_btn_rect.collidepoint(virtual_mouse_pos):
                    if is_multiplayer:
                        mp_disconnect()
                    init_game()
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()
                elif mainmenu_btn_rect.collidepoint(virtual_mouse_pos):
                    if is_multiplayer:
                        mp_disconnect()
                    game_state = STATE_MAIN_MENU
                    pygame.mouse.set_visible(True)
                    pygame.event.set_grab(False)
                elif quit_btn_rect.collidepoint(virtual_mouse_pos):
                    mp_disconnect()
                    pygame.quit(); exit()
            elif game_state == STATE_MAIN_MENU:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                virtual_mouse_pos = get_virtual_mouse_pos(mouse_x, mouse_y)
                if single_btn_rect.collidepoint(virtual_mouse_pos):
                    is_multiplayer = False
                    init_game()
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()
                elif multi_btn_rect.collidepoint(virtual_mouse_pos):
                    ip_input_text = ''
                    mp_connect_error = ''
                    ip_connecting = False
                    game_state = STATE_IP_INPUT
                elif main_quit_btn_rect.collidepoint(virtual_mouse_pos):
                    mp_disconnect()
                    pygame.quit(); exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_f:
                trigger_melee()
            if event.key == pygame.K_r and not player_dead and game_state == STATE_PLAYING:
                if current_weapon == WEAPON_PISTOL:
                    start_reload()
                    play_and_broadcast_sound('pistol_reload') # 👉 장전 소리 재생 및 전송
                elif current_weapon == WEAPON_AK:
                    start_reload()
                    play_and_broadcast_sound('ak_reload') # 👉 AK 장전 소리
                elif currernt_weapon == WEAPON_SHOTGUN:
                    start_reload()
                    play_and_broadcast_sound('shotgun_reload') # 👉 샷건 장전 소리
            if event.key == pygame.K_ESCAPE:
                if game_state == STATE_PLAYING:
                    game_state = STATE_PAUSED
                    pygame.mouse.set_visible(True)
                    pygame.event.set_grab(False)
                elif game_state == STATE_PAUSED:
                    game_state = STATE_PLAYING
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()
            if event.key == pygame.K_F11:
                is_fullscreen = not is_fullscreen
                if is_fullscreen:
                    current_win_size = (pygame.display.Info().current_w, pygame.display.Info().current_h)
                    screen = pygame.display.set_mode(current_win_size, pygame.FULLSCREEN)
                else:
                    current_win_size = (WIDTH, HEIGHT)
                    screen = pygame.display.set_mode(current_win_size, pygame.RESIZABLE)
            if game_state == STATE_PLAYING:
                if event.key == pygame.K_1:
                    current_weapon = WEAPON_PISTOL; is_reloading = False
                if event.key == pygame.K_2 and has_ak:
                    current_weapon = WEAPON_AK; is_reloading = False
                if event.key == pygame.K_3 and has_shotgun:
                    current_weapon = WEAPON_SHOTGUN; is_reloading = False

    if game_state != STATE_PLAYING or player_dead:
        pygame.mouse.get_rel()

    if game_state in [STATE_PLAYING, STATE_COUNTDOWN]:
        for notice in pickup_notices[:]:
            notice['timer'] -= 1 * time_scale
            if notice['timer'] <= 0:
                pickup_notices.remove(notice)

    if game_state == STATE_COUNTDOWN:
        elapsed = pygame.time.get_ticks() - countdown_start
        if elapsed >= 4000:
            game_state = STATE_PLAYING
            countdown_start = 0

    if game_state == STATE_PLAYING:
        if not is_multiplayer:
            curr_grid_x = int(player_x / TILE_SIZE)
            curr_grid_y = int(player_y / TILE_SIZE)
            if curr_grid_x != last_grid_x or curr_grid_y != last_grid_y:
                update_flow_field()
                last_grid_x, last_grid_y = curr_grid_x, curr_grid_y

        if pygame.mouse.get_pressed()[0] and current_weapon == WEAPON_AK and not player_dead:
            shoot()
        if heal_effect_timer > 0:
            heal_effect_timer -= 1 * time_scale
        if damage_flash_timer > 0:
            damage_flash_timer -= 1 * time_scale
        if damage_text_timer > 0:
            damage_text_timer -= 1 * time_scale

        if is_melee_attacking:
            melee_timer -= 1 * time_scale
            if melee_timer <= 0:
                is_melee_attacking = False
        if is_reloading and current_time >= reload_end:
            is_reloading = False
            if current_weapon == WEAPON_PISTOL:
                current_pistol_ammo = max_pistol_ammo
            elif current_weapon == WEAPON_AK:
                needed = max_ak_ammo - current_ak_ammo
                taken = min(needed, ak_reserve_ammo)
                current_ak_ammo += taken; ak_reserve_ammo -= taken
            elif current_weapon == WEAPON_SHOTGUN:
                needed = max_shotgun_ammo - current_shotgun_ammo
                taken = min(needed, shotgun_reserve_ammo)
                current_shotgun_ammo += taken; shotgun_reserve_ammo -= taken

        if not is_multiplayer:
            target_max_enemies = min(30, 10 + (current_score // 600) * 2)
            spawn_amount = min(3, 1 + (current_score // 1200))
            spawn_delay = max(60, 150 - (current_score // 300) * 5)
            alive_enemies_count = sum(1 for e in enemies if not e['dead'])
            if len(enemies) > target_max_enemies * 3:
                enemies[:] = [e for e in enemies if not e['dead']]
            if alive_enemies_count < target_max_enemies:
                spawn_timer += 1 * time_scale
                if spawn_timer > spawn_delay:
                    spawn_enemies(spawn_amount); spawn_timer = 0

        if is_shooting:
            shoot_timer -= 1 * time_scale
            if shoot_timer <= 0:
                is_shooting = False

        if current_weapon == WEAPON_PISTOL and current_pistol_ammo == 0:
            start_reload()
        elif current_weapon == WEAPON_AK and current_ak_ammo == 0 and ak_reserve_ammo > 0:
            start_reload()
        elif current_weapon == WEAPON_SHOTGUN and current_shotgun_ammo == 0 and shotgun_reserve_ammo > 0:
            start_reload()

        if not player_dead:
            mouse_dx, mouse_dy = pygame.mouse.get_rel()
            player_angle += mouse_dx * 0.002 * sens_mult
            player_pitch -= mouse_dy * 2 * sens_mult
            player_pitch = max(-HEIGHT // 2 + 50, min(HEIGHT // 2 - 50, player_pitch))

            dx, dy = 0, 0

            # 👇 이 코드로 다시 덮어써주세요 👇
            is_sprinting = False
            if keys[pygame.K_LSHIFT] and player_stamina > 0:
                speed = 5.0  # 달리기 속도
                player_stamina -= 0.1
                is_sprinting = True  # <--- 이 변수가 지워져서 오류가 났던 것입니다!
            else:
                speed = 2.5  # 기본 걷기 속도

            if is_aiming:
                speed *= 0.5

            if is_sprinting and (keys[pygame.K_w] or keys[pygame.K_s] or keys[pygame.K_a] or keys[pygame.K_d]):
                player_stamina = max(0, player_stamina - 0.5 * time_scale)
            else:
                player_stamina = min(max_stamina, player_stamina + 0.2 * time_scale)

            # 👇 여기서부터 덮어쓰기 👇
            if keys[pygame.K_w]: dx += math.cos(player_angle) * speed; dy += math.sin(player_angle) * speed
            if keys[pygame.K_s]: dx -= math.cos(player_angle) * speed; dy -= math.sin(player_angle) * speed
            if keys[pygame.K_a]: dx += math.sin(player_angle) * speed; dy -= math.cos(player_angle) * speed
            if keys[pygame.K_d]: dx -= math.sin(player_angle) * speed; dy += math.cos(player_angle) * speed

            player_is_moving = (dx != 0 or dy != 0)
            check_collision(dx, dy)
            
            # 플레이어 발소리 재생
            if player_is_moving:
                # 걷기 속도 기준을 초과하면 달리기(500ms), 아니면 걷기(1000ms)로 딜레이 설정
                # (만약 기본 걷기 속도 변수가 4.0 등이라면 그보다 클 때 달리기로 판별)
                delay = 300 if speed > 5.0 else 500 

                if current_time - last_player_footstep_time >= delay:
                    last_player_footstep_time = current_time
                    if 'player_footstep' in sounds:
                        sounds['player_footstep'].stop() # 겹침 방지: 재생 전 이전 소리 즉시 끄기!
                        sounds['player_footstep'].set_volume(1.0)
                    play_and_broadcast_sound('player_footstep')
            else:
                if 'player_footstep' in sounds:
                    sounds['player_footstep'].stop()
            # 👆 여기까지 👆

            for item in items[:]:
                dist = math.hypot(player_x - item['x'], player_y - item['y'])
                if dist < 40:
                    msg, msg_color = "", WHITE
                    if item['type'] == 'ak':
                        if not has_ak:
                            has_ak = True; msg = "AK-47 획득"; msg_color = YELLOW
                        else:
                            msg = "AK 탄약 획득 (+30발)"; msg_color = YELLOW; ak_reserve_ammo += 30
                    elif item['type'] == 'shotgun':
                        if not has_shotgun:
                            has_shotgun = True; msg = "SHOTGUN 획득"; msg_color = WHITE
                        else:
                            msg = "샷건 탄약 획득 (+20발)"; msg_color = WHITE; shotgun_reserve_ammo += 20
                    elif item['type'] == 'ak_ammo':
                        ak_reserve_ammo += 15; msg = "AK 탄약 획득 (+15발)"; msg_color = YELLOW
                    elif item['type'] == 'shotgun_ammo':
                        shotgun_reserve_ammo += 4; msg = "샷건 탄약 획득 (+4발)"; msg_color = RED
                    elif item['type'] == 'health':
                        player_health = min(100.0, player_health + 20); msg = "체력 회복 (+20)"; msg_color = GREEN; heal_effect_timer = 40

                    if msg:
                        pickup_notices.append({'text': msg, 'color': msg_color, 'timer': 120})
                        if is_multiplayer and 'id' in item:
                            mp_send({'type': 'pickup', 'item_id': item['id']})
                    items.remove(item)

            if not is_multiplayer:
                closest_moving_monster_dist = float('inf')
                for enemy in enemies:
                    if enemy['dead']:
                        continue
                    edx, edy = player_x - enemy['x'], player_y - enemy['y']
                    dist = math.hypot(edx, edy)

                    if dist < 2000:
                        if dist > 35:
                            grid_x = int(enemy['x'] / TILE_SIZE)
                            grid_y = int(enemy['y'] / TILE_SIZE)

                            if check_line_of_sight(enemy['x'], enemy['y'], player_x, player_y):
                                fdx, fdy = edx / max(1.0, dist), edy / max(1.0, dist)
                            else:
                                if 0 <= grid_x < MAP_W and 0 <= grid_y < MAP_H:
                                    ffx, ffy = FLOW_FIELD[grid_y][grid_x]
                                    fdx, fdy = ffx, ffy
                                    if fdx == 0 and fdy == 0:
                                        fdx, fdy = edx / max(1.0, dist), edy / max(1.0, dist)
                                else:
                                    fdx, fdy = edx / max(1.0, dist), edy / max(1.0, dist)

                            move_x = fdx * enemy['speed']
                            move_y = fdy * enemy['speed']
                        
                            moved = False
                            if is_safe_enemy(enemy['x'] + move_x, enemy['y']):
                                enemy['x'] += move_x
                                moved = True
                            if is_safe_enemy(enemy['x'], enemy['y'] + move_y):
                                enemy['y'] += move_y
                                moved = True
                            
                            # 움직인 몬스터 중 가장 가까운 거리만 기록
                            if moved:
                                dist = math.hypot(player_x - enemy['x'], player_y - enemy['y'])
                                if dist < closest_moving_monster_dist:
                                    closest_moving_monster_dist = dist
                            # 👆 2번 끝 👆
                        else:
                            if current_time >= enemy['next_attack_time']:
                                enemy['next_attack_time'] = current_time + 1000
                                if current_time >= player_invincible_end:
                                    player_health -= 10.0

                                    damage_flash_timer = 20
                                    damage_text_timer = 60

                                    if player_health <= 0:
                                        player_dead = True
                                        game_state = STATE_GAMEOVER
                                        pygame.mouse.set_visible(True)
                                        pygame.event.set_grab(False)

            if closest_moving_monster_dist != float('inf'):
                    if current_time - last_monster_footstep_time >= 1000:
                        last_monster_footstep_time = current_time
                        vol = max(0.0, 1.0 - (closest_moving_monster_dist / 1000.0))
                        
                        if vol > 0 and 'monster_footstep' in sounds:
                            sounds['monster_footstep'].set_volume(vol * 0.3) 
                            sounds['monster_footstep'].play()
            
            maybe_send_state(current_time)

    render_scene()

    screen.fill(BLACK)
    win_w, win_h = current_win_size
    ratio = min(win_w / WIDTH, win_h / HEIGHT)
    scaled_w, scaled_h = int(WIDTH * ratio), int(HEIGHT * ratio)
    offset_x = (win_w - scaled_w) // 2
    offset_y = (win_h - scaled_h) // 2

    scaled_screen = pygame.transform.scale(virtual_screen, (scaled_w, scaled_h))
    screen.blit(scaled_screen, (offset_x, offset_y))

    pygame.display.flip()

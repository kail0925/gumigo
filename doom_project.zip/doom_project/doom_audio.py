import math

import pygame


def init_audio(channel_index=7, num_channels=50):
    if not pygame.mixer.get_init():
        pygame.mixer.init()
    pygame.mixer.set_num_channels(num_channels)
    return pygame.mixer.Channel(channel_index)


def load_sounds():
    sounds = {}
    try:
        sounds['pistol_shoot'] = pygame.mixer.Sound('sound/pistol_shoot.mp3')
        sounds['pistol_reload'] = pygame.mixer.Sound('sound/pistol_reload.mp3')

        sounds['ak_shoot'] = pygame.mixer.Sound('sound/ak_shoot.mp3')
        sounds['ak_reload'] = pygame.mixer.Sound('sound/ak_reload.mp3')

        sounds['shotgun_shoot'] = pygame.mixer.Sound('sound/shotgun_shoot.mp3')
        sounds['shotgun_reload'] = pygame.mixer.Sound('sound/shotgun_reload.mp3')

        sounds['no_ammo'] = pygame.mixer.Sound('sound/no_ammo.mp3')

        sounds['player_footstep'] = pygame.mixer.Sound('sound/player_footstep.mp3')
        sounds['monster_footstep'] = pygame.mixer.Sound('sound/monster_footstep.mp3')

        sounds['sword_sound'] = pygame.mixer.Sound('sound/sword_sound.mp3')
        sounds['heal_sound'] = pygame.mixer.Sound('sound/heal_sound.mp3')
        sounds['item_pickup'] = pygame.mixer.Sound('sound/item_pickup.mp3')
        sounds['item_pickup'].set_volume(1.5)
        sounds['ammo_pickup'] = pygame.mixer.Sound('sound/ammo_pickup.mp3')

        sounds['main_lobby'] = pygame.mixer.Sound('sound/mainlobby.mp3')

        sounds['monster_dmg'] = pygame.mixer.Sound('sound/monster_dmg.mp3')
        sounds['player_dmg'] = pygame.mixer.Sound('sound/player_dmg.mp3')
        sounds['bomb_cooking'] = pygame.mixer.Sound('sound/bomb_cooking.mp3')
        sounds['bomb_boom'] = pygame.mixer.Sound('sound/bomb_boom.mp3')
    except Exception as exc:
        print("사운드 로드 실패. sound 폴더에 파일이 있는지 확인하세요.", exc)

    return sounds


def play_sound(sounds, sound_key, volume=1.0):
    if sound_key in sounds:
        sounds[sound_key].set_volume(volume)
        sounds[sound_key].play()


def start_grenade_cooking_sound(sounds, grenade_cook_channel):
    if 'bomb_cooking' in sounds:
        grenade_cook_channel.stop()
        grenade_cook_channel.set_volume(1.0)
        grenade_cook_channel.play(sounds['bomb_cooking'])


def stop_grenade_cooking_sound(grenade_cook_channel):
    if grenade_cook_channel.get_busy():
        grenade_cook_channel.stop()


def play_positional_sound(
    sounds,
    sound_key,
    source_x,
    source_y,
    listener_x,
    listener_y,
    max_distance,
    max_volume=1.0,
):
    if sound_key not in sounds:
        return

    distance = math.hypot(source_x - listener_x, source_y - listener_y)
    volume_ratio = max(0.0, 1.0 - (distance / max_distance))
    if volume_ratio <= 0:
        return

    channel = pygame.mixer.find_channel()
    if channel is None:
        return

    channel.set_volume(max_volume * volume_ratio)
    channel.play(sounds[sound_key])

import math
import random


MONSTER_BASE_HP = 150
MONSTER_SPEED_MIN = 0.6
MONSTER_SPEED_MAX = 1.4
MONSTER_MIN_SPAWN_DISTANCE = 300.0
MONSTER_SPAWN_ATTEMPTS = 50
MONSTER_ATTACK_DAMAGE = 10.0
MONSTER_ATTACK_COOLDOWN_MS = 1000
MONSTER_FOOTSTEP_VOLUME_SCALE = 0.3


def build_enemy(enemy_id, x, y):
    return {
        'id': enemy_id,
        'x': x,
        'y': y,
        'hp': MONSTER_BASE_HP,
        'speed': random.uniform(MONSTER_SPEED_MIN, MONSTER_SPEED_MAX),
        'dead': False,
        'next_attack_time': 0,
        'anim_offset': random.uniform(0, math.pi * 2),
    }

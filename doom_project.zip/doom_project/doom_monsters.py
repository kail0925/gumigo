import math
import random

import collections

import pygame


MONSTER_BASE_HP = 150
MONSTER_SPEED_MIN = 0.6
MONSTER_SPEED_MAX = 1.4
MONSTER_MIN_SPAWN_DISTANCE = 300.0
MONSTER_SPAWN_ATTEMPTS = 50
MONSTER_ATTACK_DAMAGE = 10.0
MONSTER_ATTACK_COOLDOWN_MS = 1000
MONSTER_FOOTSTEP_VOLUME_SCALE = 0.3


def build_enemy(enemy_id, x, y):
    return {
        'id': enemy_id,
        'x': x,
        'y': y,
        'hp': MONSTER_BASE_HP,
        'speed': random.uniform(MONSTER_SPEED_MIN, MONSTER_SPEED_MAX),
        'dead': False,
        'next_attack_time': 0,
        'anim_offset': random.uniform(0, math.pi * 2),
    }


def update_flow_field(ctx):
    map_w = ctx['MAP_W']
    map_h = ctx['MAP_H']
    game_map = ctx['MAP']

    integration_field = [[float('inf')] * map_w for _ in range(map_h)]
    ctx['FLOW_FIELD'] = [[(0, 0)] * map_w for _ in range(map_h)]

    player_grid_x = int(ctx['player_x'] / ctx['TILE_SIZE'])
    player_grid_y = int(ctx['player_y'] / ctx['TILE_SIZE'])
    if not (0 <= player_grid_x < map_w and 0 <= player_grid_y < map_h):
        return

    queue = collections.deque([(player_grid_x, player_grid_y)])
    integration_field[player_grid_y][player_grid_x] = 0
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (1, -1), (-1, 1), (1, 1)]

    while queue:
        curr_x, curr_y = queue.popleft()
        for dx, dy in directions:
            next_x = curr_x + dx
            next_y = curr_y + dy
            if not (0 <= next_x < map_w and 0 <= next_y < map_h):
                continue
            if game_map[next_y][next_x] != 0:
                continue

            cost = 1.414 if dx != 0 and dy != 0 else 1.0
            new_cost = integration_field[curr_y][curr_x] + cost
            if new_cost < integration_field[next_y][next_x]:
                integration_field[next_y][next_x] = new_cost
                queue.append((next_x, next_y))

    for y in range(map_h):
        for x in range(map_w):
            if game_map[y][x] == 1:
                continue
            if integration_field[y][x] == float('inf'):
                ctx['FLOW_FIELD'][y][x] = (0, 0)
                continue

            left = integration_field[y][x - 1] if x > 0 and game_map[y][x - 1] == 0 else integration_field[y][x]
            right = integration_field[y][x + 1] if x < map_w - 1 and game_map[y][x + 1] == 0 else integration_field[y][x]
            up = integration_field[y - 1][x] if y > 0 and game_map[y - 1][x] == 0 else integration_field[y][x]
            down = integration_field[y + 1][x] if y < map_h - 1 and game_map[y + 1][x] == 0 else integration_field[y][x]

            vx = left - right
            vy = up - down

            if vx == 0 and vy == 0:
                min_cost = float('inf')
                best_dir = (0, 0)
                for dx, dy in directions:
                    next_x = x + dx
                    next_y = y + dy
                    if not (0 <= next_x < map_w and 0 <= next_y < map_h):
                        continue
                    if game_map[next_y][next_x] != 0:
                        continue
                    if integration_field[next_y][next_x] < min_cost:
                        min_cost = integration_field[next_y][next_x]
                        dist = math.hypot(dx, dy)
                        best_dir = (dx / dist, dy / dist)
                ctx['FLOW_FIELD'][y][x] = best_dir
                continue

            vector_len = math.hypot(vx, vy)
            if vector_len > 0:
                ctx['FLOW_FIELD'][y][x] = (vx / vector_len, vy / vector_len)
            else:
                ctx['FLOW_FIELD'][y][x] = (0, 0)


def check_line_of_sight(ctx, x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    dist = math.hypot(dx, dy)
    if dist == 0:
        return True

    steps = int(dist / 16.0)
    if steps == 0:
        return True

    for i in range(1, steps):
        check_x = x1 + (dx * i / steps)
        check_y = y1 + (dy * i / steps)
        grid_x = int(check_x / ctx['TILE_SIZE'])
        grid_y = int(check_y / ctx['TILE_SIZE'])
        if 0 <= grid_x < ctx['MAP_W'] and 0 <= grid_y < ctx['MAP_H']:
            if ctx['MAP'][grid_y][grid_x] == 1:
                return False
    return True


def spawn_enemies(ctx, count):
    existing_ids = {enemy.get('id') for enemy in ctx['enemies'] if 'id' in enemy}
    for _ in range(count):
        for _attempt in range(MONSTER_SPAWN_ATTEMPTS):
            grid_x = random.randint(1, ctx['MAP_W'] - 2)
            grid_y = random.randint(1, ctx['MAP_H'] - 2)
            dist_to_player = math.hypot(
                grid_x * ctx['TILE_SIZE'] - ctx['player_x'],
                grid_y * ctx['TILE_SIZE'] - ctx['player_y'],
            )
            if ctx['MAP'][grid_y][grid_x] != 0 or dist_to_player <= MONSTER_MIN_SPAWN_DISTANCE:
                continue

            enemy_id = random.randint(0, 999999)
            while enemy_id in existing_ids:
                enemy_id = random.randint(0, 999999)

            existing_ids.add(enemy_id)
            ctx['enemies'].append(
                build_enemy(
                    enemy_id,
                    grid_x * ctx['TILE_SIZE'] + ctx['TILE_SIZE'] // 2,
                    grid_y * ctx['TILE_SIZE'] + ctx['TILE_SIZE'] // 2,
                )
            )
            break


def kill_enemy(ctx, target_enemy, is_headshot):
    target_enemy['dead'] = True
    ctx['current_score'] += 200 if is_headshot else 100
    ctx['enemies_killed'] += 1

    if ctx['enemies_killed'] % ctx['GRENADE_REWARD_KILLS'] == 0:
        ctx['grenade_count'] += 1
        ctx['pickup_notices'].append({'text': "수류탄 +1", 'color': ctx['YELLOW'], 'timer': 150})

    drop_x = target_enemy['x'] + random.randint(-10, 10)
    drop_y = target_enemy['y'] + random.randint(-10, 10)
    roll = random.random()
    drop_type = None

    if roll < 0.15:
        drop_type = 'shotgun_ammo' if ctx['has_shotgun'] else 'shotgun'
    elif roll < 0.40:
        drop_type = 'ak_ammo' if ctx['has_ak'] else 'ak'
    elif roll < 0.60:
        drop_type = 'health'

    if drop_type:
        ctx['items'].append(
            {
                'id': random.randint(0, 999999),
                'x': drop_x,
                'y': drop_y,
                'type': drop_type,
                'anim': random.random() * 10,
            }
        )


def update_enemies(ctx, current_time):
    closest_moving_monster_dist = float('inf')

    for enemy in ctx['enemies']:
        if enemy['dead']:
            continue

        edx = ctx['player_x'] - enemy['x']
        edy = ctx['player_y'] - enemy['y']
        dist = math.hypot(edx, edy)
        if dist >= 2000:
            continue

        if dist > 35:
            grid_x = int(enemy['x'] / ctx['TILE_SIZE'])
            grid_y = int(enemy['y'] / ctx['TILE_SIZE'])

            if check_line_of_sight(ctx, enemy['x'], enemy['y'], ctx['player_x'], ctx['player_y']):
                flow_dx = edx / max(1.0, dist)
                flow_dy = edy / max(1.0, dist)
            elif 0 <= grid_x < ctx['MAP_W'] and 0 <= grid_y < ctx['MAP_H']:
                flow_dx, flow_dy = ctx['FLOW_FIELD'][grid_y][grid_x]
                if flow_dx == 0 and flow_dy == 0:
                    flow_dx = edx / max(1.0, dist)
                    flow_dy = edy / max(1.0, dist)
            else:
                flow_dx = edx / max(1.0, dist)
                flow_dy = edy / max(1.0, dist)

            move_x = flow_dx * enemy['speed']
            move_y = flow_dy * enemy['speed']
            moved = False

            if ctx['is_safe_enemy'](enemy['x'] + move_x, enemy['y']):
                enemy['x'] += move_x
                moved = True
            if ctx['is_safe_enemy'](enemy['x'], enemy['y'] + move_y):
                enemy['y'] += move_y
                moved = True

            if moved:
                dist = math.hypot(ctx['player_x'] - enemy['x'], ctx['player_y'] - enemy['y'])
                closest_moving_monster_dist = min(closest_moving_monster_dist, dist)
            continue

        if current_time < enemy['next_attack_time']:
            continue

        enemy['next_attack_time'] = current_time + MONSTER_ATTACK_COOLDOWN_MS
        if current_time < ctx['player_invincible_end']:
            continue

        ctx['play_sound']('player_dmg')
        ctx['player_health'] -= MONSTER_ATTACK_DAMAGE

        enemy_id = enemy.get('id')
        if enemy_id is not None:
            ctx['last_hit_enemies'][enemy_id] = current_time

        ctx['damage_flash_timer'] = 20
        ctx['damage_text_timer'] = 60

        if ctx['player_health'] <= 0:
            ctx['player_dead'] = True
            ctx['game_state'] = ctx['STATE_GAMEOVER']
            pygame.mouse.set_visible(True)
            pygame.event.set_grab(False)

    if closest_moving_monster_dist == float('inf'):
        return

    if current_time - ctx['last_monster_footstep_time'] < 1000:
        return

    ctx['last_monster_footstep_time'] = current_time
    volume = max(0.0, 1.0 - (closest_moving_monster_dist / 1000.0))
    if volume > 0 and 'monster_footstep' in ctx['sounds']:
        ctx['sounds']['monster_footstep'].set_volume(volume * MONSTER_FOOTSTEP_VOLUME_SCALE)
        ctx['sounds']['monster_footstep'].play()


def draw_items_and_enemies(ctx):
    render_list = []
    current_t = pygame.time.get_ticks()

    for item in ctx['items']:
        render_list.append(
            {
                'type': 'item',
                'obj': item,
                'dist': math.hypot(item['x'] - ctx['player_x'], item['y'] - ctx['player_y']),
            }
        )

    for enemy in ctx['enemies']:
        if enemy['dead']:
            continue
        render_list.append(
            {
                'type': 'enemy',
                'obj': enemy,
                'dist': math.hypot(enemy['x'] - ctx['player_x'], enemy['y'] - ctx['player_y']),
            }
        )

    render_list.sort(key=lambda entry: entry['dist'], reverse=True)

    for entity in render_list:
        obj = entity['obj']
        dist = entity['dist']
        safe_dist = max(1.0, dist)

        dx = obj['x'] - ctx['player_x']
        dy = obj['y'] - ctx['player_y']
        angle_to_obj = math.atan2(dy, dx)
        angle_diff = angle_to_obj - ctx['player_angle']
        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi

        if abs(angle_diff) >= ctx['current_fov'] / 2 + 0.3:
            continue

        screen_x = (ctx['WIDTH'] / 2) + (angle_diff / (ctx['current_fov'] / 2)) * (ctx['WIDTH'] / 2)
        wall_height = (ctx['TILE_SIZE'] * ctx['current_proj_dist']) / safe_dist

        ray_idx = int(screen_x / ctx['SCALE'])
        if not (0 <= ray_idx < ctx['CASTED_RAYS']) or dist >= ctx['Z_BUFFER'][ray_idx] + 20:
            continue

        fog_ratio = min(1.0, dist / ctx['MAX_DEPTH'])
        intensity = max(0.0, 1.0 - fog_ratio)

        if entity['type'] == 'enemy':
            sprite_height = wall_height * 0.78
            sprite_width = sprite_height * 0.56
            if sprite_height < 14:
                continue

            bob_offset = math.sin((current_t / 150.0) + obj['anim_offset']) * (wall_height * 0.05)
            monster_bottom = ctx['HEIGHT'] // 2 + wall_height // 2 + ctx['player_pitch'] + bob_offset
            monster_top = monster_bottom - sprite_height

            shadow_w = sprite_width * 0.8
            shadow_h = max(3, wall_height * 0.07)
            pygame.draw.ellipse(
                ctx['virtual_screen'],
                (10, 10, 10, int(80 * intensity)),
                (
                    screen_x - shadow_w / 2,
                    ctx['HEIGHT'] // 2 + wall_height // 2 + ctx['player_pitch'] - shadow_h / 2,
                    shadow_w,
                    shadow_h,
                ),
            )

            body_color = (
                int(150 * intensity + ctx['FOG_COLOR'][0] * (1 - intensity)),
                int(58 * intensity + ctx['FOG_COLOR'][1] * (1 - intensity)),
                int(66 * intensity + ctx['FOG_COLOR'][2] * (1 - intensity)),
            )
            body_rect = pygame.Rect(
                int(screen_x - sprite_width * 0.5),
                int(monster_top + sprite_height * 0.12),
                int(sprite_width),
                int(sprite_height * 0.78),
            )
            pygame.draw.ellipse(ctx['virtual_screen'], body_color, body_rect)

            head_w = sprite_width * 0.48
            head_h = sprite_height * 0.20
            head_rect = pygame.Rect(
                int(screen_x - head_w * 0.5),
                int(monster_top + sprite_height * 0.18),
                int(head_w),
                int(head_h),
            )
            pygame.draw.ellipse(ctx['virtual_screen'], (int(210 * intensity), int(190 * intensity), int(120 * intensity)), head_rect)

            if dist < 900:
                eye_color = (int(255 * intensity), int(220 * intensity), 60)
                eye_y = int(monster_top + sprite_height * 0.28)
                eye_w = max(2, int(sprite_width * 0.1))
                pygame.draw.line(
                    ctx['virtual_screen'],
                    eye_color,
                    (int(screen_x - sprite_width * 0.12), eye_y),
                    (int(screen_x + sprite_width * 0.12), eye_y),
                    eye_w,
                )

            if dist < 650:
                hp_ratio = max(0, obj['hp']) / MONSTER_BASE_HP
                bar_w = int(sprite_width * 0.8)
                bar_h = max(3, int(sprite_height * 0.04))
                bar_x = int(screen_x - bar_w / 2)
                bar_y = int(monster_top - bar_h - max(4, wall_height * 0.04))
                pygame.draw.rect(ctx['virtual_screen'], (70, 12, 12), (bar_x, bar_y, bar_w, bar_h))
                pygame.draw.rect(ctx['virtual_screen'], (40, 190, 70), (bar_x, bar_y, int(bar_w * hp_ratio), bar_h))
            continue

        item_anim_y = math.sin(current_t / 200.0 + obj['anim']) * (wall_height * 0.05)
        item_size = max(8, int(wall_height * 0.18))
        if item_size < 7:
            continue
        item_bottom = ctx['HEIGHT'] // 2 + wall_height // 2 + ctx['player_pitch'] + item_anim_y

        shadow_w = item_size * 2
        pygame.draw.ellipse(
            ctx['virtual_screen'],
            (10, 10, 10),
            (
                screen_x - shadow_w / 2,
                ctx['HEIGHT'] // 2 + wall_height // 2 + ctx['player_pitch'],
                shadow_w,
                item_size * 0.3,
            ),
        )

        label = None
        if obj['type'] == 'ak':
            color = (int(139 * intensity), int(69 * intensity), int(19 * intensity))
            dark_gray = (int(50 * intensity), int(50 * intensity), int(50 * intensity))
            pygame.draw.rect(ctx['virtual_screen'], color, (screen_x - item_size, item_bottom - item_size * 0.8, item_size * 2, item_size * 0.35), border_radius=2)
            pygame.draw.rect(ctx['virtual_screen'], dark_gray, (screen_x - item_size * 1.1, item_bottom - item_size * 1.05, item_size * 1.45, item_size * 0.28), border_radius=2)
            label = ctx['ITEM_FONT'].render("AK-47", True, ctx['YELLOW']) if dist < 320 else None
        elif obj['type'] == 'shotgun':
            wood = (int(120 * intensity), int(60 * intensity), int(20 * intensity))
            dark_metal = (int(40 * intensity), int(40 * intensity), int(40 * intensity))
            pygame.draw.rect(ctx['virtual_screen'], dark_metal, (screen_x - item_size * 1.1, item_bottom - item_size * 1.0, item_size * 1.9, item_size * 0.28), border_radius=2)
            pygame.draw.rect(ctx['virtual_screen'], wood, (screen_x - item_size * 0.9, item_bottom - item_size * 0.78, item_size * 0.85, item_size * 0.46), border_radius=2)
            label = ctx['ITEM_FONT'].render("SHOTGUN", True, ctx['WHITE']) if dist < 320 else None
        elif obj['type'] == 'ak_ammo':
            box_color = (int(100 * intensity), int(120 * intensity), int(100 * intensity))
            pygame.draw.rect(
                ctx['virtual_screen'],
                box_color,
                (screen_x - item_size * 0.8, item_bottom - item_size, item_size * 1.6, item_size),
                border_radius=2,
            )
            pygame.draw.rect(ctx['virtual_screen'], (int(200 * intensity), int(180 * intensity), 0), (screen_x - item_size * 0.45, item_bottom - item_size * 0.72, item_size * 0.9, item_size * 0.18), border_radius=2)
            label = ctx['ITEM_FONT'].render("AK AMMO", True, ctx['YELLOW']) if dist < 300 else None
        elif obj['type'] == 'shotgun_ammo':
            box_color = (int(150 * intensity), int(40 * intensity), int(40 * intensity))
            gold = (int(200 * intensity), int(180 * intensity), 0)
            pygame.draw.rect(
                ctx['virtual_screen'],
                box_color,
                (screen_x - item_size * 0.8, item_bottom - item_size * 0.8, item_size * 1.6, item_size * 0.8),
                border_radius=2,
            )
            pygame.draw.rect(ctx['virtual_screen'], gold, (screen_x - item_size * 0.42, item_bottom - item_size * 0.56, item_size * 0.84, item_size * 0.16), border_radius=2)
            label = ctx['ITEM_FONT'].render("SG AMMO", True, ctx['RED']) if dist < 300 else None
        elif obj['type'] == 'health':
            box_color = (int(220 * intensity), int(220 * intensity), int(220 * intensity))
            cross_color = (int(200 * intensity), 0, 0)
            pygame.draw.rect(
                ctx['virtual_screen'],
                box_color,
                (screen_x - item_size, item_bottom - item_size * 1.2, item_size * 2, item_size * 1.2),
                border_radius=3,
            )
            pygame.draw.rect(
                ctx['virtual_screen'],
                cross_color,
                (screen_x - item_size * 0.2, item_bottom - item_size * 0.9, item_size * 0.4, item_size * 0.6),
            )
            pygame.draw.rect(
                ctx['virtual_screen'],
                cross_color,
                (screen_x - item_size * 0.5, item_bottom - item_size * 0.75, item_size, item_size * 0.3),
            )
            label = ctx['ITEM_FONT'].render("HP", True, ctx['RED']) if dist < 280 else None

        if label is not None:
            label.set_alpha(int(255 * max(0.3, intensity)))
            ctx['virtual_screen'].blit(label, (screen_x - label.get_width() // 2, item_bottom - item_size - 30))

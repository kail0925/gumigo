import math
import random


GAME_CAPTION = "Pygame Retro FPS - Ultimate Balance (Fixed)"

WIDTH = 1280
HEIGHT = 720

TILE_SIZE = 64
MAP_DEFAULT_WIDTH = 24
MAP_DEFAULT_HEIGHT = 24

BASE_FOV = math.pi / 3
CASTED_RAYS = 320
MAX_DEPTH = 20 * TILE_SIZE
SCALE = WIDTH / CASTED_RAYS

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
YELLOW = (255, 220, 0)
GRAY = (80, 80, 80)
LIGHT_GRAY = (150, 150, 150)
BROWN = (139, 69, 19)

CROSSHAIR_COLOR_PRESETS = (
    ("\ud770\uc0c9", WHITE),
    ("\ube68\uac15", (255, 80, 80)),
    ("\ucd08\ub85d", (80, 255, 120)),
    ("\ud558\ub298", (80, 220, 255)),
    ("\ub178\ub791", YELLOW),
    ("\ubd84\ud64d", (255, 120, 220)),
)

INDICATOR_COLOR_PRESETS = (
    ("\uc8fc\ud669", (255, 200, 80), (120, 70, 10)),
    ("\ube68\uac15", (255, 90, 90), (120, 20, 20)),
    ("\ucd08\ub85d", (120, 255, 140), (20, 100, 40)),
    ("\ud558\ub298", (120, 220, 255), (20, 80, 120)),
    ("\ub178\ub791", (255, 230, 100), (120, 100, 20)),
    ("\ubcf4\ub77c", (210, 150, 255), (90, 40, 120)),
)

DEFAULT_CROSSHAIR_COLOR_INDEX = 0
DEFAULT_INDICATOR_COLOR_INDEX = 0

FOG_COLOR = (30, 30, 35)
DOOM_WALL_BASE = (150, 120, 90)

STATE_PLAYING = 0
STATE_GAMEOVER = 1
STATE_PAUSED = 2
STATE_MAIN_MENU = 3
STATE_COUNTDOWN = 4
STATE_SETTINGS = 5
STATE_IP_INPUT = -1

GRENADE_START_COUNT = 1
GRENADE_REWARD_KILLS = 20
GRENADE_MAX_DAMAGE = 150
GRENADE_MIN_DAMAGE = 70
GRENADE_BLAST_RADIUS = 220.0
GRENADE_THROW_SPEED = 10.0
GRENADE_BASE_VZ = 3.7
GRENADE_GRAVITY = 0.70
GRENADE_BOUNCE_DAMPING = 0.34
GRENADE_GROUND_FRICTION = 0.88
GRENADE_FUSE_FRAMES = 420
GRENADE_PREVIEW_STEPS = 48
GRENADE_PREVIEW_STEP_SCALE = 0.9
GRENADE_EXPLOSION_LIFE = 52
GRENADE_EXPLOSION_SOUND_RADIUS = GRENADE_BLAST_RADIUS * 4.0
GRENADE_EXPLOSION_MAX_VOLUME = 0.85


def generate_random_map(width, height, tile_size):
    game_map = [[1 for _ in range(width)] for _ in range(height)]

    for y in range(1, height - 1):
        for x in range(1, width - 1):
            if random.random() > 0.3:
                game_map[y][x] = 0

    center_x, center_y = width // 2, height // 2
    for dy in range(-1, 2):
        for dx in range(-1, 2):
            game_map[center_y + dy][center_x + dx] = 0

    visited = set()
    regions = []

    for y in range(1, height - 1):
        for x in range(1, width - 1):
            if game_map[y][x] != 0 or (x, y) in visited:
                continue

            region = []
            queue = [(x, y)]
            visited.add((x, y))

            while queue:
                curr_x, curr_y = queue.pop(0)
                region.append((curr_x, curr_y))

                for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                    next_x = curr_x + dx
                    next_y = curr_y + dy
                    if not (0 < next_x < width - 1 and 0 < next_y < height - 1):
                        continue
                    if game_map[next_y][next_x] != 0 or (next_x, next_y) in visited:
                        continue

                    visited.add((next_x, next_y))
                    queue.append((next_x, next_y))

            regions.append(region)

    if regions:
        regions.sort(key=len, reverse=True)
        main_region = regions[0]

        for isolated_region in regions[1:]:
            src_x, src_y = random.choice(isolated_region)
            dst_x, dst_y = random.choice(main_region)

            if random.choice((True, False)):
                for x in range(min(src_x, dst_x), max(src_x, dst_x) + 1):
                    game_map[src_y][x] = 0
                for y in range(min(src_y, dst_y), max(src_y, dst_y) + 1):
                    game_map[y][dst_x] = 0
            else:
                for y in range(min(src_y, dst_y), max(src_y, dst_y) + 1):
                    game_map[y][src_x] = 0
                for x in range(min(src_x, dst_x), max(src_x, dst_x) + 1):
                    game_map[dst_y][x] = 0

    for _ in range(2):
        for y in range(height - 1):
            for x in range(width - 1):
                if game_map[y][x] == 1 and game_map[y + 1][x + 1] == 1:
                    if game_map[y + 1][x] == 0 and game_map[y][x + 1] == 0:
                        game_map[y + 1][x] = 1
                        game_map[y][x + 1] = 1
                if game_map[y][x + 1] == 1 and game_map[y + 1][x] == 1:
                    if game_map[y][x] == 0 and game_map[y + 1][x + 1] == 0:
                        game_map[y][x] = 1
                        game_map[y + 1][x + 1] = 1

    player_x = center_x * tile_size + tile_size // 2
    player_y = center_y * tile_size + tile_size // 2
    return game_map, width, height, player_x, player_y
